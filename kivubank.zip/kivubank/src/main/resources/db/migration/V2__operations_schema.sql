-- Notifications, incidents, anomaly assessments, simulated provider ledger and reconciliation

CREATE TABLE notifications (
    id         BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id    BIGINT        NOT NULL,
    channel    VARCHAR(10)   NOT NULL,
    type       VARCHAR(30)   NOT NULL,
    recipient  VARCHAR(190)  NULL,
    subject    VARCHAR(150)  NOT NULL,
    body       VARCHAR(500)  NOT NULL,
    status     VARCHAR(10)   NOT NULL,
    provider   VARCHAR(30)   NOT NULL,
    created_at DATETIME(6)   NOT NULL,
    read_at    DATETIME(6)   NULL,
    CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users (id)
);
CREATE INDEX idx_notifications_user ON notifications (user_id, channel, created_at);

CREATE TABLE incidents (
    id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
    title               VARCHAR(150)  NOT NULL,
    description         VARCHAR(2000) NOT NULL,
    severity            VARCHAR(10)   NOT NULL,
    affected_service    VARCHAR(30)   NOT NULL,
    status              VARCHAR(15)   NOT NULL,
    assignee            VARCHAR(120)  NULL,
    created_by_user_id  BIGINT        NULL,
    created_at          DATETIME(6)   NOT NULL,
    updated_at          DATETIME(6)   NOT NULL,
    resolution          VARCHAR(2000) NULL,
    root_cause          VARCHAR(2000) NULL,
    resolved_at         DATETIME(6)   NULL,
    closed_at           DATETIME(6)   NULL
);
CREATE INDEX idx_incidents_status ON incidents (status, created_at);

CREATE TABLE anomaly_assessments (
    id             BIGINT AUTO_INCREMENT PRIMARY KEY,
    transaction_id BIGINT        NOT NULL,
    transaction_reference VARCHAR(40) NOT NULL,
    account_id     BIGINT        NOT NULL,
    score          DECIMAL(6,4)  NOT NULL,
    flagged        BOOLEAN       NOT NULL,
    reasons        VARCHAR(1000) NULL,
    features       VARCHAR(500)  NULL,
    model_version  VARCHAR(40)   NOT NULL,
    created_at     DATETIME(6)   NOT NULL,
    CONSTRAINT uq_anomaly_tx UNIQUE (transaction_id),
    CONSTRAINT fk_anomaly_tx FOREIGN KEY (transaction_id) REFERENCES transactions (id)
);
CREATE INDEX idx_anomaly_flagged ON anomaly_assessments (flagged, created_at);

CREATE TABLE sim_provider_transactions (
    id                 BIGINT AUTO_INCREMENT PRIMARY KEY,
    provider_reference VARCHAR(40)   NOT NULL,
    internal_reference VARCHAR(40)   NULL,
    amount             DECIMAL(19,2) NOT NULL,
    currency           VARCHAR(3)    NOT NULL,
    status             VARCHAR(10)   NOT NULL,
    submitted_at       DATETIME(6)   NOT NULL,
    CONSTRAINT uq_sim_provider_reference UNIQUE (provider_reference)
);
CREATE INDEX idx_sim_provider_internal ON sim_provider_transactions (internal_reference);
CREATE INDEX idx_sim_provider_submitted ON sim_provider_transactions (submitted_at);

CREATE TABLE reconciliation_runs (
    id                     BIGINT AUTO_INCREMENT PRIMARY KEY,
    started_at             DATETIME(6) NOT NULL,
    window_from            DATETIME(6) NOT NULL,
    window_to              DATETIME(6) NOT NULL,
    internal_count         INT         NOT NULL,
    external_count         INT         NOT NULL,
    matched_count          INT         NOT NULL,
    missing_external_count INT         NOT NULL,
    missing_internal_count INT         NOT NULL,
    amount_mismatch_count  INT         NOT NULL,
    duplicate_count        INT         NOT NULL,
    status_mismatch_count  INT         NOT NULL,
    triggered_by_user_id   BIGINT      NULL
);

CREATE TABLE reconciliation_items (
    id                 BIGINT AUTO_INCREMENT PRIMARY KEY,
    run_id             BIGINT        NOT NULL,
    category           VARCHAR(20)   NOT NULL,
    internal_reference VARCHAR(40)   NULL,
    provider_reference VARCHAR(40)   NULL,
    internal_amount    DECIMAL(19,2) NULL,
    external_amount    DECIMAL(19,2) NULL,
    internal_status    VARCHAR(20)   NULL,
    external_status    VARCHAR(20)   NULL,
    note               VARCHAR(300)  NULL,
    CONSTRAINT fk_recon_item_run FOREIGN KEY (run_id) REFERENCES reconciliation_runs (id)
);
CREATE INDEX idx_recon_items_run ON reconciliation_items (run_id, category);
