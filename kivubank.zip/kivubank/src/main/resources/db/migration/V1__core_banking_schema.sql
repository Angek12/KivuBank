-- KivuBank core schema (simulated banking data only)

CREATE TABLE users (
    id                    BIGINT AUTO_INCREMENT PRIMARY KEY,
    full_name             VARCHAR(120)  NOT NULL,
    email                 VARCHAR(190)  NOT NULL,
    phone                 VARCHAR(20)   NOT NULL,
    password_hash         VARCHAR(100)  NOT NULL,
    role                  VARCHAR(20)   NOT NULL,
    status                VARCHAR(20)   NOT NULL,
    failed_login_attempts INT           NOT NULL DEFAULT 0,
    locked_until          DATETIME(6)   NULL,
    last_login_at         DATETIME(6)   NULL,
    password_changed_at   DATETIME(6)   NULL,
    created_at            DATETIME(6)   NOT NULL,
    CONSTRAINT uq_users_email UNIQUE (email),
    CONSTRAINT uq_users_phone UNIQUE (phone),
    CONSTRAINT chk_users_role CHECK (role IN ('CUSTOMER','SUPPORT_AGENT','ADMIN','AUDITOR')),
    CONSTRAINT chk_users_status CHECK (status IN ('ACTIVE','DISABLED'))
);

CREATE TABLE accounts (
    id             BIGINT AUTO_INCREMENT PRIMARY KEY,
    account_number VARCHAR(20)   NOT NULL,
    user_id        BIGINT        NOT NULL,
    balance        DECIMAL(19,2) NOT NULL DEFAULT 0,
    currency       VARCHAR(3)    NOT NULL,
    status         VARCHAR(20)   NOT NULL,
    version        BIGINT        NOT NULL DEFAULT 0,
    created_at     DATETIME(6)   NOT NULL,
    updated_at     DATETIME(6)   NOT NULL,
    CONSTRAINT uq_accounts_number UNIQUE (account_number),
    CONSTRAINT uq_accounts_user UNIQUE (user_id),
    CONSTRAINT fk_accounts_user FOREIGN KEY (user_id) REFERENCES users (id),
    CONSTRAINT chk_accounts_balance CHECK (balance >= 0),
    CONSTRAINT chk_accounts_status CHECK (status IN ('ACTIVE','FROZEN','CLOSED'))
);

CREATE TABLE pin_credentials (
    account_id      BIGINT       NOT NULL PRIMARY KEY,
    pin_hash        VARCHAR(100) NOT NULL,
    failed_attempts INT          NOT NULL DEFAULT 0,
    locked_until    DATETIME(6)  NULL,
    updated_at      DATETIME(6)  NOT NULL,
    CONSTRAINT fk_pin_account FOREIGN KEY (account_id) REFERENCES accounts (id)
);

CREATE TABLE revoked_tokens (
    jti        VARCHAR(64) NOT NULL PRIMARY KEY,
    expires_at DATETIME(6) NOT NULL,
    revoked_at DATETIME(6) NOT NULL
);
CREATE INDEX idx_revoked_tokens_expiry ON revoked_tokens (expires_at);

CREATE TABLE transactions (
    id                    BIGINT AUTO_INCREMENT PRIMARY KEY,
    reference             VARCHAR(40)   NOT NULL,
    type                  VARCHAR(20)   NOT NULL,
    status                VARCHAR(20)   NOT NULL,
    amount                DECIMAL(19,2) NOT NULL,
    currency              VARCHAR(3)    NOT NULL,
    source_account_id     BIGINT        NULL,
    target_account_id     BIGINT        NULL,
    source_balance_after  DECIMAL(19,2) NULL,
    target_balance_after  DECIMAL(19,2) NULL,
    description           VARCHAR(200)  NULL,
    failure_reason        VARCHAR(200)  NULL,
    channel               VARCHAR(20)   NOT NULL,
    initiated_by_user_id  BIGINT        NULL,
    idempotency_key       VARCHAR(80)   NULL,
    reversal_of_id        BIGINT        NULL,
    version               BIGINT        NOT NULL DEFAULT 0,
    created_at            DATETIME(6)   NOT NULL,
    updated_at            DATETIME(6)   NOT NULL,
    completed_at          DATETIME(6)   NULL,
    CONSTRAINT uq_transactions_reference UNIQUE (reference),
    CONSTRAINT fk_tx_source FOREIGN KEY (source_account_id) REFERENCES accounts (id),
    CONSTRAINT fk_tx_target FOREIGN KEY (target_account_id) REFERENCES accounts (id),
    CONSTRAINT fk_tx_reversal FOREIGN KEY (reversal_of_id) REFERENCES transactions (id),
    CONSTRAINT chk_tx_amount CHECK (amount > 0),
    CONSTRAINT chk_tx_type CHECK (type IN ('DEPOSIT','WITHDRAWAL','TRANSFER','REVERSAL')),
    CONSTRAINT chk_tx_status CHECK (status IN ('PENDING','PROCESSING','SUCCESS','FAILED','REVERSED','CANCELLED'))
);
CREATE INDEX idx_tx_source_created ON transactions (source_account_id, created_at);
CREATE INDEX idx_tx_target_created ON transactions (target_account_id, created_at);
CREATE INDEX idx_tx_status_created ON transactions (status, created_at);
CREATE INDEX idx_tx_created ON transactions (created_at);

CREATE TABLE idempotency_records (
    id                    BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id               BIGINT         NOT NULL,
    idempotency_key       VARCHAR(80)    NOT NULL,
    operation             VARCHAR(40)    NOT NULL,
    request_hash          VARCHAR(64)    NOT NULL,
    state                 VARCHAR(20)    NOT NULL,
    http_status           INT            NULL,
    response_body         VARCHAR(4000)  NULL,
    transaction_reference VARCHAR(40)    NULL,
    created_at            DATETIME(6)    NOT NULL,
    completed_at          DATETIME(6)    NULL,
    CONSTRAINT uq_idempotency_user_key UNIQUE (user_id, idempotency_key),
    CONSTRAINT fk_idempotency_user FOREIGN KEY (user_id) REFERENCES users (id)
);
CREATE INDEX idx_idempotency_created ON idempotency_records (created_at);

CREATE TABLE audit_events (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    occurred_at  DATETIME(6)   NOT NULL,
    actor_user_id BIGINT       NULL,
    actor_email  VARCHAR(190)  NULL,
    actor_role   VARCHAR(20)   NULL,
    action       VARCHAR(40)   NOT NULL,
    outcome      VARCHAR(10)   NOT NULL,
    target_type  VARCHAR(40)   NULL,
    target_id    VARCHAR(80)   NULL,
    ip_address   VARCHAR(45)   NULL,
    request_id   VARCHAR(64)   NULL,
    details      VARCHAR(500)  NULL
);
CREATE INDEX idx_audit_occurred ON audit_events (occurred_at);
CREATE INDEX idx_audit_action ON audit_events (action, occurred_at);
CREATE INDEX idx_audit_actor ON audit_events (actor_user_id, occurred_at);
