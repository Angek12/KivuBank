'use strict';
/* KivuBank web UI (vanilla JS, no external dependencies, no innerHTML with data => XSS-safe by construction).
   The token is kept in sessionStorage (cleared when the tab closes). */
const state = { token: sessionStorage.getItem('kb_token'), user: JSON.parse(sessionStorage.getItem('kb_user') || 'null'), page: null };
const $ = (s) => document.querySelector(s);

function el(tag, props, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') n.className = v;
    else if (k === 'text') n.textContent = v;
    else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
    else if (k === 'value') n.value = v;
    else n.setAttribute(k, v === true ? '' : v);
  }
  for (const c of kids.flat()) if (c !== null && c !== undefined && c !== false) n.append(c.nodeType ? c : document.createTextNode(String(c)));
  return n;
}
const fmt = (n, cur) => (n === null || n === undefined ? '-' : Number(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + (cur ? ' ' + cur : ''));
const when = (t) => (t ? new Date(t).toLocaleString() : '-');
const badge = (v) => el('span', { class: 'badge b-' + v, text: v });
const isStaff = () => state.user && state.user.role !== 'CUSTOMER';
const isAdmin = () => state.user && state.user.role === 'ADMIN';

function toast(msg, kind) {
  const t = el('div', { class: 'toast ' + (kind || ''), text: msg });
  $('#toasts').append(t);
  setTimeout(() => t.remove(), 5000);
}
class ApiProblem extends Error { constructor(m, status, body) { super(m); this.status = status; this.body = body; } }

async function api(path, { method = 'GET', body, headers = {}, text = false } = {}) {
  const h = { ...headers };
  if (body !== undefined) h['Content-Type'] = 'application/json';
  if (state.token) h.Authorization = 'Bearer ' + state.token;
  let res;
  try { res = await fetch(path, { method, headers: h, body: body !== undefined ? JSON.stringify(body) : undefined }); }
  catch (e) { throw new ApiProblem('Network error - check your connection and retry.', 0); }
  if (res.status === 401 && state.token && !path.includes('/auth/login')) { logout(); throw new ApiProblem('Session expired. Please sign in again.', 401); }
  const raw = await res.text();
  let data = null;
  if (raw && !text) { try { data = JSON.parse(raw); } catch (e) { data = null; } }
  if (!res.ok) {
    const isTx = data && data.reference && data.status; // FAILED transactions come back as 422 with a transaction body
    if (!isTx) {
      let msg = (data && data.message) || ('Request failed (' + res.status + ')');
      if (data && data.violations) msg += ': ' + data.violations.map((v) => v.field + ' ' + v.message).join('; ');
      throw new ApiProblem(msg, res.status, data);
    }
  }
  return { status: res.status, data: text ? raw : data, headers: res.headers };
}
const guard = (fn) => async (...a) => { try { return await fn(...a); } catch (e) { if (e instanceof ApiProblem) toast(e.message, 'err'); else { console.error(e); toast('Unexpected error', 'err'); } } };

function setSession(token, user) {
  state.token = token; state.user = user;
  if (token) { sessionStorage.setItem('kb_token', token); sessionStorage.setItem('kb_user', JSON.stringify(user)); }
  else { sessionStorage.removeItem('kb_token'); sessionStorage.removeItem('kb_user'); }
}
function logout() { if (state.token) { fetch('/api/auth/logout', { method: 'POST', headers: { Authorization: 'Bearer ' + state.token } }).catch(() => {}); } setSession(null, null); render(); }

function field(label, input) { return el('label', {}, label, input); }
function table(headers, rows, onRow) {
  return el('div', { class: 'tablewrap' }, el('table', {}, el('thead', {}, el('tr', {}, headers.map((h) => el('th', { text: h })))),
    el('tbody', {}, rows.length ? rows.map((r) => el('tr', { class: onRow ? 'click' : '', onclick: onRow ? () => onRow(r) : null }, r.cells.map((c) => el('td', {}, c)))) : [el('tr', {}, el('td', { colspan: headers.length, class: 'muted', text: 'No data' }))])));
}
function pager(p, load) {
  return el('div', { class: 'pager' }, el('span', { class: 'muted small', text: `Page ${p.page + 1} of ${Math.max(p.totalPages, 1)} (${p.totalElements} total)` }),
    el('button', { class: 'btn ghost', disabled: p.page <= 0, onclick: () => load(p.page - 1), text: 'Prev' }),
    el('button', { class: 'btn ghost', disabled: p.page + 1 >= p.totalPages, onclick: () => load(p.page + 1), text: 'Next' }));
}
function modal(title, body) {
  const bg = el('div', { class: 'modal-bg', onclick: (e) => { if (e.target === bg) bg.remove(); } },
    el('div', { class: 'modal', role: 'dialog', 'aria-label': title }, el('h2', { text: title }), body, el('div', { class: 'row', style: 'margin-top:1rem' }, el('button', { class: 'btn ghost', onclick: () => bg.remove(), text: 'Close' }))));
  document.body.append(bg);
  return bg;
}
function kv(obj) { return el('dl', { class: 'kv' }, Object.entries(obj).filter(([, v]) => v !== null && v !== undefined && v !== '').flatMap(([k, v]) => [el('dt', { text: k }), el('dd', {}, v.nodeType ? v : String(v))])); }
const qs = (o) => { const p = new URLSearchParams(); Object.entries(o).forEach(([k, v]) => { if (v !== '' && v !== undefined && v !== null) p.set(k, v); }); const s = p.toString(); return s ? '?' + s : ''; };
const isoFromLocal = (v) => (v ? new Date(v).toISOString() : '');

/* ------------------------------ authentication ------------------------------ */
function authView() {
  let mode = 'login';
  const box = el('div', { class: 'card auth' });
  function draw() {
    const email = el('input', { type: 'text', autocomplete: 'username', required: true, placeholder: 'e-mail or account number' });
    const pass = el('input', { type: 'password', autocomplete: mode === 'login' ? 'current-password' : 'new-password', required: true });
    const name = el('input', { type: 'text', autocomplete: 'name', required: true });
    const phone = el('input', { type: 'tel', autocomplete: 'tel', required: true, placeholder: '+14155552671' });
    const form = el('form', { class: 'stack', onsubmit: guard(async (e) => {
      e.preventDefault();
      if (mode === 'register') {
        await api('/api/auth/register', { method: 'POST', body: { fullName: name.value, email: email.value, phone: phone.value, password: pass.value } });
        toast('Registered. You can sign in now.', 'ok'); mode = 'login'; draw(); return;
      }
      const r = await api('/api/auth/login', { method: 'POST', body: { identifier: email.value, password: pass.value } });
      setSession(r.data.accessToken, r.data.user); state.page = null; render();
    }) },
      mode === 'register' ? field('Full name', name) : null,
      field(mode === 'login' ? 'E-mail or account number' : 'E-mail', email),
      mode === 'register' ? field('Phone (international format)', phone) : null,
      field('Password', pass),
      mode === 'register' ? el('p', { class: 'muted small', text: 'At least 10 characters with upper and lower case, a digit and a symbol.' }) : null,
      el('button', { class: 'btn', type: 'submit', text: mode === 'login' ? 'Sign in' : 'Create simulated account' }));
    box.replaceChildren(el('h1', { text: 'KivuBank' }), el('p', { class: 'center muted', text: 'Simulated digital banking platform' }),
      el('div', { class: 'tabs' }, el('button', { class: mode === 'login' ? 'active' : '', onclick: () => { mode = 'login'; draw(); }, text: 'Sign in' }),
        el('button', { class: mode === 'register' ? 'active' : '', onclick: () => { mode = 'register'; draw(); }, text: 'Register' })), form);
  }
  draw();
  return box;
}

/* ---------------------------------- shell ---------------------------------- */
const customerPages = { Dashboard: customerDashboard, Transactions: customerTransactions, 'Send & receive': moneyPage, Notifications: notificationsPage, 'USSD simulator': ussdPage };
const staffPages = { Overview: opsOverview, Transactions: staffTransactions, Incidents: incidentsPage, 'Audit log': auditPage, 'System health': healthPage, 'Anomalies (experimental)': anomaliesPage, 'Reconciliation (sim)': reconciliationPage, 'Users & accounts': usersPage };

function render() {
  const app = $('#app');
  if (!state.token) { app.replaceChildren(authView()); return; }
  const pages = isStaff() ? staffPages : customerPages;
  if (!state.page || !pages[state.page]) state.page = Object.keys(pages)[0];
  const main = el('main', { class: 'main' });
  const nav = el('nav', { class: 'nav' }, Object.keys(pages).map((p) => el('button', { class: p === state.page ? 'active' : '', onclick: () => { state.page = p; render(); }, text: p })),
    el('button', { onclick: logout, text: 'Sign out' }));
  app.replaceChildren(el('div', { class: 'shell' }, el('aside', { class: 'side' }, el('div', { class: 'brand', text: 'KivuBank' }),
    el('div', { class: 'who' }, state.user.fullName, el('br'), el('span', { class: 'badge', text: state.user.role })), nav), main));
  main.replaceChildren(el('p', { class: 'muted', text: 'Loading...' }));
  guard(async () => { main.replaceChildren(await pages[state.page]()); })();
}

/* -------------------------------- customer -------------------------------- */
async function customerDashboard() {
  const [acc, tx, unread] = await Promise.all([api('/api/accounts/me'), api('/api/transactions?size=5'), api('/api/notifications/unread-count')]);
  const a = acc.data;
  const wrap = el('div', {}, el('h1', { text: 'Dashboard' }),
    el('div', { class: 'grid' },
      el('div', { class: 'card stat' }, el('div', { class: 'l', text: 'Available balance' }), el('div', { class: 'v', text: fmt(a.balance, a.currency) }), el('div', { class: 'muted small mono', text: 'Account ' + a.accountNumber })),
      el('div', { class: 'card stat' }, el('div', { class: 'l', text: 'Account status' }), el('div', { class: 'v' }, badge(a.status === 'ACTIVE' ? 'UP' : 'DOWN')), el('div', { class: 'muted small', text: a.status })),
      el('div', { class: 'card stat' }, el('div', { class: 'l', text: 'Unread notifications' }), el('div', { class: 'v', text: unread.data.unread }))));
  if (!a.pinSet) wrap.append(pinSetupCard());
  wrap.append(el('div', { class: 'card' }, el('h2', { text: 'Recent transactions' }), txTable(tx.data.content)));
  return wrap;
}
function pinSetupCard() {
  const pin = el('input', { type: 'password', inputmode: 'numeric', pattern: '\\d{4,6}', maxlength: 6, required: true });
  const pw = el('input', { type: 'password', autocomplete: 'current-password', required: true });
  return el('form', { class: 'card stack', onsubmit: guard(async (e) => {
    e.preventDefault();
    await api('/api/accounts/me/pin', { method: 'POST', body: { pin: pin.value, password: pw.value } });
    toast('PIN created', 'ok'); render();
  }) }, el('h2', { text: 'Set your transaction PIN' }), el('p', { class: 'muted small', text: 'A 4-6 digit PIN (not sequential or repeated) is required for every deposit, withdrawal and transfer.' }),
    el('div', { class: 'row' }, field('New PIN', pin), field('Account password', pw), el('button', { class: 'btn', type: 'submit', text: 'Save PIN' })));
}
function txTable(list) {
  return table(['Date', 'Ref', 'Type', 'Direction', 'Amount', 'Status'], list.map((t) => ({ t, cells: [when(t.createdAt), el('span', { class: 'mono', text: t.reference }), t.type, t.direction || '-',
    el('span', { class: t.direction === 'CREDIT' ? 'credit' : t.direction === 'DEBIT' ? 'debit' : '', text: (t.direction === 'DEBIT' ? '-' : t.direction === 'CREDIT' ? '+' : '') + fmt(t.amount, t.currency) }), badge(t.status)] })), (r) => showTx(r.t.reference));
}
const showTx = guard(async (ref) => {
  const t = (await api('/api/transactions/' + encodeURIComponent(ref))).data;
  const body = el('div', {}, kv({ Reference: t.reference, Type: t.type, Status: badge(t.status), Direction: t.direction, Amount: fmt(t.amount, t.currency), From: t.sourceAccountNumber, To: t.targetAccountNumber,
    'Balance after': t.balanceAfter === null || t.balanceAfter === undefined ? null : fmt(t.balanceAfter, t.currency), Channel: t.channel, Description: t.description, 'Failure reason': t.failureReason, Created: when(t.createdAt), Completed: when(t.completedAt) }));
  if (t.status === 'PENDING') body.append(el('p', { class: 'muted small', text: 'This transfer exceeds the review threshold and awaits approval by an administrator.' }),
    el('button', { class: 'btn danger', text: 'Cancel transfer', onclick: guard(async () => { await api('/api/transactions/' + ref + '/cancel', { method: 'POST' }); toast('Cancelled', 'ok'); document.querySelector('.modal-bg')?.remove(); render(); }) }));
  modal('Transaction details', body);
});
async function customerTransactions() {
  const f = { status: '', type: '', from: '', to: '', minAmount: '', maxAmount: '' };
  const holder = el('div');
  const status = el('select', {}, ['', 'PENDING', 'PROCESSING', 'SUCCESS', 'FAILED', 'REVERSED', 'CANCELLED'].map((s) => el('option', { value: s, text: s || 'Any status' })));
  const type = el('select', {}, ['', 'DEPOSIT', 'WITHDRAWAL', 'TRANSFER', 'REVERSAL'].map((s) => el('option', { value: s, text: s || 'Any type' })));
  const from = el('input', { type: 'datetime-local' }), to = el('input', { type: 'datetime-local' });
  const min = el('input', { type: 'number', step: '0.01', min: '0' }), max = el('input', { type: 'number', step: '0.01', min: '0' });
  const load = guard(async (page = 0) => {
    const r = await api('/api/transactions' + qs({ status: status.value, type: type.value, from: isoFromLocal(from.value), to: isoFromLocal(to.value), minAmount: min.value, maxAmount: max.value, page, size: 10 }));
    holder.replaceChildren(txTable(r.data.content), pager(r.data, load));
  });
  const wrap = el('div', {}, el('h1', { text: 'Transactions' }), el('div', { class: 'card' },
    el('div', { class: 'row' }, field('Status', status), field('Type', type), field('From', from), field('To', to), field('Min amount', min), field('Max amount', max), el('button', { class: 'btn', onclick: () => load(0), text: 'Apply' })), holder));
  await load(0);
  return wrap;
}
async function moneyPage() {
  const acc = (await api('/api/accounts/me')).data;
  let mode = 'transfer';
  const box = el('div');
  const keyHolder = { key: crypto.randomUUID() };
  function draw() {
    const amount = el('input', { type: 'number', step: '0.01', min: '0.01', required: true });
    const pin = el('input', { type: 'password', inputmode: 'numeric', pattern: '\\d{4,6}', maxlength: 6, required: true, autocomplete: 'off' });
    const desc = el('input', { type: 'text', maxlength: 200 });
    const target = el('input', { type: 'text', inputmode: 'numeric', pattern: '\\d{6,20}', required: true });
    const lookupOut = el('span', { class: 'muted small' });
    const result = el('div');
    const form = el('form', { class: 'stack', onsubmit: guard(async (e) => {
      e.preventDefault();
      const body = { amount: amount.value, pin: pin.value, description: desc.value || undefined };
      if (mode === 'transfer') body.targetAccountNumber = target.value;
      const r = await api('/api/transactions/' + mode, { method: 'POST', body, headers: { 'Idempotency-Key': keyHolder.key, 'X-Client-Channel': 'WEB' } });
      keyHolder.key = crypto.randomUUID(); // definitive answer received: next submission is a new operation
      const t = r.data;
      const msg = t.status === 'SUCCESS' ? 'Completed' : t.status === 'PENDING' ? 'Submitted - awaiting administrator approval' : 'Failed: ' + (t.failureReason || t.status);
      toast(msg, t.status === 'FAILED' ? 'err' : 'ok');
      result.replaceChildren(el('div', { class: 'card' }, kv({ Reference: t.reference, Status: badge(t.status), Amount: fmt(t.amount, t.currency), 'Balance after': t.balanceAfter == null ? null : fmt(t.balanceAfter, t.currency), Replayed: r.headers.get('Idempotent-Replayed') === 'true' ? 'yes (idempotent replay)' : null })));
      pin.value = '';
    }) },
      mode === 'transfer' ? el('div', { class: 'row' }, field('Recipient account number', target), el('button', { class: 'btn ghost', type: 'button', text: 'Verify', onclick: guard(async () => {
        const r = await api('/api/accounts/lookup/' + encodeURIComponent(target.value)); lookupOut.textContent = r.data.ownerNameMasked + ' (' + r.data.currency + ')'; }) }), lookupOut) : null,
      el('div', { class: 'row' }, field('Amount (' + acc.currency + ')', amount), field('PIN', pin), field('Description (optional)', desc)),
      el('button', { class: 'btn', type: 'submit', text: mode[0].toUpperCase() + mode.slice(1) }),
      el('p', { class: 'muted small', text: 'Each submission carries an Idempotency-Key, so a retry or double click cannot move money twice. Transfers at or above the review threshold wait for administrator approval.' }));
    box.replaceChildren(el('div', { class: 'tabs' }, ['transfer', 'deposit', 'withdraw'].map((m) => el('button', { class: m === mode ? 'active' : '', onclick: () => { mode = m; keyHolder.key = crypto.randomUUID(); draw(); }, text: m[0].toUpperCase() + m.slice(1) }))), form, result);
  }
  draw();
  const stmt = el('button', { class: 'btn ghost', text: 'Download 30-day statement (CSV)', onclick: guard(async () => {
    const r = await api('/api/accounts/me/statement', { text: true });
    const a = el('a', { href: URL.createObjectURL(new Blob([r.data], { type: 'text/csv' })), download: 'kivubank-statement.csv' }); document.body.append(a); a.click(); a.remove(); toast('Statement generated', 'ok');
  }) });
  return el('div', {}, el('h1', { text: 'Send & receive' }), el('p', { class: 'muted', text: 'Balance: ' + fmt(acc.balance, acc.currency) + ' - account ' + acc.accountNumber }), el('div', { class: 'card' }, box), el('div', { class: 'card' }, el('h2', { text: 'Statement' }), stmt));
}
async function notificationsPage() {
  const holder = el('div');
  const load = guard(async (page = 0) => {
    const r = (await api('/api/notifications?size=15&page=' + page)).data;
    holder.replaceChildren(...r.content.map((n) => el('div', { class: 'alert' }, el('strong', { text: n.subject }), n.read ? null : el('span', { class: 'badge b-INFO', text: 'new', style: 'margin-left:.5rem' }), el('div', { text: n.body }),
      el('div', { class: 'muted small', text: when(n.createdAt) + ' - ' + n.type }), n.read ? null : el('button', { class: 'btn ghost', text: 'Mark read', onclick: guard(async () => { await api('/api/notifications/' + n.id + '/read', { method: 'POST' }); load(page); }) }))),
      r.content.length ? null : el('p', { class: 'muted', text: 'No notifications yet.' }), pager(r, load));
  });
  await load(0);
  return el('div', {}, el('h1', { text: 'Notifications' }), el('p', { class: 'muted small', text: 'E-mail/SMS copies are produced by a simulated provider in local development.' }), el('div', { class: 'card' }, holder));
}
async function ussdPage() {
  const phone = el('input', { type: 'tel', value: state.user.phone });
  const screen = el('pre', { text: 'Press "Dial *123#" to start.' });
  const input = el('input', { type: 'text', autocomplete: 'off', placeholder: 'reply' });
  const send = el('button', { class: 'btn', text: 'Send', disabled: true });
  let parts = [], session = null;
  const call = guard(async () => {
    const r = (await api('/api/ussd/session', { method: 'POST', body: { sessionId: session, serviceCode: '*123#', phoneNumber: phone.value, text: parts.join('*') } })).data;
    screen.textContent = r.message; send.disabled = r.sessionEnded; if (r.sessionEnded) session = null; input.value = ''; input.focus();
  });
  const dial = el('button', { class: 'btn', text: 'Dial *123#', onclick: () => { session = 'ui-' + crypto.randomUUID().slice(0, 12); parts = []; send.disabled = false; call(); } });
  send.addEventListener('click', () => { if (!session) return; parts.push(input.value); call(); });
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') send.click(); });
  return el('div', {}, el('h1', {}, 'USSD simulator', el('span', { class: 'pill-sim', text: 'SIMULATED' })),
    el('p', { class: 'muted', text: 'Calls the same services as the REST API (PIN lockout, idempotent transfers). Not connected to any telecom operator.' }),
    el('div', { class: 'card' }, el('div', { class: 'phone' }, field('Subscriber number', phone), screen, input, el('div', { class: 'row', style: 'margin-top:.6rem' }, dial, send))));
}

/* --------------------------- staff / operations --------------------------- */
function stat(label, value, sub) { return el('div', { class: 'card stat' }, el('div', { class: 'l', text: label }), el('div', { class: 'v', text: value }), sub ? el('div', { class: 'muted small', text: sub }) : null); }
function trendChart(points) {
  const max = Math.max(1, ...points.map((p) => p.success + p.failed + p.other));
  return el('div', {}, el('div', { class: 'bars', role: 'img', 'aria-label': 'Hourly transactions, last 24 hours' }, points.map((p) => {
    const tot = p.success + p.failed + p.other;
    return el('div', { class: 'col', title: `${new Date(p.hour).getHours()}:00  ok ${p.success}  failed ${p.failed}  other ${p.other}`, style: `height:${(tot / max) * 100}%` },
      el('div', { class: 's', style: `flex:${p.success}` }), el('div', { class: 'f', style: `flex:${p.failed}` }), el('div', { class: 'o', style: `flex:${p.other}` }));
  })), el('div', { class: 'legend' }, el('span', {}, el('i', { style: 'background:var(--ok)' }), 'success'), el('span', {}, el('i', { style: 'background:var(--bad)' }), 'failed'), el('span', {}, el('i', { style: 'background:var(--warn)' }), 'pending/other')));
}
async function opsOverview() {
  const [d, trend] = await Promise.all([api('/api/ops/dashboard'), api('/api/ops/transactions/trend?hours=24')]);
  const x = d.data, t = x.transactions;
  const total = Math.max(t.total, 1);
  return el('div', {}, el('h1', {}, 'Operations overview', el('span', { class: 'pill-sim', text: 'SIMULATED DATA' })), el('p', { class: 'muted small', text: x.dataDisclosure }),
    el('div', { class: 'grid' },
      stat('API health', x.health.status, 'DB latency ' + x.health.databaseLatencyMs + ' ms'), stat('Uptime', Math.floor(x.health.uptimeSeconds / 60) + ' min', 'since ' + when(x.health.startedAt)),
      stat('Transactions', t.total, t.last24hTotal + ' in last 24h'), stat('Success rate', t.successRateAllTime == null ? 'n/a' : t.successRateAllTime + '%', '24h: ' + (t.successRateLast24h == null ? 'n/a' : t.successRateLast24h + '%')),
      stat('Failed', t.byStatus.FAILED), stat('Pending review', t.byStatus.PENDING), stat('Avg response', x.http.averageResponseMs + ' ms', x.http.totalRequests + ' API requests'),
      stat('Active users (30 min)', x.users.activeUsersLast30Min, x.users.customers + ' customers'), stat('Open incidents', x.openIncidents), stat('Flagged (24h, exp.)', x.flaggedAnomalies24h)),
    el('div', { class: 'card' }, el('h2', { text: 'System alerts' }), x.alerts.length ? x.alerts.map((a) => el('div', { class: 'alert ' + a.level }, badge(a.level), ' ' + a.message)) : el('p', { class: 'muted', text: 'No active alerts.' })),
    el('div', { class: 'card' }, el('h2', { text: 'Transactions per hour (last 24h)' }), trendChart(trend.data)),
    el('div', { class: 'card' }, el('h2', { text: 'Transactions by status' }), Object.entries(t.byStatus).map(([s, n]) => el('div', { style: 'margin-bottom:.5rem' }, el('div', { class: 'small' }, badge(s), ' ' + n), el('div', { class: 'hbar' }, el('span', { style: `width:${(n / total) * 100}%` }))))),
    el('div', { class: 'card' }, el('h2', { text: 'Recent incidents' }), table(['ID', 'Title', 'Severity', 'Status', 'Service'], x.recentIncidents.map((i) => ({ cells: [i.incidentId, i.title, badge(i.severity), badge(i.status), i.affectedService] })))),
    el('div', { class: 'card' }, el('h2', { text: 'Recent audit events' }), table(['Time', 'Action', 'Outcome', 'Actor', 'Target'], x.recentAuditEvents.map((e) => ({ cells: [when(e.occurredAt), e.action, badge(e.outcome === 'SUCCESS' ? 'UP' : 'DOWN'), e.actorEmail || '-', (e.targetType || '') + ' ' + (e.targetId || '')] })))));
}
async function staffTransactions() {
  const holder = el('div');
  const status = el('select', {}, ['', 'PENDING', 'PROCESSING', 'SUCCESS', 'FAILED', 'REVERSED', 'CANCELLED'].map((s) => el('option', { value: s, text: s || 'Any status' })));
  const ref = el('input', { type: 'text', placeholder: 'reference' });
  const load = guard(async (page = 0) => {
    const r = (await api('/api/admin/transactions' + qs({ status: status.value, reference: ref.value, page, size: 15 }))).data;
    holder.replaceChildren(table(['Date', 'Ref', 'Type', 'From', 'To', 'Amount', 'Status'], r.content.map((t) => ({ t, cells: [when(t.createdAt), el('span', { class: 'mono', text: t.reference }), t.type, t.sourceAccountNumber || '-', t.targetAccountNumber || '-', fmt(t.amount, t.currency), badge(t.status)] })), (row) => staffTxDetail(row.t, load, page)), pager(r, load));
  });
  await load(0);
  return el('div', {}, el('h1', { text: 'Transactions' }), el('div', { class: 'card' }, el('div', { class: 'row' }, field('Status', status), field('Reference', ref), el('button', { class: 'btn', onclick: () => load(0), text: 'Search' })), holder));
}
function staffTxDetail(t, reload, page) {
  const body = el('div', {}, kv({ Reference: t.reference, Type: t.type, Status: badge(t.status), Amount: fmt(t.amount, t.currency), From: t.sourceAccountNumber, To: t.targetAccountNumber, Channel: t.channel, Description: t.description, 'Failure reason': t.failureReason, Created: when(t.createdAt), Completed: when(t.completedAt) }));
  const m = modal('Transaction', body);
  if (isAdmin() && t.status === 'PENDING') body.append(el('button', { class: 'btn', style: 'margin-top:1rem', text: 'Approve', onclick: guard(async () => { await api('/api/admin/transactions/' + t.reference + '/approve', { method: 'POST' }); toast('Approved', 'ok'); m.remove(); reload(page); }) }));
  if (isAdmin() && t.status === 'SUCCESS') {
    const reason = el('input', { type: 'text', placeholder: 'reason for reversal', maxlength: 200 });
    body.append(el('div', { class: 'row', style: 'margin-top:1rem' }, reason, el('button', { class: 'btn danger', text: 'Reverse', onclick: guard(async () => { await api('/api/admin/transactions/' + t.reference + '/reverse', { method: 'POST', body: { reason: reason.value } }); toast('Reversed', 'ok'); m.remove(); reload(page); }) })));
  }
}
async function incidentsPage() {
  const holder = el('div');
  const status = el('select', {}, ['', 'OPEN', 'INVESTIGATING', 'MITIGATED', 'RESOLVED', 'CLOSED'].map((s) => el('option', { value: s, text: s || 'Any status' })));
  const load = guard(async (page = 0) => {
    const r = (await api('/api/incidents' + qs({ status: status.value, page, size: 10 }))).data;
    holder.replaceChildren(table(['ID', 'Title', 'Severity', 'Status', 'Service', 'Assignee', 'Updated'], r.content.map((i) => ({ i, cells: [i.incidentId, i.title, badge(i.severity), badge(i.status), i.affectedService, i.assignee || '-', when(i.updatedAt)] })), (row) => incidentDetail(row.i, load, page)), pager(r, load));
  });
  await load(0);
  const canEdit = state.user.role !== 'AUDITOR';
  return el('div', {}, el('h1', { text: 'Incidents' }), canEdit ? incidentCreateCard(load) : null, el('div', { class: 'card' }, el('div', { class: 'row' }, field('Status', status), el('button', { class: 'btn', onclick: () => load(0), text: 'Filter' })), holder));
}
const SERVICES = ['API', 'DATABASE', 'AUTHENTICATION', 'TRANSACTIONS', 'NOTIFICATIONS', 'RECONCILIATION', 'USSD', 'DASHBOARD', 'OTHER'];
const SEVS = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];
function opts(list) { return list.map((s) => el('option', { value: s, text: s })); }
function incidentCreateCard(reload) {
  const title = el('input', { type: 'text', required: true, maxlength: 150 }), desc = el('textarea', { required: true, maxlength: 2000, rows: 2 });
  const sev = el('select', {}, opts(SEVS)), svc = el('select', {}, opts(SERVICES)), who = el('input', { type: 'text', maxlength: 120, placeholder: 'person or team' });
  return el('form', { class: 'card', onsubmit: guard(async (e) => { e.preventDefault(); await api('/api/incidents', { method: 'POST', body: { title: title.value, description: desc.value, severity: sev.value, affectedService: svc.value, assignee: who.value } }); toast('Incident opened', 'ok'); e.target.reset(); reload(0); }) },
    el('h2', { text: 'Open an incident' }), el('div', { class: 'row' }, field('Title', title), field('Severity', sev), field('Affected service', svc), field('Assignee', who)), field('Description', desc), el('button', { class: 'btn', type: 'submit', style: 'margin-top:.6rem', text: 'Open incident' }));
}
function incidentDetail(i, reload, page) {
  const canEdit = state.user.role !== 'AUDITOR' && i.status !== 'CLOSED';
  const status = el('select', {}, opts(['OPEN', 'INVESTIGATING', 'MITIGATED', 'RESOLVED', 'CLOSED'])); status.value = i.status;
  const assignee = el('input', { type: 'text', value: i.assignee || '' }), res = el('textarea', { rows: 2, maxlength: 2000 }), root = el('textarea', { rows: 2, maxlength: 2000 });
  res.value = i.resolution || ''; root.value = i.rootCause || '';
  const body = el('div', { class: 'stack' }, kv({ ID: i.incidentId, Title: i.title, Description: i.description, Severity: badge(i.severity), Service: i.affectedService, Created: when(i.createdAt), Updated: when(i.updatedAt), Resolved: i.resolvedAt ? when(i.resolvedAt) : null, Closed: i.closedAt ? when(i.closedAt) : null }));
  const m = modal(i.incidentId, body);
  if (canEdit) body.append(field('Status', status), field('Assignee', assignee), field('Resolution', res), field('Root cause', root),
    el('button', { class: 'btn', text: 'Save', onclick: guard(async () => { await api('/api/incidents/' + i.id, { method: 'PATCH', body: { status: status.value, assignee: assignee.value, resolution: res.value, rootCause: root.value } }); toast('Incident updated', 'ok'); m.remove(); reload(page); }) }));
  else body.append(kv({ Resolution: i.resolution, 'Root cause': i.rootCause, Assignee: i.assignee }));
}
async function auditPage() {
  const holder = el('div');
  const ACTIONS = ['', 'LOGIN_SUCCESS', 'LOGIN_FAILURE', 'LOGOUT', 'ACCOUNT_CREATED', 'PASSWORD_CHANGED', 'PIN_CREATED', 'PIN_CHANGED', 'PIN_FAILED', 'PIN_LOCKED', 'DEPOSIT', 'WITHDRAWAL', 'TRANSFER_CREATED', 'TRANSFER_COMPLETED', 'TRANSFER_FAILED', 'TRANSACTION_CANCELLED', 'TRANSACTION_APPROVED', 'TRANSACTION_REVERSED', 'STATEMENT_GENERATED', 'ADMIN_USER_CREATED', 'ADMIN_USER_STATUS_CHANGED', 'ADMIN_ACCOUNT_FROZEN', 'ADMIN_ACCOUNT_UNFROZEN', 'INCIDENT_CREATED', 'INCIDENT_UPDATED', 'RECONCILIATION_RUN', 'PROVIDER_SIMULATION', 'ANOMALY_FLAGGED'];
  const action = el('select', {}, ACTIONS.map((a) => el('option', { value: a, text: a || 'Any action' })));
  const outcome = el('select', {}, ['', 'SUCCESS', 'FAILURE'].map((a) => el('option', { value: a, text: a || 'Any outcome' })));
  const actor = el('input', { type: 'text', placeholder: 'actor e-mail contains' });
  const load = guard(async (page = 0) => {
    const r = (await api('/api/admin/audit-events' + qs({ action: action.value, outcome: outcome.value, actor: actor.value, page, size: 20 }))).data;
    holder.replaceChildren(table(['Time', 'Action', 'Outcome', 'Actor', 'Target', 'IP', 'Details'], r.content.map((e) => ({ cells: [when(e.occurredAt), e.action, badge(e.outcome === 'SUCCESS' ? 'UP' : 'DOWN'), e.actorEmail || '-', (e.targetType || '') + ' ' + (e.targetId || ''), e.ipAddress || '-', e.details || ''] })), null), pager(r, load));
  });
  await load(0);
  return el('div', {}, el('h1', { text: 'Audit log' }), el('div', { class: 'card' }, el('div', { class: 'row' }, field('Action', action), field('Outcome', outcome), field('Actor', actor), el('button', { class: 'btn', onclick: () => load(0), text: 'Search' })), holder));
}
async function healthPage() {
  const [h, m] = await Promise.all([api('/api/ops/health'), api('/api/ops/metrics')]);
  const http = m.data.http, jvm = m.data.jvm;
  return el('div', {}, el('h1', { text: 'System health' }),
    el('div', { class: 'grid' }, stat('Overall', h.data.status), stat('DB round trip', h.data.databaseLatencyMs + ' ms'), stat('Uptime', Math.floor(h.data.uptimeSeconds / 60) + ' min'),
      stat('Heap', jvm.heapUsedMb + ' / ' + jvm.heapMaxMb + ' MB'), stat('Threads', jvm.liveThreads), stat('CPUs', jvm.processors)),
    el('div', { class: 'card' }, el('h2', { text: 'Components' }), table(['Component', 'Status'], h.data.components.map((c) => ({ cells: [c.name, badge(c.status)] })))),
    el('div', { class: 'card' }, el('h2', { text: 'HTTP (API requests since start)' }), el('div', { class: 'grid' }, stat('Requests', http.totalRequests), stat('Avg response', http.averageResponseMs + ' ms'), stat('Max response', http.maxResponseMs + ' ms'), stat('4xx / 5xx', http.clientErrors + ' / ' + http.serverErrors), stat('Error rate', http.errorRatePercent + '%')),
      el('h3', { text: 'Slowest endpoints (mean)' }), table(['Endpoint', 'Requests', 'Mean ms', 'Max ms'], http.slowestEndpoints.map((e) => ({ cells: [e.uri, e.requests, e.meanMs, e.maxMs] })))),
    el('p', { class: 'muted small', text: 'Raw Actuator endpoints: /actuator/health (public), /actuator/metrics and /actuator/prometheus (ADMIN).' }));
}
async function anomaliesPage() {
  const [model, list] = await Promise.all([api('/api/admin/anomalies/model'), api('/api/admin/anomalies?flaggedOnly=false&size=15')]);
  const mi = model.data, v = mi.validation;
  const out = el('div');
  const f = { amount: el('input', { type: 'number', value: '250000' }), typical: el('input', { type: 'number', value: '15000' }), hour: el('input', { type: 'number', min: 0, max: 23, value: '3' }), last: el('input', { type: 'number', min: 0, value: '1' }), type: el('select', {}, opts(['TRANSFER', 'WITHDRAWAL'])), newr: el('select', {}, [el('option', { value: 'true', text: 'new recipient' }), el('option', { value: 'false', text: 'known recipient' })]), frac: el('input', { type: 'number', step: '0.05', min: 0, max: 1, value: '0.85' }) };
  const evalBtn = el('button', { class: 'btn', text: 'Score', onclick: guard(async () => {
    const r = (await api('/api/admin/anomalies/evaluate', { method: 'POST', body: { amount: f.amount.value, typicalAmount: f.typical.value, hourUtc: Number(f.hour.value), transactionsLastHour: Number(f.last.value), type: f.type.value, newRecipient: f.newr.value === 'true', balanceFraction: Number(f.frac.value) } })).data;
    out.replaceChildren(el('div', { class: 'alert ' + (r.flagged ? 'HIGH' : 'INFO') }, el('strong', { text: 'Score ' + r.score + (r.flagged ? ' - FLAGGED' : ' - not flagged') }), r.reasons.map((x) => el('div', { text: '- ' + x }))));
  }) });
  return el('div', {}, el('h1', {}, 'Anomaly monitoring', el('span', { class: 'pill-sim', text: 'EXPERIMENTAL' })), el('div', { class: 'alert WARNING', text: mi.disclaimer }),
    el('div', { class: 'card' }, el('h2', { text: 'Model' }), kv({ Version: mi.modelVersion, 'Trained on': mi.trainedOn, Trees: mi.trees, 'Training rows': mi.trainingRows, Threshold: mi.threshold.toFixed(4), 'Synthetic validation': `precision ${v.precision}, recall ${v.recall}, F1 ${v.f1} (${v.normalRows} normal + ${v.anomalousRows} anomalous held-out rows)` })),
    el('div', { class: 'card' }, el('h2', { text: 'What-if scoring' }), el('div', { class: 'row' }, field('Amount', f.amount), field('Usual amount', f.typical), field('Hour (UTC)', f.hour), field('Tx last hour', f.last), field('Type', f.type), field('Recipient', f.newr), field('Balance fraction', f.frac), evalBtn), out),
    el('div', { class: 'card' }, el('h2', { text: 'Assessed transactions' }), table(['Time', 'Reference', 'Score', 'Flag', 'Why'], list.data.content.map((a) => ({ cells: [when(a.createdAt), el('span', { class: 'mono', text: a.transactionReference }), a.score.toFixed(3), badge(a.flagged ? 'HIGH' : 'LOW'), a.reasons.join(' ')] })))));
}
async function reconciliationPage() {
  const runs = el('div'), items = el('div');
  const sim = { drop: el('input', { type: 'number', step: '0.05', min: 0, max: 1, value: '0.1' }), dup: el('input', { type: 'number', step: '0.05', min: 0, max: 1, value: '0.1' }), drift: el('input', { type: 'number', step: '0.05', min: 0, max: 1, value: '0.1' }), flip: el('input', { type: 'number', step: '0.05', min: 0, max: 1, value: '0.1' }), orphans: el('input', { type: 'number', min: 0, max: 50, value: '1' }) };
  const loadRuns = guard(async () => {
    const r = (await api('/api/admin/reconciliation/runs?size=8')).data;
    runs.replaceChildren(table(['Run', 'Started', 'Internal', 'External', 'Matched', 'Missing ext.', 'Missing int.', 'Amount', 'Dup.', 'Status'], r.content.map((x) => ({ x, cells: ['#' + x.id, when(x.startedAt), x.internalCount, x.externalCount, x.matched, x.missingExternal, x.missingInternal, x.amountMismatch, x.duplicates, x.statusMismatch] })), (row) => loadItems(row.x.id)));
  });
  const loadItems = guard(async (id) => {
    const r = (await api('/api/admin/reconciliation/runs/' + id + '/items?size=100')).data;
    items.replaceChildren(el('h3', { text: 'Run #' + id + ' items' }), table(['Category', 'Internal ref', 'Provider ref', 'Internal amt', 'External amt', 'Internal -> provider status', 'Note'],
      r.content.map((i) => ({ cells: [badge(i.category === 'MATCHED' ? 'MATCHED' : 'WARNING'), i.internalReference || '-', i.providerReference || '-', fmt(i.internalAmount), fmt(i.externalAmount), (i.internalStatus || '-') + ' -> ' + (i.externalStatus || '-'), (i.category === 'MATCHED' ? '' : i.category + '. ') + (i.note || '')] }))));
  });
  await loadRuns();
  const adminOnly = isAdmin();
  return el('div', {}, el('h1', {}, 'Reconciliation', el('span', { class: 'pill-sim', text: 'SIMULATION' })), el('p', { class: 'muted', text: 'Compares KivuBank transactions with a simulated external provider ledger. No real provider is contacted.' }),
    adminOnly ? el('div', { class: 'card' }, el('h2', { text: '1. Simulate provider settlement (with fault injection)' }), el('div', { class: 'row' }, field('Drop rate', sim.drop), field('Duplicate rate', sim.dup), field('Amount drift rate', sim.drift), field('Status flip rate', sim.flip), field('Provider-only orphans', sim.orphans),
      el('button', { class: 'btn', text: 'Simulate settlement', onclick: guard(async () => { const r = (await api('/api/admin/reconciliation/simulate-settlement', { method: 'POST', body: { dropRate: +sim.drop.value, duplicateRate: +sim.dup.value, amountDriftRate: +sim.drift.value, statusFlipRate: +sim.flip.value, timeoutRate: 0.05, orphanCount: +sim.orphans.value } })).data; toast(`Provider ledger: ${r.submitted} submitted, ${r.dropped} dropped, ${r.duplicated} duplicated`, 'ok'); }) })),
      el('h2', { text: '2. Reconcile' }), el('button', { class: 'btn', text: 'Run reconciliation (last 24h)', onclick: guard(async () => { const r = (await api('/api/admin/reconciliation/runs', { method: 'POST', body: {} })).data; toast('Run #' + r.id + ' complete', 'ok'); await loadRuns(); await loadItems(r.id); }) })) : null,
    el('div', { class: 'card' }, el('h2', { text: 'Runs' }), runs, items));
}
async function usersPage() {
  const holder = el('div');
  const load = guard(async (page = 0) => {
    const [u, a] = await Promise.all([isAdmin() || state.user.role === 'AUDITOR' ? api('/api/admin/users?size=10&page=' + page) : Promise.resolve({ data: { content: [], page: 0, totalPages: 0, totalElements: 0 } }), api('/api/admin/accounts?size=10&page=' + page)]);
    holder.replaceChildren(el('h2', { text: 'Users' }), table(['ID', 'Name', 'E-mail', 'Role', 'Status', 'Last login', ''], u.data.content.map((x) => ({ cells: [x.id, x.fullName, x.email, x.role, badge(x.status === 'ACTIVE' ? 'UP' : 'DOWN'), when(x.lastLoginAt),
      isAdmin() && x.id !== state.user.id ? el('button', { class: 'btn ghost', text: x.status === 'ACTIVE' ? 'Disable' : 'Enable', onclick: guard(async (e) => { e.stopPropagation(); await api('/api/admin/users/' + x.id + '/status', { method: 'PATCH', body: { status: x.status === 'ACTIVE' ? 'DISABLED' : 'ACTIVE' } }); load(page); }) }) : ''] }))), pager(u.data, load),
      el('h2', { text: 'Accounts' }), table(['Account', 'Owner', 'Balance', 'Status', ''], a.data.content.map((x) => ({ cells: [x.accountNumber, x.ownerName, fmt(x.balance, x.currency), badge(x.status === 'ACTIVE' ? 'UP' : 'DOWN'),
        isAdmin() ? el('button', { class: 'btn ghost', text: x.status === 'FROZEN' ? 'Unfreeze' : 'Freeze', onclick: guard(async () => { await api('/api/admin/accounts/' + x.accountNumber + (x.status === 'FROZEN' ? '/unfreeze' : '/freeze'), { method: 'POST' }); load(page); }) }) : ''] }))), pager(a.data, load));
  });
  await load(0);
  const staffForm = isAdmin() ? (() => {
    const n = el('input', { type: 'text', required: true }), e = el('input', { type: 'email', required: true }), p = el('input', { type: 'tel', required: true, placeholder: '+14155552671' }), pw = el('input', { type: 'password', required: true, autocomplete: 'new-password' }), r = el('select', {}, opts(['SUPPORT_AGENT', 'AUDITOR', 'ADMIN']));
    return el('form', { class: 'card', onsubmit: guard(async (ev) => { ev.preventDefault(); await api('/api/admin/users', { method: 'POST', body: { fullName: n.value, email: e.value, phone: p.value, password: pw.value, role: r.value } }); toast('Staff user created', 'ok'); ev.target.reset(); load(0); }) },
      el('h2', { text: 'Create staff user' }), el('div', { class: 'row' }, field('Name', n), field('E-mail', e), field('Phone', p), field('Password', pw), field('Role', r), el('button', { class: 'btn', type: 'submit', text: 'Create' })));
  })() : null;
  return el('div', {}, el('h1', { text: 'Users & accounts' }), staffForm, el('div', { class: 'card' }, holder));
}

render();
