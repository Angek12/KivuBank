package com.kivubank.audit;

public enum AuditOutcome { SUCCESS, FAILURE }
