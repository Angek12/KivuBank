package com.kivubank.audit;

import com.kivubank.user.Role;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "audit_events")
public class AuditEvent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private Instant occurredAt;
    private Long actorUserId;
    private String actorEmail;
    @Enumerated(EnumType.STRING)
    private Role actorRole;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AuditAction action;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AuditOutcome outcome;
    private String targetType;
    private String targetId;
    private String ipAddress;
    private String requestId;
    @Column(length = 500)
    private String details;

    protected AuditEvent() {
    }

    public AuditEvent(Instant occurredAt, Long actorUserId, String actorEmail, Role actorRole, AuditAction action,
                      AuditOutcome outcome, String targetType, String targetId, String ipAddress, String requestId,
                      String details) {
        this.occurredAt = occurredAt;
        this.actorUserId = actorUserId;
        this.actorEmail = actorEmail;
        this.actorRole = actorRole;
        this.action = action;
        this.outcome = outcome;
        this.targetType = targetType;
        this.targetId = targetId;
        this.ipAddress = ipAddress;
        this.requestId = requestId;
        this.details = details == null ? null : (details.length() > 500 ? details.substring(0, 500) : details);
    }

    public Long getId() { return id; }
    public Instant getOccurredAt() { return occurredAt; }
    public Long getActorUserId() { return actorUserId; }
    public String getActorEmail() { return actorEmail; }
    public Role getActorRole() { return actorRole; }
    public AuditAction getAction() { return action; }
    public AuditOutcome getOutcome() { return outcome; }
    public String getTargetType() { return targetType; }
    public String getTargetId() { return targetId; }
    public String getIpAddress() { return ipAddress; }
    public String getRequestId() { return requestId; }
    public String getDetails() { return details; }
}
