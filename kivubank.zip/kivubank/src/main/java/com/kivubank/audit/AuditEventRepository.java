package com.kivubank.audit;

import java.time.Instant;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface AuditEventRepository extends JpaRepository<AuditEvent, Long>, JpaSpecificationExecutor<AuditEvent> {
    List<AuditEvent> findAllByOrderByOccurredAtDesc(Pageable pageable);

    @Query("select count(distinct e.actorUserId) from AuditEvent e where e.action = com.kivubank.audit.AuditAction.LOGIN_SUCCESS and e.occurredAt >= :since")
    long countDistinctLoginsSince(@Param("since") Instant since);

    long countByActionAndOccurredAtAfter(AuditAction action, Instant since);
}
