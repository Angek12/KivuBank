package com.kivubank.audit;

import com.kivubank.common.PageResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.persistence.criteria.Predicate;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/admin/audit-events")
@Tag(name = "Audit", description = "Immutable audit trail of security and financial actions (ADMIN, AUDITOR).")
@SecurityRequirement(name = "bearerAuth")
@PreAuthorize("hasAnyRole('ADMIN','AUDITOR')")
public class AuditController {
    private final AuditEventRepository repository;

    public AuditController(AuditEventRepository repository) {
        this.repository = repository;
    }

    public record AuditEventView(Long id, Instant occurredAt, Long actorUserId, String actorEmail, String actorRole,
                                 AuditAction action, AuditOutcome outcome, String targetType, String targetId,
                                 String ipAddress, String requestId, String details) {
        public static AuditEventView of(AuditEvent e) {
            return new AuditEventView(e.getId(), e.getOccurredAt(), e.getActorUserId(), e.getActorEmail(),
                    e.getActorRole() == null ? null : e.getActorRole().name(), e.getAction(), e.getOutcome(),
                    e.getTargetType(), e.getTargetId(), e.getIpAddress(), e.getRequestId(), e.getDetails());
        }
    }

    @GetMapping
    @Transactional(readOnly = true)
    @Operation(summary = "Search audit events",
            description = "Paginated, newest first. Filter by action, outcome, actor e-mail (contains) and time range.")
    public PageResponse<AuditEventView> search(
            @RequestParam(required = false) AuditAction action,
            @RequestParam(required = false) AuditOutcome outcome,
            @RequestParam(required = false) String actor,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "25") int size) {
        Specification<AuditEvent> spec = (root, q, cb) -> {
            List<Predicate> p = new ArrayList<>();
            if (action != null) p.add(cb.equal(root.get("action"), action));
            if (outcome != null) p.add(cb.equal(root.get("outcome"), outcome));
            if (actor != null && !actor.isBlank()) {
                p.add(cb.like(cb.lower(root.get("actorEmail")), "%" + actor.toLowerCase().replace("%", "") + "%"));
            }
            if (from != null) p.add(cb.greaterThanOrEqualTo(root.get("occurredAt"), from));
            if (to != null) p.add(cb.lessThan(root.get("occurredAt"), to));
            return cb.and(p.toArray(new Predicate[0]));
        };
        var pageable = PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100), Sort.by(Sort.Direction.DESC, "occurredAt"));
        return PageResponse.of(repository.findAll(spec, pageable), AuditEventView::of);
    }
}
