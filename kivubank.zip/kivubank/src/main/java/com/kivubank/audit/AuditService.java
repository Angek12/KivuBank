package com.kivubank.audit;

import com.kivubank.auth.AuthenticatedUser;
import com.kivubank.common.ClientInfo;
import com.kivubank.common.RequestIdFilter;
import com.kivubank.user.Role;
import com.kivubank.user.UserRepository;
import java.time.Clock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

/**
 * Facade for writing audit events. Details must never contain passwords, PINs, tokens or full secrets.
 * A failure to write an audit row is logged loudly but never breaks the user's request.
 */
@Service
public class AuditService {
    private static final Logger log = LoggerFactory.getLogger(AuditService.class);
    private final AuditWriter writer;
    private final UserRepository users;
    private final Clock clock;

    public AuditService(AuditWriter writer, UserRepository users, Clock clock) {
        this.writer = writer;
        this.users = users;
        this.clock = clock;
    }

    /** Records an event attributed to the currently authenticated user (or anonymous if none). */
    public void record(AuditAction action, AuditOutcome outcome, String targetType, String targetId, String details) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.getPrincipal() instanceof AuthenticatedUser u) {
            save(action, outcome, u.id(), u.email(), u.role(), targetType, targetId, details);
        } else {
            save(action, outcome, null, null, null, targetType, targetId, details);
        }
    }

    /** Records an event attributed to a specific user (used by listeners and channels without a security context). */
    public void recordForUser(Long userId, AuditAction action, AuditOutcome outcome, String targetType,
                              String targetId, String details) {
        try {
            var user = userId == null ? null : users.findById(userId).orElse(null);
            if (user != null) {
                save(action, outcome, user.getId(), user.getEmail(), user.getRole(), targetType, targetId, details);
            } else {
                save(action, outcome, userId, null, null, targetType, targetId, details);
            }
        } catch (RuntimeException e) {
            log.error("Failed to resolve actor for audit event {}", action, e);
        }
    }

    /** Records an event where the actor is only known by a (non-secret) label, e.g. a failed login. */
    public void recordAnonymous(AuditAction action, AuditOutcome outcome, String actorLabel, String targetType,
                                String targetId, String details) {
        save(action, outcome, null, actorLabel, null, targetType, targetId, details);
    }

    private void save(AuditAction action, AuditOutcome outcome, Long actorId, String actorEmail, Role role,
                      String targetType, String targetId, String details) {
        try {
            writer.write(new AuditEvent(clock.instant(), actorId, actorEmail, role, action, outcome, targetType,
                    targetId, ClientInfo.currentIp(), MDC.get(RequestIdFilter.MDC_KEY), details));
        } catch (RuntimeException e) {
            log.error("AUDIT WRITE FAILED action={} outcome={} target={}:{}", action, outcome, targetType, targetId, e);
        }
    }
}
