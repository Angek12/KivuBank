package com.kivubank.audit;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/** Persists audit rows in their own transaction so they survive rollbacks of the business transaction. */
@Component
public class AuditWriter {
    private final AuditEventRepository repository;

    public AuditWriter(AuditEventRepository repository) {
        this.repository = repository;
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void write(AuditEvent event) {
        repository.save(event);
    }
}
