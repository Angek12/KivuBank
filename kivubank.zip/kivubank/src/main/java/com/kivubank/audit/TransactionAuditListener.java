package com.kivubank.audit;

import com.kivubank.event.DomainEvents.TransactionOutcomeEvent;
import com.kivubank.transaction.TransactionStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.context.event.EventListener;

/** Writes the final-outcome audit entry only after the money movement has actually committed. */
@Component
public class TransactionAuditListener {
    private static final Logger log = LoggerFactory.getLogger(TransactionAuditListener.class);
    private final AuditService audit;

    public TransactionAuditListener(AuditService audit) {
        this.audit = audit;
    }

    @EventListener
    public void onOutcome(TransactionOutcomeEvent e) {
        try {
            if (e.created() && e.type() == com.kivubank.transaction.TransactionType.TRANSFER) {
                audit.recordForUser(e.initiatedByUserId(), AuditAction.TRANSFER_CREATED, AuditOutcome.SUCCESS, "TRANSACTION",
                        e.reference(), "amount=" + e.amount() + " " + e.currency() + " channel=" + e.channel());
            }
            boolean ok = e.status() == TransactionStatus.SUCCESS;
            AuditAction action = switch (e.type()) {
                case DEPOSIT -> AuditAction.DEPOSIT;
                case WITHDRAWAL -> AuditAction.WITHDRAWAL;
                case TRANSFER -> ok ? AuditAction.TRANSFER_COMPLETED : AuditAction.TRANSFER_FAILED;
                case REVERSAL -> null;
            };
            if (action == null || e.status() == TransactionStatus.PENDING || e.status() == TransactionStatus.CANCELLED
                    || e.status() == TransactionStatus.REVERSED || (!e.created() && e.type() != com.kivubank.transaction.TransactionType.TRANSFER)) {
                return;
            }
            audit.recordForUser(e.initiatedByUserId(), action, ok ? AuditOutcome.SUCCESS : AuditOutcome.FAILURE,
                    "TRANSACTION", e.reference(), "amount=" + e.amount() + " " + e.currency() + " status=" + e.status()
                            + (e.failureReason() == null ? "" : " reason=" + e.failureReason()) + " channel=" + e.channel());
        } catch (RuntimeException ex) {
            log.error("Audit listener failed for {}", e.reference(), ex);
        }
    }
}
