package com.kivubank.common;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/** Resolves the caller's IP from the current request, if any. Uses the socket address (not spoofable headers). */
public final class ClientInfo {
    private ClientInfo() {
    }

    public static String currentIp() {
        RequestAttributes attrs = RequestContextHolder.getRequestAttributes();
        if (attrs instanceof ServletRequestAttributes sra) {
            HttpServletRequest req = sra.getRequest();
            return req.getRemoteAddr();
        }
        return null;
    }
}
