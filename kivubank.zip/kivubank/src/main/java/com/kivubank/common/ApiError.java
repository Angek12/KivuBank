package com.kivubank.common;

import java.time.Instant;
import java.util.List;

/** Uniform error body. Never contains stack traces or internal details. */
public record ApiError(Instant timestamp, int status, String code, String message, String path,
                       String requestId, List<FieldViolation> violations) {

    public record FieldViolation(String field, String message) {
    }
}
