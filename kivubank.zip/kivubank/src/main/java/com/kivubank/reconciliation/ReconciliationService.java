package com.kivubank.reconciliation;

import com.kivubank.audit.AuditAction;
import com.kivubank.audit.AuditOutcome;
import com.kivubank.audit.AuditService;
import com.kivubank.auth.AuthenticatedUser;
import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import com.kivubank.common.PageResponse;
import com.kivubank.transaction.Transaction;
import com.kivubank.transaction.TransactionRepository;
import com.kivubank.transaction.TransactionStatus;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * SIMULATION: compares KivuBank's internal transactions with the simulated provider's ledger and classifies every
 * difference: MATCHED, MISSING_EXTERNAL, MISSING_INTERNAL, AMOUNT_MISMATCH, DUPLICATE, STATUS_MISMATCH.
 * CANCELLED/REVERSED/REVERSAL records are internal-only and excluded from the comparison.
 */
@Service
public class ReconciliationService {
    private static final Set<TransactionStatus> COMPARED = EnumSet.of(TransactionStatus.SUCCESS, TransactionStatus.FAILED,
            TransactionStatus.PENDING, TransactionStatus.PROCESSING);
    private final TransactionRepository transactions;
    private final ProviderTransactionRepository providerRows;
    private final ReconciliationRunRepository runs;
    private final ReconciliationItemRepository items;
    private final SimulatedPaymentGateway gateway;
    private final AuditService audit;
    private final Clock clock;

    public ReconciliationService(TransactionRepository transactions, ProviderTransactionRepository providerRows,
                                 ReconciliationRunRepository runs, ReconciliationItemRepository items,
                                 SimulatedPaymentGateway gateway, AuditService audit, Clock clock) {
        this.transactions = transactions;
        this.providerRows = providerRows;
        this.runs = runs;
        this.items = items;
        this.gateway = gateway;
        this.audit = audit;
        this.clock = clock;
    }

    public record RunView(Long id, Instant startedAt, Instant windowFrom, Instant windowTo, int internalCount,
                          int externalCount, int matched, int missingExternal, int missingInternal, int amountMismatch,
                          int duplicates, int statusMismatch, boolean simulation) {
        static RunView of(ReconciliationRun r) {
            return new RunView(r.getId(), r.getStartedAt(), r.getWindowFrom(), r.getWindowTo(), r.getInternalCount(),
                    r.getExternalCount(), r.getMatchedCount(), r.getMissingExternalCount(), r.getMissingInternalCount(),
                    r.getAmountMismatchCount(), r.getDuplicateCount(), r.getStatusMismatchCount(), true);
        }
    }

    public record ItemView(Long id, ReconciliationCategory category, String internalReference, String providerReference,
                           BigDecimal internalAmount, BigDecimal externalAmount, String internalStatus,
                           String externalStatus, String note) {
        static ItemView of(ReconciliationItem i) {
            return new ItemView(i.getId(), i.getCategory(), i.getInternalReference(), i.getProviderReference(),
                    i.getInternalAmount(), i.getExternalAmount(), i.getInternalStatus(), i.getExternalStatus(), i.getNote());
        }
    }

    /** Rates are probabilities in [0,1]. Use a seed for reproducible demos. */
    public record SimulationRequest(Instant from, Instant to, double dropRate, double duplicateRate, double amountDriftRate,
                                    double statusFlipRate, double timeoutRate, int orphanCount, Long seed) {
    }

    public record SimulationResult(int submitted, int dropped, int duplicated, int amountDrifted, int statusFlipped,
                                   int timedOut, int orphans, boolean simulation) {
    }

    @Transactional
    public SimulationResult simulateSettlement(SimulationRequest req) {
        Instant now = clock.instant();
        Instant to = req.to() == null ? now.plusSeconds(60) : req.to();
        Instant from = req.from() == null ? to.minus(Duration.ofHours(24)) : req.from();
        Random rnd = req.seed() == null ? new Random() : new Random(req.seed());
        double dropRate = Math.min(req.dropRate(), 1), duplicateRate = Math.min(req.duplicateRate(), 1),
                driftRate = Math.min(req.amountDriftRate(), 1), flipRate = Math.min(req.statusFlipRate(), 1),
                timeoutRate = Math.min(req.timeoutRate(), 1);
        int submitted = 0, dropped = 0, duplicated = 0, drifted = 0, flipped = 0, timedOut = 0;
        for (Transaction t : transactions.findForReconciliation(from, to, COMPARED)) {
            if (providerRows.existsByInternalReference(t.getReference())) {
                continue;   // already settled with the provider
            }
            if (rnd.nextDouble() < dropRate) {
                dropped++;
                continue;
            }
            ProviderStatus status = expected(t.getStatus());
            if (rnd.nextDouble() < timeoutRate) {
                status = ProviderStatus.TIMEOUT;
                timedOut++;
            } else if (rnd.nextDouble() < flipRate) {
                status = status == ProviderStatus.SUCCESS ? ProviderStatus.FAILED : ProviderStatus.SUCCESS;
                flipped++;
            }
            BigDecimal amount = t.getAmount();
            if (rnd.nextDouble() < driftRate) {
                amount = amount.add(amount.multiply(new BigDecimal("0.10")).setScale(2, java.math.RoundingMode.HALF_UP));
                drifted++;
            }
            gateway.record(t.getReference(), amount, t.getCurrency(), status);
            submitted++;
            if (rnd.nextDouble() < duplicateRate) {
                gateway.record(t.getReference(), amount, t.getCurrency(), status);
                duplicated++;
            }
        }
        for (int i = 0; i < req.orphanCount(); i++) {
            gateway.record("ORPHAN-" + Long.toString(Math.abs(rnd.nextLong()), 36).toUpperCase(),
                    new BigDecimal("1000.00"), "RWF", ProviderStatus.SUCCESS);
        }
        audit.record(AuditAction.PROVIDER_SIMULATION, AuditOutcome.SUCCESS, "SIMULATOR", "settlement",
                "submitted=" + submitted + " dropped=" + dropped + " duplicated=" + duplicated);
        return new SimulationResult(submitted, dropped, duplicated, drifted, flipped, timedOut, req.orphanCount(), true);
    }

    @Transactional
    public RunView run(Instant fromOrNull, Instant toOrNull) {
        Instant now = clock.instant();
        Instant to = toOrNull == null ? now.plusSeconds(60) : toOrNull;
        Instant from = fromOrNull == null ? to.minus(Duration.ofHours(24)) : fromOrNull;
        if (!from.isBefore(to) || Duration.between(from, to).toDays() > 31) {
            throw new BusinessException(ErrorCode.VALIDATION_FAILED, "Window must be positive and at most 31 days.");
        }
        Long userId = AuthenticatedUser.current().id();
        List<Transaction> internal = transactions.findForReconciliation(from, to, COMPARED);
        Set<String> internalRefs = internal.stream().map(Transaction::getReference).collect(Collectors.toSet());

        Map<Long, ProviderTransaction> external = new LinkedHashMap<>();
        if (!internalRefs.isEmpty()) {
            providerRows.findByInternalReferenceIn(internalRefs).forEach(p -> external.put(p.getId(), p));
        }
        providerRows.findBySubmittedAtGreaterThanEqualAndSubmittedAtLessThan(from, to).forEach(p -> external.putIfAbsent(p.getId(), p));

        Map<String, List<ProviderTransaction>> byRef = new HashMap<>();
        for (ProviderTransaction p : external.values()) {
            if (p.getInternalReference() != null) {
                byRef.computeIfAbsent(p.getInternalReference(), k -> new ArrayList<>()).add(p);
            }
        }
        byRef.values().forEach(l -> l.sort(Comparator.comparing(ProviderTransaction::getSubmittedAt).thenComparing(ProviderTransaction::getId)));

        ReconciliationRun run = runs.save(new ReconciliationRun(now, from, to, userId));
        List<ReconciliationItem> out = new ArrayList<>();
        int matched = 0, missingExternal = 0, missingInternal = 0, amountMismatch = 0, duplicates = 0, statusMismatch = 0;

        for (Transaction t : internal) {
            List<ProviderTransaction> rows = byRef.getOrDefault(t.getReference(), List.of());
            String status = t.getStatus().name();
            if (rows.isEmpty()) {
                missingExternal++;
                out.add(new ReconciliationItem(run.getId(), ReconciliationCategory.MISSING_EXTERNAL, t.getReference(), null,
                        t.getAmount(), null, status, null, "Not present in the provider ledger."));
                continue;
            }
            ProviderTransaction p = rows.get(0);
            boolean clean = rows.size() == 1;
            if (rows.size() > 1) {
                duplicates++;
                out.add(new ReconciliationItem(run.getId(), ReconciliationCategory.DUPLICATE, t.getReference(), p.getProviderReference(),
                        t.getAmount(), p.getAmount(), status, p.getStatus().name(),
                        "Provider recorded this payment " + rows.size() + " times."));
            }
            if (t.getAmount().compareTo(p.getAmount()) != 0) {
                clean = false;
                amountMismatch++;
                out.add(new ReconciliationItem(run.getId(), ReconciliationCategory.AMOUNT_MISMATCH, t.getReference(), p.getProviderReference(),
                        t.getAmount(), p.getAmount(), status, p.getStatus().name(), "Amounts differ."));
            }
            if (expected(t.getStatus()) != p.getStatus()) {
                clean = false;
                statusMismatch++;
                out.add(new ReconciliationItem(run.getId(), ReconciliationCategory.STATUS_MISMATCH, t.getReference(), p.getProviderReference(),
                        t.getAmount(), p.getAmount(), status, p.getStatus().name(),
                        "Expected provider status " + expected(t.getStatus()) + "."));
            }
            if (clean) {
                matched++;
                out.add(new ReconciliationItem(run.getId(), ReconciliationCategory.MATCHED, t.getReference(), p.getProviderReference(),
                        t.getAmount(), p.getAmount(), status, p.getStatus().name(), null));
            }
        }
        Set<String> seenOrphans = new HashSet<>();
        for (ProviderTransaction p : external.values()) {
            String ref = p.getInternalReference();
            if (ref != null && internalRefs.contains(ref)) {
                continue;
            }
            if (ref != null && transactions.findByReference(ref).isPresent()) {
                continue;   // belongs to an internal transaction outside this window or excluded status
            }
            if (seenOrphans.add(p.getProviderReference())) {
                missingInternal++;
                out.add(new ReconciliationItem(run.getId(), ReconciliationCategory.MISSING_INTERNAL, ref, p.getProviderReference(),
                        null, p.getAmount(), null, p.getStatus().name(), "Provider reports a payment KivuBank has no record of."));
            }
        }
        items.saveAll(out);
        run.setCounts(internal.size(), external.size(), matched, missingExternal, missingInternal, amountMismatch, duplicates, statusMismatch);
        audit.record(AuditAction.RECONCILIATION_RUN, AuditOutcome.SUCCESS, "RECONCILIATION", String.valueOf(run.getId()),
                "internal=" + internal.size() + " matched=" + matched + " exceptions="
                        + (missingExternal + missingInternal + amountMismatch + duplicates + statusMismatch));
        return RunView.of(run);
    }

    @Transactional(readOnly = true)
    public PageResponse<RunView> listRuns(int page, int size) {
        return PageResponse.of(runs.findAll(PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100),
                Sort.by(Sort.Direction.DESC, "startedAt"))), RunView::of);
    }

    @Transactional(readOnly = true)
    public RunView getRun(Long id) {
        return runs.findById(id).map(RunView::of).orElseThrow(() -> new BusinessException(ErrorCode.NOT_FOUND, "Run not found."));
    }

    @Transactional(readOnly = true)
    public PageResponse<ItemView> listItems(Long runId, ReconciliationCategory category, int page, int size) {
        PageRequest p = PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 200), Sort.by("id"));
        var result = category == null ? items.findByRunId(runId, p) : items.findByRunIdAndCategory(runId, category, p);
        return PageResponse.of(result, ItemView::of);
    }

    static ProviderStatus expected(TransactionStatus status) {
        return switch (status) {
            case SUCCESS -> ProviderStatus.SUCCESS;
            case FAILED -> ProviderStatus.FAILED;
            default -> ProviderStatus.PENDING;
        };
    }
}
