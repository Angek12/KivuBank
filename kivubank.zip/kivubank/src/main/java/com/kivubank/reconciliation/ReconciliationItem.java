package com.kivubank.reconciliation;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;

@Entity
@Table(name = "reconciliation_items")
public class ReconciliationItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private Long runId;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ReconciliationCategory category;
    private String internalReference;
    private String providerReference;
    @Column(precision = 19, scale = 2)
    private BigDecimal internalAmount;
    @Column(precision = 19, scale = 2)
    private BigDecimal externalAmount;
    private String internalStatus;
    private String externalStatus;
    @Column(length = 300)
    private String note;

    protected ReconciliationItem() {
    }

    public ReconciliationItem(Long runId, ReconciliationCategory category, String internalReference, String providerReference,
                              BigDecimal internalAmount, BigDecimal externalAmount, String internalStatus,
                              String externalStatus, String note) {
        this.runId = runId;
        this.category = category;
        this.internalReference = internalReference;
        this.providerReference = providerReference;
        this.internalAmount = internalAmount;
        this.externalAmount = externalAmount;
        this.internalStatus = internalStatus;
        this.externalStatus = externalStatus;
        this.note = note;
    }

    public Long getId() { return id; }
    public Long getRunId() { return runId; }
    public ReconciliationCategory getCategory() { return category; }
    public String getInternalReference() { return internalReference; }
    public String getProviderReference() { return providerReference; }
    public BigDecimal getInternalAmount() { return internalAmount; }
    public BigDecimal getExternalAmount() { return externalAmount; }
    public String getInternalStatus() { return internalStatus; }
    public String getExternalStatus() { return externalStatus; }
    public String getNote() { return note; }
}
