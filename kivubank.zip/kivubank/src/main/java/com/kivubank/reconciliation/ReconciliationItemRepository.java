package com.kivubank.reconciliation;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReconciliationItemRepository extends JpaRepository<ReconciliationItem, Long> {
    Page<ReconciliationItem> findByRunId(Long runId, Pageable pageable);

    Page<ReconciliationItem> findByRunIdAndCategory(Long runId, ReconciliationCategory category, Pageable pageable);
}
