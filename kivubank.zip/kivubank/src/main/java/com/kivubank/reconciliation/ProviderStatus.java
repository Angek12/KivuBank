package com.kivubank.reconciliation;

public enum ProviderStatus { SUCCESS, FAILED, PENDING, TIMEOUT }
