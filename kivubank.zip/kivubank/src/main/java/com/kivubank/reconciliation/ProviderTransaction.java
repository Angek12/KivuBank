package com.kivubank.reconciliation;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.time.Instant;

/** A row in the SIMULATED external payment provider's own ledger. */
@Entity
@Table(name = "sim_provider_transactions")
public class ProviderTransaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, unique = true, length = 40)
    private String providerReference;
    @Column(length = 40)
    private String internalReference;
    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal amount;
    @Column(nullable = false, length = 3)
    private String currency;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ProviderStatus status;
    @Column(nullable = false)
    private Instant submittedAt;

    protected ProviderTransaction() {
    }

    public ProviderTransaction(String providerReference, String internalReference, BigDecimal amount, String currency,
                               ProviderStatus status, Instant submittedAt) {
        this.providerReference = providerReference;
        this.internalReference = internalReference;
        this.amount = amount;
        this.currency = currency;
        this.status = status;
        this.submittedAt = submittedAt;
    }

    public Long getId() { return id; }
    public String getProviderReference() { return providerReference; }
    public String getInternalReference() { return internalReference; }
    public BigDecimal getAmount() { return amount; }
    public String getCurrency() { return currency; }
    public ProviderStatus getStatus() { return status; }
    public Instant getSubmittedAt() { return submittedAt; }
}
