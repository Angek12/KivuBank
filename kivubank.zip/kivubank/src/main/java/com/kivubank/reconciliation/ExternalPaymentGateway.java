package com.kivubank.reconciliation;

import java.math.BigDecimal;

/**
 * Port to an external payment provider (KivuBank -> provider). The only implementation is
 * {@link SimulatedPaymentGateway}; no real provider, bank or network call exists.
 */
public interface ExternalPaymentGateway {
    ProviderResponse submit(PaymentInstruction instruction);

    /** @param forcedStatus optional; when set the simulator returns exactly this outcome. */
    record PaymentInstruction(String internalReference, BigDecimal amount, String currency, ProviderStatus forcedStatus) {
    }

    record ProviderResponse(ProviderStatus status, String providerReference, boolean recordedByProvider, String note) {
    }
}
