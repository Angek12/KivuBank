package com.kivubank.reconciliation;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProviderTransactionRepository extends JpaRepository<ProviderTransaction, Long> {
    List<ProviderTransaction> findByInternalReferenceIn(Collection<String> references);

    List<ProviderTransaction> findBySubmittedAtGreaterThanEqualAndSubmittedAtLessThan(Instant from, Instant to);

    boolean existsByInternalReference(String internalReference);
}
