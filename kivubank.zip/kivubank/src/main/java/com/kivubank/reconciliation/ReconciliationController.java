package com.kivubank.reconciliation;

import com.kivubank.common.PageResponse;
import com.kivubank.reconciliation.ExternalPaymentGateway.PaymentInstruction;
import com.kivubank.reconciliation.ExternalPaymentGateway.ProviderResponse;
import com.kivubank.reconciliation.ReconciliationService.ItemView;
import com.kivubank.reconciliation.ReconciliationService.RunView;
import com.kivubank.reconciliation.ReconciliationService.SimulationRequest;
import com.kivubank.reconciliation.ReconciliationService.SimulationResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.Instant;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/admin")
@Tag(name = "Reconciliation (simulation)", description = "SIMULATED external payment provider and reconciliation. "
        + "No real provider or bank is contacted.")
@SecurityRequirement(name = "bearerAuth")
public class ReconciliationController {
    private final ReconciliationService service;
    private final SimulatedPaymentGateway gateway;

    public ReconciliationController(ReconciliationService service, SimulatedPaymentGateway gateway) {
        this.service = service;
        this.gateway = gateway;
    }

    public record ProviderPaymentRequest(
            @Schema(example = "KB20261003-ABCDEFGHJK", description = "KivuBank transaction reference (optional)") @Size(max = 40) String internalReference,
            @Schema(example = "1500.00") @NotNull @DecimalMin("0.01") BigDecimal amount,
            @Schema(description = "Force a provider outcome; omit for a random one") ProviderStatus forceStatus) {
    }

    public record SettlementRequest(Instant from, Instant to,
                                    @PositiveOrZero double dropRate,
                                    @PositiveOrZero double duplicateRate,
                                    @PositiveOrZero double amountDriftRate,
                                    @PositiveOrZero double statusFlipRate,
                                    @PositiveOrZero double timeoutRate,
                                    @Min(0) @Max(50) int orphanCount, Long seed) {
    }

    public record RunRequest(Instant from, Instant to) {
    }

    @PostMapping("/simulator/provider/payments")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Send a payment to the simulated provider",
            description = "KivuBank -> External Payment Provider. Returns SUCCESS, FAILED, PENDING or TIMEOUT. SIMULATION ONLY.")
    public ProviderResponse submitToProvider(@Valid @RequestBody ProviderPaymentRequest r) {
        return gateway.submit(new PaymentInstruction(r.internalReference(), r.amount(), "RWF", r.forceStatus()));
    }

    @PostMapping("/reconciliation/simulate-settlement")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Simulate provider settlement of internal transactions",
            description = "Mirrors recent internal transactions into the simulated provider ledger, optionally injecting faults "
                    + "(dropped, duplicated, amount drift, status flips, timeouts, provider-only orphans) so reconciliation has something to find.")
    public SimulationResult simulate(@Valid @RequestBody SettlementRequest r) {
        return service.simulateSettlement(new SimulationRequest(r.from(), r.to(), r.dropRate(), r.duplicateRate(),
                r.amountDriftRate(), r.statusFlipRate(), r.timeoutRate(), r.orphanCount(), r.seed()));
    }

    @PostMapping("/reconciliation/runs")
    @PreAuthorize("hasRole('ADMIN')")
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Run reconciliation", description = "Compares internal transactions with the simulated provider ledger for a window (default last 24h).")
    public RunView run(@RequestBody(required = false) RunRequest r) {
        return service.run(r == null ? null : r.from(), r == null ? null : r.to());
    }

    @GetMapping("/reconciliation/runs")
    @PreAuthorize("hasAnyRole('ADMIN','AUDITOR')")
    @Operation(summary = "List reconciliation runs")
    public PageResponse<RunView> runs(@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "20") int size) {
        return service.listRuns(page, size);
    }

    @GetMapping("/reconciliation/runs/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','AUDITOR')")
    @Operation(summary = "Get a reconciliation run summary")
    public RunView run(@PathVariable Long id) {
        return service.getRun(id);
    }

    @GetMapping("/reconciliation/runs/{id}/items")
    @PreAuthorize("hasAnyRole('ADMIN','AUDITOR')")
    @Operation(summary = "List reconciliation items", description = "Filter by category: MATCHED, MISSING_EXTERNAL, MISSING_INTERNAL, AMOUNT_MISMATCH, DUPLICATE, STATUS_MISMATCH.")
    public PageResponse<ItemView> items(@PathVariable Long id, @RequestParam(required = false) ReconciliationCategory category,
                                        @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "50") int size) {
        return service.listItems(id, category, page, size);
    }
}
