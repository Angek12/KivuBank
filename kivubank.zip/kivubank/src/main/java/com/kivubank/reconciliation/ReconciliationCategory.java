package com.kivubank.reconciliation;

public enum ReconciliationCategory { MATCHED, MISSING_EXTERNAL, MISSING_INTERNAL, AMOUNT_MISMATCH, DUPLICATE, STATUS_MISMATCH }
