package com.kivubank.reconciliation;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "reconciliation_runs")
public class ReconciliationRun {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private Instant startedAt;
    @Column(nullable = false)
    private Instant windowFrom;
    @Column(nullable = false)
    private Instant windowTo;
    private int internalCount;
    private int externalCount;
    private int matchedCount;
    private int missingExternalCount;
    private int missingInternalCount;
    private int amountMismatchCount;
    private int duplicateCount;
    private int statusMismatchCount;
    private Long triggeredByUserId;

    protected ReconciliationRun() {
    }

    public ReconciliationRun(Instant startedAt, Instant windowFrom, Instant windowTo, Long triggeredByUserId) {
        this.startedAt = startedAt;
        this.windowFrom = windowFrom;
        this.windowTo = windowTo;
        this.triggeredByUserId = triggeredByUserId;
    }

    public void setCounts(int internal, int external, int matched, int missingExternal, int missingInternal,
                          int amountMismatch, int duplicate, int statusMismatch) {
        this.internalCount = internal;
        this.externalCount = external;
        this.matchedCount = matched;
        this.missingExternalCount = missingExternal;
        this.missingInternalCount = missingInternal;
        this.amountMismatchCount = amountMismatch;
        this.duplicateCount = duplicate;
        this.statusMismatchCount = statusMismatch;
    }

    public Long getId() { return id; }
    public Instant getStartedAt() { return startedAt; }
    public Instant getWindowFrom() { return windowFrom; }
    public Instant getWindowTo() { return windowTo; }
    public int getInternalCount() { return internalCount; }
    public int getExternalCount() { return externalCount; }
    public int getMatchedCount() { return matchedCount; }
    public int getMissingExternalCount() { return missingExternalCount; }
    public int getMissingInternalCount() { return missingInternalCount; }
    public int getAmountMismatchCount() { return amountMismatchCount; }
    public int getDuplicateCount() { return duplicateCount; }
    public int getStatusMismatchCount() { return statusMismatchCount; }
    public Long getTriggeredByUserId() { return triggeredByUserId; }
}
