package com.kivubank.reconciliation;

import java.security.SecureRandom;
import java.time.Clock;
import java.util.Random;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * SIMULATION ONLY. Behaves like a flaky provider: ~80% SUCCESS, ~10% FAILED, ~7% PENDING, ~3% TIMEOUT unless an
 * outcome is forced. A TIMEOUT is ambiguous by design: the provider may or may not have recorded the payment
 * (here it records it as TIMEOUT), which is exactly the situation reconciliation exists to resolve.
 */
@Component
public class SimulatedPaymentGateway implements ExternalPaymentGateway {
    private static final String ALPHABET = "ABCDEFGHJKMNPQRSTVWXYZ23456789";
    private final ProviderTransactionRepository repository;
    private final Clock clock;
    private final Random random = new Random();
    private final SecureRandom idRandom = new SecureRandom();

    public SimulatedPaymentGateway(ProviderTransactionRepository repository, Clock clock) {
        this.repository = repository;
        this.clock = clock;
    }

    @Override
    @Transactional
    public ProviderResponse submit(PaymentInstruction i) {
        ProviderStatus status = i.forcedStatus() != null ? i.forcedStatus() : roll();
        String providerRef = "EXT-" + randomId(10);
        repository.save(new ProviderTransaction(providerRef, i.internalReference(), i.amount(), i.currency(), status, clock.instant()));
        return new ProviderResponse(status, providerRef, true, "simulated provider response");
    }

    /** Records an arbitrary provider-side row (used by the settlement simulator to inject faults). */
    @Transactional
    public ProviderTransaction record(String internalReference, java.math.BigDecimal amount, String currency, ProviderStatus status) {
        return repository.save(new ProviderTransaction("EXT-" + randomId(10), internalReference, amount, currency, status, clock.instant()));
    }

    private ProviderStatus roll() {
        double r = random.nextDouble();
        if (r < 0.80) return ProviderStatus.SUCCESS;
        if (r < 0.90) return ProviderStatus.FAILED;
        if (r < 0.97) return ProviderStatus.PENDING;
        return ProviderStatus.TIMEOUT;
    }

    private String randomId(int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append(ALPHABET.charAt(idRandom.nextInt(ALPHABET.length())));
        }
        return sb.toString();
    }
}
