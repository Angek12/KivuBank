package com.kivubank.bootstrap;

import com.kivubank.auth.PasswordPolicy;
import com.kivubank.config.KivuBankProperties;
import com.kivubank.user.Role;
import com.kivubank.user.User;
import com.kivubank.user.UserRepository;
import java.time.Clock;
import java.util.List;
import java.util.Locale;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * Creates the first ADMIN from environment variables (KIVUBANK_BOOTSTRAP_ADMIN_EMAIL / _PASSWORD) when no admin
 * exists yet. No default credentials exist anywhere in the code base.
 */
@Component
@Order(1)
public class AdminBootstrap implements ApplicationRunner {
    private static final Logger log = LoggerFactory.getLogger(AdminBootstrap.class);
    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final KivuBankProperties props;
    private final Clock clock;

    public AdminBootstrap(UserRepository users, PasswordEncoder encoder, KivuBankProperties props, Clock clock) {
        this.users = users;
        this.encoder = encoder;
        this.props = props;
        this.clock = clock;
    }

    @Override
    public void run(ApplicationArguments args) {
        var cfg = props.bootstrap();
        if (cfg.adminEmail() == null || cfg.adminEmail().isBlank() || cfg.adminPassword() == null || cfg.adminPassword().isBlank()) {
            if (!users.existsByRole(Role.ADMIN)) {
                log.warn("No ADMIN user exists. Set KIVUBANK_BOOTSTRAP_ADMIN_EMAIL and KIVUBANK_BOOTSTRAP_ADMIN_PASSWORD to create one.");
            }
            return;
        }
        if (users.existsByRole(Role.ADMIN)) {
            return;
        }
        String email = cfg.adminEmail().trim().toLowerCase(Locale.ROOT);
        List<String> problems = PasswordPolicy.violations(cfg.adminPassword(), email, cfg.adminName());
        if (!problems.isEmpty()) {
            throw new IllegalStateException("KIVUBANK_BOOTSTRAP_ADMIN_PASSWORD is too weak: " + String.join(" ", problems));
        }
        users.save(new User(cfg.adminName(), email, cfg.adminPhone(), encoder.encode(cfg.adminPassword()), Role.ADMIN, clock.instant()));
        log.info("Bootstrap ADMIN user created for {}", email);
    }
}
