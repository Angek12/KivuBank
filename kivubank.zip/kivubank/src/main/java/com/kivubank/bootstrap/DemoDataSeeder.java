package com.kivubank.bootstrap;

import com.kivubank.account.Account;
import com.kivubank.account.AccountService;
import com.kivubank.account.PinPolicy;
import com.kivubank.account.PinService;
import com.kivubank.incident.AffectedService;
import com.kivubank.incident.IncidentRepository;
import com.kivubank.incident.Incident;
import com.kivubank.incident.IncidentSeverity;
import com.kivubank.transaction.Channel;
import com.kivubank.transaction.TransactionProcessor;
import com.kivubank.transaction.TransactionProcessor.MoneyCommand;
import com.kivubank.transaction.TransactionProcessor.TransferCommand;
import com.kivubank.user.Role;
import com.kivubank.user.User;
import com.kivubank.user.UserRepository;
import java.math.BigDecimal;
import java.security.SecureRandom;
import java.time.Clock;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * Profile "demo" only: loads clearly SYNTHETIC users and transactions so the dashboards have something to show.
 * Credentials are never hard-coded: the password comes from KIVUBANK_DEMO_PASSWORD (or is generated) and PINs are random;
 * both are printed once to the console.
 */
@Component
@Profile("demo")
@Order(2)
public class DemoDataSeeder implements ApplicationRunner {
    private static final Logger log = LoggerFactory.getLogger(DemoDataSeeder.class);
    private static final String DOMAIN = "@kivubank.example";
    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final AccountService accountService;
    private final PinService pinService;
    private final TransactionProcessor processor;
    private final IncidentRepository incidents;
    private final Clock clock;
    private final String configuredPassword;
    private final SecureRandom random = new SecureRandom();

    public DemoDataSeeder(UserRepository users, PasswordEncoder encoder, AccountService accountService, PinService pinService,
                          TransactionProcessor processor, IncidentRepository incidents, Clock clock,
                          @Value("${KIVUBANK_DEMO_PASSWORD:}") String configuredPassword) {
        this.users = users;
        this.encoder = encoder;
        this.accountService = accountService;
        this.pinService = pinService;
        this.processor = processor;
        this.incidents = incidents;
        this.clock = clock;
        this.configuredPassword = configuredPassword;
    }

    private record Demo(User user, Account account, String pin) {
    }

    @Override
    public void run(ApplicationArguments args) {
        if (users.existsByEmail("support.demo" + DOMAIN)) {
            log.info("Demo data already present; skipping.");
            return;
        }
        String password = configuredPassword == null || configuredPassword.isBlank() ? generatePassword() : configuredPassword;
        staff("Demo Support Agent", "support.demo" + DOMAIN, "+14155550101", password, Role.SUPPORT_AGENT);
        staff("Demo Auditor", "auditor.demo" + DOMAIN, "+14155550102", password, Role.AUDITOR);
        if (!users.existsByRole(Role.ADMIN)) {
            staff("Demo Administrator", "admin.demo" + DOMAIN, "+14155550100", password, Role.ADMIN);
        }
        List<Demo> customers = new ArrayList<>();
        customers.add(customer("Demo Customer Alpha", "alpha.demo" + DOMAIN, "+14155550111", password, "500000.00"));
        customers.add(customer("Demo Customer Bravo", "bravo.demo" + DOMAIN, "+14155550112", password, "250000.00"));
        customers.add(customer("Demo Customer Charlie", "charlie.demo" + DOMAIN, "+14155550113", password, "120000.00"));

        for (int i = 0; i < 12; i++) {
            Demo from = customers.get(i % 3);
            Demo to = customers.get((i + 1) % 3);
            BigDecimal amount = new BigDecimal(1000 + random.nextInt(40) * 500).setScale(2);
            processor.transfer(new TransferCommand(from.user().getId(), to.account().getAccountNumber(), amount,
                    "Synthetic demo transfer", Channel.WEB, "demo-seed-" + i));
        }
        processor.withdraw(new MoneyCommand(customers.get(0).user().getId(), new BigDecimal("20000.00"),
                "Synthetic demo withdrawal", Channel.MOBILE, "demo-seed-w1"));
        incidents.save(new Incident("Demo: elevated API latency",
                "Synthetic example incident created by the demo profile to illustrate incident management.",
                IncidentSeverity.MEDIUM, AffectedService.API, "Platform team", null, clock.instant()));

        log.warn("=== KIVUBANK DEMO DATA (synthetic) ===");
        log.warn("Password for all demo users: {}", password);
        log.warn("Staff: support.demo{0}, auditor.demo{0}".replace("{0}", DOMAIN));
        customers.forEach(c -> log.warn("Customer {} / account {} / PIN {}", c.user().getEmail(), c.account().getAccountNumber(), c.pin()));
    }

    private void staff(String name, String email, String phone, String password, Role role) {
        users.save(new User(name, email, phone, encoder.encode(password), role, clock.instant()));
    }

    private Demo customer(String name, String email, String phone, String password, String openingDeposit) {
        User user = users.save(new User(name, email, phone, encoder.encode(password), Role.CUSTOMER, clock.instant()));
        Account account = accountService.openAccount(user.getId());
        String pin = randomPin();
        pinService.create(user.getId(), password, pin);
        processor.deposit(new MoneyCommand(user.getId(), new BigDecimal(openingDeposit), "Synthetic opening deposit",
                Channel.WEB, "demo-open-" + user.getId()));
        return new Demo(user, account, pin);
    }

    private String randomPin() {
        String pin;
        do {
            pin = String.format("%04d", random.nextInt(10000));
        } while (PinPolicy.violation(pin) != null);
        return pin;
    }

    private String generatePassword() {
        String alphabet = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 14; i++) {
            sb.append(alphabet.charAt(random.nextInt(alphabet.length())));
        }
        return sb + "-Kb9";
    }
}
