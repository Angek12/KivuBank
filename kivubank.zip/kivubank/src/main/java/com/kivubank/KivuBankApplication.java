package com.kivubank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * KivuBank - a simulated digital banking platform. No real money, customers or banks are involved.
 * Derived from the MIT-licensed BankingPortal-API project by Abhishek Tiwari (see LICENSE and README).
 */
@SpringBootApplication
@ConfigurationPropertiesScan
public class KivuBankApplication {
    public static void main(String[] args) {
        SpringApplication.run(KivuBankApplication.class, args);
    }
}
