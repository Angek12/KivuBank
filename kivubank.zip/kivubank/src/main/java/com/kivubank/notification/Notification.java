package com.kivubank.notification;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "notifications")
public class Notification {
    public enum DeliveryStatus { SENT, FAILED }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private Long userId;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private NotificationChannel channel;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private NotificationType type;
    private String recipient;
    @Column(nullable = false, length = 150)
    private String subject;
    @Column(nullable = false, length = 500)
    private String body;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private DeliveryStatus status;
    @Column(nullable = false, length = 30)
    private String provider;
    @Column(nullable = false)
    private Instant createdAt;
    private Instant readAt;

    protected Notification() {
    }

    public Notification(Long userId, NotificationChannel channel, NotificationType type, String recipient,
                        String subject, String body, DeliveryStatus status, String provider, Instant now) {
        this.userId = userId;
        this.channel = channel;
        this.type = type;
        this.recipient = recipient;
        this.subject = subject.length() > 150 ? subject.substring(0, 150) : subject;
        this.body = body.length() > 500 ? body.substring(0, 500) : body;
        this.status = status;
        this.provider = provider;
        this.createdAt = now;
    }

    public void markRead(Instant now) {
        if (readAt == null) {
            readAt = now;
        }
    }

    public Long getId() { return id; }
    public Long getUserId() { return userId; }
    public NotificationChannel getChannel() { return channel; }
    public NotificationType getType() { return type; }
    public String getRecipient() { return recipient; }
    public String getSubject() { return subject; }
    public String getBody() { return body; }
    public DeliveryStatus getStatus() { return status; }
    public String getProvider() { return provider; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getReadAt() { return readAt; }
}
