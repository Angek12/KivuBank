package com.kivubank.notification;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/** Local-development provider: logs a masked line instead of contacting any e-mail/SMS/push service. */
@Component
@ConditionalOnProperty(name = "kivubank.notifications.provider", havingValue = "simulated", matchIfMissing = true)
public class SimulatedNotificationProvider implements NotificationProvider {
    private static final Logger log = LoggerFactory.getLogger(SimulatedNotificationProvider.class);

    @Override
    public String name() {
        return "simulated";
    }

    @Override
    public DeliveryResult send(Message m) {
        log.info("[SIMULATED {}] to={} type={} subject=\"{}\"", m.channel(), mask(m.recipient()), m.type(), m.subject());
        return new DeliveryResult(true, "simulated");
    }

    private static String mask(String recipient) {
        if (recipient == null || recipient.length() < 5) {
            return "***";
        }
        return recipient.substring(0, 2) + "***" + recipient.substring(recipient.length() - 2);
    }
}
