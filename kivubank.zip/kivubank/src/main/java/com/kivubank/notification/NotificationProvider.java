package com.kivubank.notification;

/**
 * Delivery abstraction. A real implementation (SMTP, an SMS gateway, FCM/APNs) can be added by implementing this
 * interface and selecting it with kivubank.notifications.provider=&lt;name&gt;; no calling code changes.
 */
public interface NotificationProvider {
    /** Unique provider name, matched against kivubank.notifications.provider. */
    String name();

    /** Attempts delivery; must not throw for ordinary delivery failures. */
    DeliveryResult send(Message message);

    record Message(Long userId, NotificationChannel channel, NotificationType type, String recipient, String subject,
                   String body) {
    }

    record DeliveryResult(boolean delivered, String detail) {
    }
}
