package com.kivubank.notification;

public enum NotificationChannel { EMAIL, SMS, PUSH, IN_APP }
