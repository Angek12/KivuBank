package com.kivubank.notification;

import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import com.kivubank.common.PageResponse;
import com.kivubank.notification.NotificationProvider.DeliveryResult;
import com.kivubank.notification.NotificationProvider.Message;
import com.kivubank.user.User;
import com.kivubank.user.UserRepository;
import java.time.Clock;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class NotificationService {
    private static final Logger log = LoggerFactory.getLogger(NotificationService.class);
    private final NotificationRepository repository;
    private final NotificationProvider provider;
    private final UserRepository users;
    private final Clock clock;

    public NotificationService(NotificationRepository repository, NotificationProvider provider, UserRepository users, Clock clock) {
        this.repository = repository;
        this.provider = provider;
        this.users = users;
        this.clock = clock;
    }

    public record NotificationView(Long id, NotificationChannel channel, NotificationType type, String subject,
                                   String body, java.time.Instant createdAt, boolean read) {
        static NotificationView of(Notification n) {
            return new NotificationView(n.getId(), n.getChannel(), n.getType(), n.getSubject(), n.getBody(),
                    n.getCreatedAt(), n.getReadAt() != null);
        }
    }

    /** Sends through the provider on each channel and records every attempt. Runs in its own transaction. */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void notifyUser(Long userId, NotificationType type, String subject, String body, List<NotificationChannel> channels) {
        if (userId == null) {
            return;
        }
        User user = users.findById(userId).orElse(null);
        if (user == null) {
            return;
        }
        for (NotificationChannel channel : channels) {
            String recipient = switch (channel) {
                case EMAIL -> user.getEmail();
                case SMS, PUSH -> user.getPhone();
                case IN_APP -> "user:" + userId;
            };
            DeliveryResult result;
            try {
                result = channel == NotificationChannel.IN_APP
                        ? new DeliveryResult(true, "in-app")
                        : provider.send(new Message(userId, channel, type, recipient, subject, body));
            } catch (RuntimeException e) {
                log.warn("Notification provider {} failed: {}", provider.name(), e.getClass().getSimpleName());
                result = new DeliveryResult(false, "provider error");
            }
            repository.save(new Notification(userId, channel, type, recipient, subject, body,
                    result.delivered() ? Notification.DeliveryStatus.SENT : Notification.DeliveryStatus.FAILED,
                    provider.name(), clock.instant()));
        }
    }

    @Transactional(readOnly = true)
    public PageResponse<NotificationView> inbox(Long userId, int page, int size) {
        Pageable p = PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100), Sort.by(Sort.Direction.DESC, "createdAt"));
        return PageResponse.of(repository.findByUserIdAndChannel(userId, NotificationChannel.IN_APP, p), NotificationView::of);
    }

    @Transactional(readOnly = true)
    public long unreadCount(Long userId) {
        return repository.countByUserIdAndChannelAndReadAtIsNull(userId, NotificationChannel.IN_APP);
    }

    @Transactional
    public void markRead(Long userId, Long id) {
        Notification n = repository.findByIdAndUserId(id, userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.NOT_FOUND, "Notification not found."));
        n.markRead(clock.instant());
    }
}
