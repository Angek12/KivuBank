package com.kivubank.notification;

import static com.kivubank.notification.NotificationChannel.EMAIL;
import static com.kivubank.notification.NotificationChannel.IN_APP;
import static com.kivubank.notification.NotificationChannel.SMS;

import com.kivubank.event.DomainEvents.LoginEvent;
import com.kivubank.event.DomainEvents.SecurityChangeEvent;
import com.kivubank.event.DomainEvents.StatementEvent;
import com.kivubank.event.DomainEvents.TransactionOutcomeEvent;
import com.kivubank.transaction.TransactionStatus;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

/** Maps domain events to notifications. Runs after commit; failures never affect the originating request. */
@Component
public class NotificationEventListener {
    private static final Logger log = LoggerFactory.getLogger(NotificationEventListener.class);
    private final NotificationService notifications;

    public NotificationEventListener(NotificationService notifications) {
        this.notifications = notifications;
    }

    @EventListener
    public void onTransaction(TransactionOutcomeEvent e) {
        try {
            String amount = e.amount().toPlainString() + " " + e.currency();
            switch (e.type()) {
                case TRANSFER -> {
                    if (e.status() == TransactionStatus.SUCCESS) {
                        notifications.notifyUser(e.sourceUserId(), NotificationType.TRANSFER_SUCCESS, "Transfer successful",
                                "Your transfer of " + amount + " (ref " + e.reference() + ") was completed.", List.of(IN_APP, SMS));
                        notifications.notifyUser(e.targetUserId(), NotificationType.TRANSFER_RECEIVED, "Funds received",
                                "You received " + amount + " (ref " + e.reference() + ").", List.of(IN_APP, SMS));
                    } else if (e.status() == TransactionStatus.FAILED) {
                        notifications.notifyUser(e.sourceUserId(), NotificationType.TRANSFER_FAILED, "Transfer failed",
                                "Your transfer of " + amount + " (ref " + e.reference() + ") failed: " + e.failureReason() + ".", List.of(IN_APP, SMS));
                    } else if (e.status() == TransactionStatus.PENDING) {
                        notifications.notifyUser(e.sourceUserId(), NotificationType.TRANSFER_PENDING, "Transfer awaiting review",
                                "Your transfer of " + amount + " (ref " + e.reference() + ") is awaiting manual approval.", List.of(IN_APP));
                    }
                }
                case DEPOSIT, WITHDRAWAL -> {
                    if (e.status() == TransactionStatus.SUCCESS || e.status() == TransactionStatus.FAILED) {
                        notifications.notifyUser(e.initiatedByUserId(), NotificationType.ACCOUNT_ACTIVITY, "Account activity",
                                e.type() + " of " + amount + " " + e.status() + " (ref " + e.reference() + ").", List.of(IN_APP));
                    }
                }
                default -> { }
            }
        } catch (RuntimeException ex) {
            log.error("Notification listener failed for {}", e.reference(), ex);
        }
    }

    @Async
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onLogin(LoginEvent e) {
        safe(() -> notifications.notifyUser(e.userId(), NotificationType.LOGIN, "New sign-in",
                "A sign-in to your KivuBank account was detected" + (e.ip() == null ? "." : " from IP " + e.ip() + "."),
                List.of(IN_APP, EMAIL)));
    }

    @Async
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onSecurityChange(SecurityChangeEvent e) {
        boolean pin = e.change().startsWith("PIN");
        safe(() -> notifications.notifyUser(e.userId(), pin ? NotificationType.PIN_CHANGED : NotificationType.PASSWORD_CHANGED,
                pin ? "PIN updated" : "Password changed",
                pin ? "Your transaction PIN was set or changed." : "Your password was changed. Sign in again on your devices.",
                List.of(IN_APP, EMAIL)));
    }

    @Async
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onStatement(StatementEvent e) {
        safe(() -> notifications.notifyUser(e.userId(), NotificationType.STATEMENT_GENERATED, "Statement generated",
                "A statement with " + e.rows() + " entries was generated for account " + e.accountNumber() + ".",
                List.of(IN_APP, EMAIL)));
    }

    private void safe(Runnable r) {
        try {
            r.run();
        } catch (RuntimeException ex) {
            log.error("Notification listener failed", ex);
        }
    }
}
