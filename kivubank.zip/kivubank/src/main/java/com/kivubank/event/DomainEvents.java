package com.kivubank.event;

import com.kivubank.transaction.Channel;
import com.kivubank.transaction.TransactionStatus;
import com.kivubank.transaction.TransactionType;
import java.math.BigDecimal;
import java.time.Instant;

/** Immutable domain events. Listeners run AFTER the originating database transaction commits. */
public final class DomainEvents {
    private DomainEvents() {
    }

    public record TransactionOutcomeEvent(Long transactionId, String reference, TransactionType type,
                                          TransactionStatus status, BigDecimal amount, String currency,
                                          Long sourceAccountId, Long targetAccountId, Long sourceUserId,
                                          Long targetUserId, Long initiatedByUserId, Channel channel,
                                          String failureReason, Instant occurredAt, boolean created) {
    }

    public record LoginEvent(Long userId, String ip) {
    }

    /** change is one of PIN_CREATED, PIN_CHANGED, PASSWORD_CHANGED. */
    public record SecurityChangeEvent(Long userId, String change) {
    }

    public record StatementEvent(Long userId, String accountNumber, String period, int rows) {
    }
}
