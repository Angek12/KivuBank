package com.kivubank.channels;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/channels")
@Tag(name = "Channels", description = "Simulated e-channels.")
@SecurityRequirement(name = "bearerAuth")
public class ChannelsController {
    public record ChannelInfo(String channel, String description, String howToUse, boolean simulated) {
    }

    @GetMapping
    @Operation(summary = "List the simulated e-channels")
    public List<ChannelInfo> channels() {
        return List.of(
                new ChannelInfo("WEB", "Browser banking (this application's web UI).", "Open the root URL and sign in.", false),
                new ChannelInfo("MOBILE", "Mobile banking concept: the same REST API consumed by a mobile client.",
                        "Send header 'X-Client-Channel: MOBILE' on money-moving requests; the UI is responsive.", true),
                new ChannelInfo("USSD", "Simulated *123# menu.", "POST /api/ussd/session or use the USSD tab in the UI.", true));
    }
}
