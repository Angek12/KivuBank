package com.kivubank.channels;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/ussd")
@Tag(name = "USSD simulator", description = "SIMULATED USSD channel (*123#). Not connected to any telecom operator or bank.")
public class UssdController {
    private final UssdService service;

    public UssdController(UssdService service) {
        this.service = service;
    }

    public record UssdRequest(
            @Schema(example = "sess-0001") @NotBlank @Size(max = 64) @Pattern(regexp = "^[A-Za-z0-9._-]+$") String sessionId,
            @Schema(example = "*123#") @NotBlank @Size(max = 20) String serviceCode,
            @Schema(example = "+14155552671", description = "Subscriber number (MSISDN); must belong to a registered customer") @NotBlank @Size(max = 25) String phoneNumber,
            @Schema(example = "2*1043820917*500*4829*1", description = "Accumulated input, '*'-separated; empty on first dial") @Size(max = 120) String text) {
    }

    public record UssdResponse(String message, boolean sessionEnded, String display, boolean simulator) {
    }

    @PostMapping("/session")
    @SecurityRequirements
    @Operation(summary = "Send input to the USSD simulator",
            description = "Public (as USSD aggregators are) but rate limited; every money action still requires the account PIN, with the same lockout rules as the REST API. "
                    + "Menu: 1 Check Balance, 2 Transfer Money, 3 Mini Statement, 4 Exit. Example flow: '' -> '2' -> '2*<account>' -> '2*<account>*<amount>' -> '2*<account>*<amount>*<pin>' -> '...*1'.")
    public UssdResponse session(@Valid @RequestBody UssdRequest r) {
        UssdService.Reply reply = service.handle(r.sessionId(), r.serviceCode(), r.phoneNumber(), r.text());
        return new UssdResponse(reply.message(), reply.end(), (reply.end() ? "END " : "CON ") + reply.message(), true);
    }
}
