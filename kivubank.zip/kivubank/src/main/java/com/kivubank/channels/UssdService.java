package com.kivubank.channels;

import com.kivubank.account.Account;
import com.kivubank.account.AccountDtos.AccountLookup;
import com.kivubank.account.AccountService;
import com.kivubank.account.PinService;
import com.kivubank.common.BusinessException;
import com.kivubank.common.Hashing;
import com.kivubank.config.KivuBankProperties;
import com.kivubank.transaction.Channel;
import com.kivubank.transaction.TransactionDtos.TransactionView;
import com.kivubank.transaction.TransactionDtos.TransferRequest;
import com.kivubank.transaction.TransactionFacade;
import com.kivubank.transaction.TransactionFacade.IdempotentResult;
import com.kivubank.transaction.TransactionQueryService;
import com.kivubank.user.PhoneNumbers;
import com.kivubank.user.Role;
import com.kivubank.user.User;
import com.kivubank.user.UserRepository;
import com.kivubank.user.UserStatus;
import java.math.BigDecimal;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * SIMULATED USSD menu (dial *123#). Stateless in the style of USSD aggregators: the client sends the accumulated
 * input ("2*1043820917*500*4829*1") on every hop. It calls the same services as the REST API (PIN lockout,
 * idempotent transfers, limits). It is not connected to any telecom operator.
 */
@Service
public class UssdService {
    public static final String SERVICE_CODE = "*123#";
    private static final Logger log = LoggerFactory.getLogger(UssdService.class);
    private static final String MENU = "Welcome to KivuBank (SIMULATOR)\n1. Check Balance\n2. Transfer Money\n3. Mini Statement\n4. Exit";

    private final UserRepository users;
    private final PhoneNumbers phones;
    private final AccountService accountService;
    private final PinService pins;
    private final TransactionFacade facade;
    private final TransactionQueryService queries;
    private final KivuBankProperties props;

    public UssdService(UserRepository users, PhoneNumbers phones, AccountService accountService, PinService pins,
                       TransactionFacade facade, TransactionQueryService queries, KivuBankProperties props) {
        this.users = users;
        this.phones = phones;
        this.accountService = accountService;
        this.pins = pins;
        this.facade = facade;
        this.queries = queries;
        this.props = props;
    }

    public record Reply(String message, boolean end) {
        static Reply con(String m) {
            return new Reply(m, false);
        }

        static Reply end(String m) {
            return new Reply(m, true);
        }
    }

    public Reply handle(String sessionId, String serviceCode, String phoneNumber, String text) {
        if (!props.simulators().ussdEnabled()) {
            return Reply.end("The USSD simulator is disabled.");
        }
        if (serviceCode == null || !SERVICE_CODE.equals(serviceCode.trim())) {
            return Reply.end("Invalid USSD code. Dial " + SERVICE_CODE);
        }
        String msisdn = phones.normalizeOrNull(phoneNumber);
        User user = msisdn == null ? null : users.findByPhone(msisdn).orElse(null);
        if (user == null || user.getStatus() != UserStatus.ACTIVE || user.getRole() != Role.CUSTOMER) {
            return Reply.end("This number is not registered for KivuBank (simulator).");
        }
        String[] parts = text == null || text.isBlank() ? new String[0] : text.split("\\*", -1);
        try {
            if (parts.length == 0) {
                return Reply.con(MENU);
            }
            return switch (parts[0]) {
                case "1" -> balance(user, parts);
                case "2" -> transfer(user, sessionId, text, parts);
                case "3" -> miniStatement(user, parts);
                case "4" -> Reply.end("Thank you for using KivuBank (simulator). Goodbye.");
                default -> Reply.end("Invalid choice.");
            };
        } catch (BusinessException e) {
            return Reply.end(e.getMessage());
        } catch (RuntimeException e) {
            log.error("USSD simulator error", e);
            return Reply.end("Service unavailable. Please try again later.");
        }
    }

    private Reply balance(User user, String[] parts) {
        if (parts.length == 1) {
            return Reply.con("Enter your PIN:");
        }
        Account account = verifiedAccount(user, parts[1]);
        return Reply.end("Balance: " + account.getBalance().toPlainString() + " " + account.getCurrency());
    }

    private Reply miniStatement(User user, String[] parts) {
        if (parts.length == 1) {
            return Reply.con("Enter your PIN:");
        }
        verifiedAccount(user, parts[1]);
        List<TransactionView> recent = queries.recentForUser(user.getId(), 5);
        if (recent.isEmpty()) {
            return Reply.end("No transactions yet.");
        }
        StringBuilder sb = new StringBuilder("Mini statement:\n");
        for (TransactionView v : recent) {
            sb.append("DEBIT".equals(v.direction()) ? "-" : "+").append(v.amount().toPlainString()).append(' ')
                    .append(v.type()).append(' ').append(v.status()).append('\n');
        }
        return Reply.end(sb.toString().trim());
    }

    private Reply transfer(User user, String sessionId, String text, String[] parts) {
        switch (parts.length) {
            case 1:
                return Reply.con("Enter recipient account number:");
            case 2: {
                AccountLookup to = lookup(parts[1]);
                return Reply.con("Send to " + to.ownerNameMasked() + " (" + to.accountNumber() + ")\nEnter amount:");
            }
            case 3:
                lookup(parts[1]);
                parseAmount(parts[2]);
                return Reply.con("Enter your PIN:");
            case 4: {
                AccountLookup to = lookup(parts[1]);
                BigDecimal amount = parseAmount(parts[2]);
                requirePinFormat(parts[3]);
                return Reply.con("Confirm transfer of " + amount.toPlainString() + " " + to.currency() + " to "
                        + to.ownerNameMasked() + "?\n1. Yes\n2. No");
            }
            case 5: {
                if (!"1".equals(parts[4])) {
                    return Reply.end("Transfer cancelled.");
                }
                lookup(parts[1]);
                BigDecimal amount = parseAmount(parts[2]);
                requirePinFormat(parts[3]);
                String key = "ussd-" + Hashing.sha256Hex((sessionId == null ? "" : sessionId) + "|" + text).substring(0, 32);
                IdempotentResult result = facade.transfer(user.getId(), key,
                        new TransferRequest(parts[1], amount, parts[3], "USSD transfer"), Channel.USSD);
                TransactionView v = result.view();
                return switch (v.status()) {
                    case SUCCESS -> Reply.end("Transfer successful. Ref " + v.reference());
                    case PENDING -> Reply.end("Transfer submitted for approval. Ref " + v.reference());
                    default -> Reply.end("Transfer failed: " + (v.failureReason() == null ? v.status() : v.failureReason()));
                };
            }
            default:
                return Reply.end("Invalid input.");
        }
    }

    private Account verifiedAccount(User user, String pin) {
        requirePinFormat(pin);
        Account account = accountService.requireByUser(user.getId());
        pins.verify(account.getId(), pin);
        return account;
    }

    private AccountLookup lookup(String accountNumber) {
        if (!accountNumber.matches("^\\d{6,20}$")) {
            throw new BusinessException(com.kivubank.common.ErrorCode.VALIDATION_FAILED, "Invalid account number.");
        }
        return accountService.lookup(accountNumber);
    }

    private BigDecimal parseAmount(String raw) {
        try {
            BigDecimal amount = new BigDecimal(raw.trim());
            if (amount.signum() <= 0 || amount.stripTrailingZeros().scale() > 2) {
                throw new NumberFormatException();
            }
            return amount;
        } catch (NumberFormatException e) {
            throw new BusinessException(com.kivubank.common.ErrorCode.INVALID_AMOUNT, "Invalid amount.");
        }
    }

    private void requirePinFormat(String pin) {
        if (pin == null || !pin.matches("^\\d{4,6}$")) {
            throw new BusinessException(com.kivubank.common.ErrorCode.VALIDATION_FAILED, "Invalid PIN format.");
        }
    }
}
