package com.kivubank.ops;

import com.kivubank.account.AccountRepository;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

/** Application-level health check: no account may have a negative balance (also enforced by a DB CHECK constraint). */
@Component("ledger")
public class LedgerHealthIndicator implements HealthIndicator {
    private final AccountRepository accounts;

    public LedgerHealthIndicator(AccountRepository accounts) {
        this.accounts = accounts;
    }

    @Override
    public Health health() {
        try {
            long negative = accounts.countNegativeBalances();
            return negative == 0 ? Health.up().withDetail("negativeBalances", 0).build()
                    : Health.down().withDetail("negativeBalances", negative).build();
        } catch (RuntimeException e) {
            return Health.down().withDetail("error", e.getClass().getSimpleName()).build();
        }
    }
}
