package com.kivubank.ops;

import com.kivubank.ops.OperationsService.Dashboard;
import com.kivubank.ops.OperationsService.HealthSummary;
import com.kivubank.ops.OperationsService.HttpStats;
import com.kivubank.ops.OperationsService.JvmInfo;
import com.kivubank.ops.OperationsService.TrendPoint;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import java.util.Map;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/ops")
@Tag(name = "Operations", description = "Operations dashboard and monitoring summaries (ADMIN, SUPPORT_AGENT, AUDITOR). "
        + "Raw Actuator endpoints are at /actuator (health is public and minimal; metrics and prometheus require ADMIN).")
@SecurityRequirement(name = "bearerAuth")
@PreAuthorize("hasAnyRole('ADMIN','SUPPORT_AGENT','AUDITOR')")
public class OperationsController {
    private final OperationsService service;

    public OperationsController(OperationsService service) {
        this.service = service;
    }

    @GetMapping("/dashboard")
    @Operation(summary = "Operations dashboard snapshot",
            description = "Health, transaction counts and success rate, average response time, active users, incidents, recent audit events and alerts. Data is simulated.")
    public Dashboard dashboard() {
        return service.dashboard();
    }

    @GetMapping("/health")
    @Operation(summary = "Service availability", description = "Overall status, per-component status, database round-trip latency and uptime.")
    public HealthSummary health() {
        return service.health();
    }

    @GetMapping("/metrics")
    @Operation(summary = "HTTP and JVM metrics summary", description = "Derived from Micrometer: request counts, mean/max latency, error rates, slowest endpoints, heap and threads.")
    public Map<String, Object> metrics() {
        HttpStats http = service.httpStats();
        JvmInfo jvm = service.jvm();
        return Map.of("http", http, "jvm", jvm);
    }

    @GetMapping("/transactions/trend")
    @Operation(summary = "Hourly transaction trend", description = "Successful, failed and other transactions per hour for the last N hours (max 168).")
    public List<TrendPoint> trend(@RequestParam(defaultValue = "24") int hours) {
        return service.trend(hours);
    }
}
