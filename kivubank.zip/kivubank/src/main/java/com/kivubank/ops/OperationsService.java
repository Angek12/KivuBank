package com.kivubank.ops;

import com.kivubank.account.AccountRepository;
import com.kivubank.account.AccountStatus;
import com.kivubank.anomaly.AnomalyAssessmentRepository;
import com.kivubank.audit.AuditController.AuditEventView;
import com.kivubank.audit.AuditEventRepository;
import com.kivubank.incident.IncidentRepository;
import com.kivubank.incident.IncidentService;
import com.kivubank.incident.IncidentService.IncidentView;
import com.kivubank.incident.IncidentSeverity;
import com.kivubank.incident.IncidentStatus;
import com.kivubank.transaction.TransactionRepository;
import com.kivubank.transaction.TransactionStatus;
import com.kivubank.user.Role;
import com.kivubank.user.UserRepository;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryUsage;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;
import org.springframework.boot.actuate.health.CompositeHealth;
import org.springframework.boot.actuate.health.HealthComponent;
import org.springframework.boot.actuate.health.HealthEndpoint;
import org.springframework.data.domain.PageRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Aggregates operational data for the dashboard from the database, Actuator health and Micrometer metrics. */
@Service
public class OperationsService {
    public static final String DISCLOSURE = "All customers, accounts and transactions in KivuBank are SIMULATED. "
            + "No real money moves and nothing here is connected to a real bank.";

    private final TransactionRepository transactions;
    private final AccountRepository accounts;
    private final UserRepository users;
    private final AuditEventRepository auditEvents;
    private final IncidentRepository incidents;
    private final IncidentService incidentService;
    private final AnomalyAssessmentRepository anomalies;
    private final HealthEndpoint healthEndpoint;
    private final MeterRegistry meters;
    private final JdbcTemplate jdbc;
    private final Clock clock;

    public OperationsService(TransactionRepository transactions, AccountRepository accounts, UserRepository users,
                             AuditEventRepository auditEvents, IncidentRepository incidents, IncidentService incidentService,
                             AnomalyAssessmentRepository anomalies, HealthEndpoint healthEndpoint, MeterRegistry meters,
                             JdbcTemplate jdbc, Clock clock) {
        this.transactions = transactions;
        this.accounts = accounts;
        this.users = users;
        this.auditEvents = auditEvents;
        this.incidents = incidents;
        this.incidentService = incidentService;
        this.anomalies = anomalies;
        this.healthEndpoint = healthEndpoint;
        this.meters = meters;
        this.jdbc = jdbc;
        this.clock = clock;
    }

    // ---- DTOs --------------------------------------------------------------------------------------------------
    public record ComponentHealth(String name, String status) {
    }

    public record HealthSummary(String status, List<ComponentHealth> components, long databaseLatencyMs, long uptimeSeconds,
                                Instant startedAt) {
    }

    public record TransactionStats(long total, Map<String, Long> byStatus, long last24hTotal, Map<String, Long> last24hByStatus,
                                   Double successRateAllTime, Double successRateLast24h, long pendingReview) {
    }

    public record EndpointLatency(String uri, long requests, double meanMs, double maxMs) {
    }

    public record HttpStats(long totalRequests, double averageResponseMs, double maxResponseMs, long clientErrors,
                            long serverErrors, double errorRatePercent, List<EndpointLatency> slowestEndpoints) {
    }

    public record JvmInfo(String javaVersion, String vendor, int processors, long heapUsedMb, long heapMaxMb,
                          int liveThreads, double systemLoadAverage) {
    }

    public record UserStats(long customers, long staff, long activeUsersLast30Min, long frozenAccounts, long totalAccounts) {
    }

    public record Alert(String level, String message) {
    }

    public record Dashboard(Instant generatedAt, String dataDisclosure, HealthSummary health, TransactionStats transactions,
                            HttpStats http, UserStats users, long openIncidents, List<IncidentView> recentIncidents,
                            List<AuditEventView> recentAuditEvents, long flaggedAnomalies24h, List<Alert> alerts, JvmInfo jvm) {
    }

    public record TrendPoint(Instant hour, long success, long failed, long other) {
    }

    // ---- queries -----------------------------------------------------------------------------------------------
    @Transactional(readOnly = true)
    public Dashboard dashboard() {
        Instant now = clock.instant();
        HealthSummary health = health();
        TransactionStats tx = transactionStats(now);
        HttpStats http = httpStats();
        long openIncidents = incidents.countByStatusIn(activeIncidentStatuses());
        long flagged24h = anomalies.countByFlaggedTrueAndCreatedAtAfter(now.minus(Duration.ofHours(24)));
        UserStats userStats = new UserStats(users.countByRole(Role.CUSTOMER), users.count() - users.countByRole(Role.CUSTOMER),
                auditEvents.countDistinctLoginsSince(now.minus(Duration.ofMinutes(30))),
                accounts.countByStatus(AccountStatus.FROZEN), accounts.count());
        List<AuditEventView> recentAudit = auditEvents.findAllByOrderByOccurredAtDesc(PageRequest.of(0, 10)).stream()
                .map(AuditEventView::of).toList();
        return new Dashboard(now, DISCLOSURE, health, tx, http, userStats, openIncidents, incidentService.recent(5),
                recentAudit, flagged24h, alerts(health, now, http, flagged24h, tx), jvm());
    }

    public HealthSummary health() {
        HealthComponent root = healthEndpoint.health();
        List<ComponentHealth> components = new ArrayList<>();
        if (root instanceof CompositeHealth composite) {
            composite.getComponents().forEach((name, c) -> components.add(new ComponentHealth(name, c.getStatus().getCode())));
        }
        long started = System.nanoTime();
        try {
            jdbc.queryForObject("select 1", Integer.class);
        } catch (RuntimeException ignored) {
            // reflected by the db health component
        }
        long latency = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - started);
        long startMillis = ManagementFactory.getRuntimeMXBean().getStartTime();
        return new HealthSummary(root.getStatus().getCode(), components, latency,
                ManagementFactory.getRuntimeMXBean().getUptime() / 1000, Instant.ofEpochMilli(startMillis));
    }

    @Transactional(readOnly = true)
    public TransactionStats transactionStats(Instant now) {
        Map<String, Long> all = statusMap(transactions.countGroupedByStatus());
        Map<String, Long> day = statusMap(transactions.countGroupedByStatusSince(now.minus(Duration.ofHours(24))));
        long total = all.values().stream().mapToLong(Long::longValue).sum();
        long dayTotal = day.values().stream().mapToLong(Long::longValue).sum();
        return new TransactionStats(total, all, dayTotal, day, rate(all), rate(day), all.getOrDefault("PENDING", 0L));
    }

    public HttpStats httpStats() {
        long count = 0;
        double totalMs = 0;
        double maxMs = 0;
        long client = 0;
        long server = 0;
        Map<String, double[]> perUri = new LinkedHashMap<>();   // uri -> {count, totalMs, maxMs}
        for (Timer timer : meters.find("http.server.requests").timers()) {
            String uri = timer.getId().getTag("uri");
            if (uri == null || !uri.startsWith("/api")) {
                continue;
            }
            long c = timer.count();
            double t = timer.totalTime(TimeUnit.MILLISECONDS);
            double m = timer.max(TimeUnit.MILLISECONDS);
            count += c;
            totalMs += t;
            maxMs = Math.max(maxMs, m);
            String status = timer.getId().getTag("status");
            if (status != null && status.startsWith("4")) client += c;
            if (status != null && status.startsWith("5")) server += c;
            double[] agg = perUri.computeIfAbsent(uri, k -> new double[3]);
            agg[0] += c;
            agg[1] += t;
            agg[2] = Math.max(agg[2], m);
        }
        List<EndpointLatency> slowest = perUri.entrySet().stream()
                .map(e -> new EndpointLatency(e.getKey(), (long) e.getValue()[0],
                        round(e.getValue()[0] == 0 ? 0 : e.getValue()[1] / e.getValue()[0]), round(e.getValue()[2])))
                .sorted(Comparator.comparingDouble(EndpointLatency::meanMs).reversed()).limit(5).toList();
        return new HttpStats(count, round(count == 0 ? 0 : totalMs / count), round(maxMs), client, server,
                round(count == 0 ? 0 : 100.0 * (client + server) / count), slowest);
    }

    public JvmInfo jvm() {
        MemoryUsage heap = ManagementFactory.getMemoryMXBean().getHeapMemoryUsage();
        return new JvmInfo(System.getProperty("java.version"), System.getProperty("java.vendor"),
                Runtime.getRuntime().availableProcessors(), heap.getUsed() / (1024 * 1024), heap.getMax() / (1024 * 1024),
                ManagementFactory.getThreadMXBean().getThreadCount(),
                round(ManagementFactory.getOperatingSystemMXBean().getSystemLoadAverage()));
    }

    @Transactional(readOnly = true)
    public List<TrendPoint> trend(int hours) {
        int h = Math.min(Math.max(hours, 1), 168);
        Instant now = clock.instant();
        Instant since = now.minus(Duration.ofHours(h)).truncatedTo(ChronoUnit.HOURS);
        Map<Instant, long[]> buckets = new TreeMap<>();
        for (Instant t = since; !t.isAfter(now); t = t.plus(Duration.ofHours(1))) {
            buckets.put(t, new long[3]);
        }
        for (Object[] row : transactions.findTrendRows(since)) {
            Instant created = (Instant) row[0];
            TransactionStatus status = (TransactionStatus) row[1];
            long[] b = buckets.get(created.truncatedTo(ChronoUnit.HOURS));
            if (b == null) continue;
            if (status == TransactionStatus.SUCCESS) b[0]++;
            else if (status == TransactionStatus.FAILED) b[1]++;
            else b[2]++;
        }
        return buckets.entrySet().stream().map(e -> new TrendPoint(e.getKey(), e.getValue()[0], e.getValue()[1], e.getValue()[2])).toList();
    }

    // ---- helpers -----------------------------------------------------------------------------------------------
    private List<Alert> alerts(HealthSummary health, Instant now, HttpStats http, long flagged24h, TransactionStats tx) {
        List<Alert> out = new ArrayList<>();
        if (!"UP".equals(health.status())) {
            out.add(new Alert("CRITICAL", "Overall health status is " + health.status() + "."));
        }
        for (ComponentHealth c : health.components()) {
            if (!"UP".equals(c.status()) && !"UNKNOWN".equals(c.status())) {
                out.add(new Alert("HIGH", "Health component '" + c.name() + "' is " + c.status() + "."));
            }
        }
        Map<String, Long> lastHour = statusMap(transactions.countGroupedByStatusSince(now.minus(Duration.ofHours(1))));
        long success = lastHour.getOrDefault("SUCCESS", 0L);
        long failed = lastHour.getOrDefault("FAILED", 0L);
        if (success + failed >= 10 && failed * 10 > (success + failed)) {
            out.add(new Alert("HIGH", "More than 10% of transactions failed in the last hour (" + failed + " of " + (success + failed) + ")."));
        }
        long severe = incidents.findByStatusInAndSeverityIn(activeIncidentStatuses(),
                List.of(IncidentSeverity.CRITICAL, IncidentSeverity.HIGH)).size();
        if (severe > 0) {
            out.add(new Alert("HIGH", severe + " high/critical incident(s) are still active."));
        }
        if (http.serverErrors() > 0) {
            out.add(new Alert("WARNING", http.serverErrors() + " HTTP 5xx response(s) since the application started."));
        }
        if (flagged24h > 0) {
            out.add(new Alert("WARNING", flagged24h + " transaction(s) flagged by the experimental anomaly model in the last 24h."));
        }
        if (tx.pendingReview() > 0) {
            out.add(new Alert("INFO", tx.pendingReview() + " transfer(s) awaiting manual approval."));
        }
        return out;
    }

    private static List<IncidentStatus> activeIncidentStatuses() {
        return List.of(IncidentStatus.OPEN, IncidentStatus.INVESTIGATING, IncidentStatus.MITIGATED);
    }

    private static Map<String, Long> statusMap(List<Object[]> rows) {
        Map<TransactionStatus, Long> raw = new EnumMap<>(TransactionStatus.class);
        for (TransactionStatus s : TransactionStatus.values()) {
            raw.put(s, 0L);
        }
        for (Object[] r : rows) {
            raw.put((TransactionStatus) r[0], ((Number) r[1]).longValue());
        }
        Map<String, Long> out = new LinkedHashMap<>();
        raw.forEach((k, v) -> out.put(k.name(), v));
        return out;
    }

    private static Double rate(Map<String, Long> byStatus) {
        long success = byStatus.getOrDefault("SUCCESS", 0L);
        long failed = byStatus.getOrDefault("FAILED", 0L);
        return success + failed == 0 ? null : Math.round(10000.0 * success / (success + failed)) / 100.0;
    }

    private static double round(double v) {
        return Double.isNaN(v) || v < 0 ? 0 : Math.round(v * 100.0) / 100.0;
    }
}
