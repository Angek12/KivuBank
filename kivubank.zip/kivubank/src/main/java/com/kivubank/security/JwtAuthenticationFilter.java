package com.kivubank.security;

import com.kivubank.auth.AuthenticatedUser;
import com.kivubank.auth.JwtService;
import com.kivubank.auth.RevokedTokenRepository;
import com.kivubank.user.User;
import com.kivubank.user.UserRepository;
import com.kivubank.user.UserStatus;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.temporal.ChronoUnit;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Validates the Bearer token: signature, issuer, expiry, revocation (logout), account status and
 * "issued before last password change". An invalid token simply leaves the request unauthenticated (401 downstream).
 */
public class JwtAuthenticationFilter extends OncePerRequestFilter {
    private final JwtService jwtService;
    private final UserRepository users;
    private final RevokedTokenRepository revoked;

    public JwtAuthenticationFilter(JwtService jwtService, UserRepository users, RevokedTokenRepository revoked) {
        this.jwtService = jwtService;
        this.users = users;
        this.revoked = revoked;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String header = request.getHeader("Authorization");
        if (header != null && header.startsWith("Bearer ")) {
            authenticate(header.substring(7).trim());
        }
        chain.doFilter(request, response);
    }

    private void authenticate(String token) {
        jwtService.parse(token).ifPresent(claims -> {
            if (revoked.existsById(claims.jti())) {
                return;
            }
            User user = users.findById(claims.userId()).orElse(null);
            if (user == null || user.getStatus() != UserStatus.ACTIVE) {
                return;
            }
            if (user.getPasswordChangedAt() != null
                    && claims.issuedAt().isBefore(user.getPasswordChangedAt().truncatedTo(ChronoUnit.SECONDS))) {
                return;
            }
            var principal = new AuthenticatedUser(user.getId(), user.getEmail(), user.getRole());
            SecurityContextHolder.getContext().setAuthentication(
                    new AuthenticatedUser.KivuAuthentication(principal, claims.jti(), claims.expiresAt()));
        });
    }
}
