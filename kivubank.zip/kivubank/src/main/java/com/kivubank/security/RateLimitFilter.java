package com.kivubank.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kivubank.common.ApiError;
import com.kivubank.common.ErrorCode;
import com.kivubank.common.RequestIdFilter;
import com.kivubank.config.KivuBankProperties;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.Clock;
import java.time.Instant;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.MDC;
import org.springframework.http.MediaType;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Sliding-window, in-memory rate limiter for sensitive endpoints, keyed by client IP + endpoint group.
 * Single-instance only; a shared store (e.g. Redis) would be required for horizontal scaling.
 */
public class RateLimitFilter extends OncePerRequestFilter {
    private static final long WINDOW_MILLIS = 60_000L;
    private final KivuBankProperties.RateLimit config;
    private final Clock clock;
    private final ObjectMapper mapper;
    private final ConcurrentHashMap<String, Deque<Long>> hits = new ConcurrentHashMap<>();

    public RateLimitFilter(KivuBankProperties.RateLimit config, Clock clock, ObjectMapper mapper) {
        this.config = config;
        this.clock = clock;
        this.mapper = mapper;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
            throws ServletException, IOException {
        if (config.enabled()) {
            String group = groupFor(req);
            if (group != null && !allow(req.getRemoteAddr() + "|" + group, limitFor(group))) {
                reject(req, res);
                return;
            }
        }
        chain.doFilter(req, res);
    }

    String groupFor(HttpServletRequest req) {
        String path = req.getRequestURI();
        String method = req.getMethod();
        if (path.equals("/api/auth/login")) return "login";
        if (path.equals("/api/auth/register")) return "register";
        if (path.startsWith("/api/ussd")) return "ussd";
        if (path.startsWith("/api/accounts/me/pin")) return "pin";
        if (path.startsWith("/api/transactions/") && "POST".equals(method)) return "financial";
        return null;
    }

    private int limitFor(String group) {
        return switch (group) {
            case "login" -> config.loginPerMinute();
            case "register" -> config.registerPerMinute();
            case "ussd" -> config.ussdPerMinute();
            case "pin" -> config.pinPerMinute();
            default -> config.financialPerMinute();
        };
    }

    boolean allow(String key, int limit) {
        long now = clock.millis();
        Deque<Long> window = hits.computeIfAbsent(key, k -> new ArrayDeque<>());
        synchronized (window) {
            while (!window.isEmpty() && now - window.peekFirst() > WINDOW_MILLIS) {
                window.pollFirst();
            }
            if (window.size() >= limit) {
                return false;
            }
            window.addLast(now);
            return true;
        }
    }

    private void reject(HttpServletRequest req, HttpServletResponse res) throws IOException {
        res.setStatus(429);
        res.setHeader("Retry-After", "60");
        res.setContentType(MediaType.APPLICATION_JSON_VALUE);
        ApiError body = new ApiError(Instant.now(), 429, ErrorCode.RATE_LIMITED.name(),
                "Too many requests. Please slow down and retry later.", req.getRequestURI(),
                MDC.get(RequestIdFilter.MDC_KEY), null);
        mapper.writeValue(res.getWriter(), body);
    }
}
