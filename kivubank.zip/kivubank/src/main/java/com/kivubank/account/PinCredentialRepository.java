package com.kivubank.account;

import java.time.Instant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface PinCredentialRepository extends JpaRepository<PinCredential, Long> {
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update PinCredential c set c.failedAttempts = c.failedAttempts + 1, c.updatedAt = :now where c.accountId = :id")
    int incrementFailures(@Param("id") Long accountId, @Param("now") Instant now);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update PinCredential c set c.lockedUntil = :until, c.updatedAt = :now where c.accountId = :id")
    int lock(@Param("id") Long accountId, @Param("until") Instant until, @Param("now") Instant now);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("update PinCredential c set c.failedAttempts = 0, c.lockedUntil = null, c.updatedAt = :now where c.accountId = :id")
    int reset(@Param("id") Long accountId, @Param("now") Instant now);
}
