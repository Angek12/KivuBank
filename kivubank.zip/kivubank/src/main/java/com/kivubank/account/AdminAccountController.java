package com.kivubank.account;

import com.kivubank.account.AccountDtos.AdminAccountView;
import com.kivubank.common.PageResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/admin/accounts")
@Tag(name = "Admin - Accounts", description = "Staff account oversight.")
@SecurityRequirement(name = "bearerAuth")
public class AdminAccountController {
    private final AccountService accountService;

    public AdminAccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','SUPPORT_AGENT','AUDITOR')")
    @Operation(summary = "List accounts (staff)")
    public PageResponse<AdminAccountView> list(@RequestParam(defaultValue = "0") int page,
                                               @RequestParam(defaultValue = "25") int size) {
        return accountService.listAll(PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100), Sort.by("id")));
    }

    @PostMapping("/{accountNumber}/freeze")
    @PreAuthorize("hasRole('ADMIN')")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Freeze an account (ADMIN)", description = "A frozen account cannot send or receive funds.")
    public void freeze(@PathVariable String accountNumber) {
        accountService.setFrozen(accountNumber, true);
    }

    @PostMapping("/{accountNumber}/unfreeze")
    @PreAuthorize("hasRole('ADMIN')")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Unfreeze an account (ADMIN)")
    public void unfreeze(@PathVariable String accountNumber) {
        accountService.setFrozen(accountNumber, false);
    }
}
