package com.kivubank.account;

public enum AccountStatus { ACTIVE, FROZEN, CLOSED }
