package com.kivubank.account;

import java.util.Set;

/** PIN format rules: 4-6 digits, not trivially guessable. */
public final class PinPolicy {
    private static final Set<String> COMMON = Set.of("1234", "4321", "0000", "1212", "2580", "1004", "2000", "6969",
            "123456", "654321", "000000", "121212", "112233");

    private PinPolicy() {
    }

    /** Returns an error message, or null when the PIN is acceptable. */
    public static String violation(String pin) {
        if (pin == null || !pin.matches("^\\d{4,6}$")) {
            return "PIN must be 4 to 6 digits.";
        }
        if (COMMON.contains(pin) || allSame(pin) || sequential(pin)) {
            return "PIN is too easy to guess. Avoid repeated or sequential digits.";
        }
        return null;
    }

    private static boolean allSame(String pin) {
        return pin.chars().distinct().count() == 1;
    }

    private static boolean sequential(String pin) {
        boolean asc = true;
        boolean desc = true;
        for (int i = 1; i < pin.length(); i++) {
            int diff = pin.charAt(i) - pin.charAt(i - 1);
            asc &= diff == 1;
            desc &= diff == -1;
        }
        return asc || desc;
    }
}
