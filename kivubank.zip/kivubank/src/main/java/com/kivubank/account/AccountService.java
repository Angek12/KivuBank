package com.kivubank.account;

import com.kivubank.account.AccountDtos.AccountLookup;
import com.kivubank.account.AccountDtos.AccountView;
import com.kivubank.account.AccountDtos.AdminAccountView;
import com.kivubank.audit.AuditAction;
import com.kivubank.audit.AuditOutcome;
import com.kivubank.audit.AuditService;
import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import com.kivubank.common.PageResponse;
import com.kivubank.config.KivuBankProperties;
import com.kivubank.user.User;
import com.kivubank.user.UserRepository;
import java.security.SecureRandom;
import java.time.Clock;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AccountService {
    private final AccountRepository accounts;
    private final UserRepository users;
    private final PinService pins;
    private final AuditService audit;
    private final KivuBankProperties props;
    private final Clock clock;
    private final SecureRandom random = new SecureRandom();

    public AccountService(AccountRepository accounts, UserRepository users, PinService pins, AuditService audit,
                          KivuBankProperties props, Clock clock) {
        this.accounts = accounts;
        this.users = users;
        this.pins = pins;
        this.audit = audit;
        this.props = props;
        this.clock = clock;
    }

    @Transactional
    public Account openAccount(Long userId) {
        for (int i = 0; i < 20; i++) {
            String number = "10" + String.format("%08d", random.nextInt(100_000_000));
            if (!accounts.existsByAccountNumber(number)) {
                return accounts.save(new Account(number, userId, props.transactions().currency(), clock.instant()));
            }
        }
        throw new BusinessException(ErrorCode.INTERNAL_ERROR, "Could not allocate an account number.");
    }

    @Transactional(readOnly = true)
    public Account requireByUser(Long userId) {
        return accounts.findByUserId(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.ACCOUNT_NOT_FOUND, "Account not found."));
    }

    @Transactional(readOnly = true)
    public AccountView viewForUser(Long userId) {
        Account a = requireByUser(userId);
        return new AccountView(a.getAccountNumber(), a.getBalance(), a.getCurrency(), a.getStatus(),
                pins.isSet(a.getId()), a.getCreatedAt());
    }

    @Transactional(readOnly = true)
    public AccountLookup lookup(String accountNumber) {
        Account a = accounts.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new BusinessException(ErrorCode.ACCOUNT_NOT_FOUND, "Account not found."));
        User owner = users.findById(a.getUserId()).orElseThrow();
        return new AccountLookup(a.getAccountNumber(), mask(owner.getFullName()), a.getCurrency());
    }

    @Transactional(readOnly = true)
    public PageResponse<AdminAccountView> listAll(Pageable pageable) {
        return PageResponse.of(accounts.findAll(pageable), a -> {
            User u = users.findById(a.getUserId()).orElse(null);
            return new AdminAccountView(a.getId(), a.getAccountNumber(), u == null ? null : u.getFullName(),
                    u == null ? null : u.getEmail(), a.getBalance(), a.getCurrency(), a.getStatus(), a.getCreatedAt());
        });
    }

    @Transactional
    public void setFrozen(String accountNumber, boolean frozen) {
        Account a = accounts.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new BusinessException(ErrorCode.ACCOUNT_NOT_FOUND, "Account not found."));
        a.setStatus(frozen ? AccountStatus.FROZEN : AccountStatus.ACTIVE, clock.instant());
        audit.record(frozen ? AuditAction.ADMIN_ACCOUNT_FROZEN : AuditAction.ADMIN_ACCOUNT_UNFROZEN,
                AuditOutcome.SUCCESS, "ACCOUNT", accountNumber, null);
    }

    static String mask(String fullName) {
        StringBuilder sb = new StringBuilder();
        for (String part : fullName.trim().split("\\s+")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(part.charAt(0)).append("***");
        }
        return sb.toString();
    }
}
