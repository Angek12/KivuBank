package com.kivubank.account;

import com.kivubank.config.KivuBankProperties;
import java.time.Clock;
import java.time.Instant;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/** Records PIN failures in a separate transaction so a rolled-back payment still counts the failed attempt. */
@Component
public class PinAttemptRecorder {
    private final PinCredentialRepository credentials;
    private final KivuBankProperties props;
    private final Clock clock;

    public PinAttemptRecorder(PinCredentialRepository credentials, KivuBankProperties props, Clock clock) {
        this.credentials = credentials;
        this.props = props;
        this.clock = clock;
    }

    /** @return remaining attempts before the PIN is locked (0 means it is now locked). */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public int recordFailure(Long accountId) {
        Instant now = clock.instant();
        credentials.incrementFailures(accountId, now);
        PinCredential c = credentials.findById(accountId).orElse(null);
        if (c == null) {
            return 0;
        }
        int max = props.security().maxPinAttempts();
        if (c.getFailedAttempts() >= max) {
            credentials.lock(accountId, now.plus(props.security().pinLockDuration()), now);
            return 0;
        }
        return max - c.getFailedAttempts();
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void reset(Long accountId) {
        credentials.reset(accountId, clock.instant());
    }
}
