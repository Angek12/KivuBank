package com.kivubank.account;

import jakarta.persistence.LockModeType;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface AccountRepository extends JpaRepository<Account, Long> {
    Optional<Account> findByAccountNumber(String accountNumber);

    Optional<Account> findByUserId(Long userId);

    boolean existsByAccountNumber(String accountNumber);

    /** Id-only lookups avoid loading (and caching) a stale entity before the row lock is taken. */
    @Query("select a.id from Account a where a.userId = :userId")
    Optional<Long> findIdByUserId(@Param("userId") Long userId);

    @Query("select a.id from Account a where a.accountNumber = :accountNumber")
    Optional<Long> findIdByAccountNumber(@Param("accountNumber") String accountNumber);

    /** Locks rows (SELECT ... FOR UPDATE) in ascending id order so concurrent transfers cannot deadlock. */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select a from Account a where a.id in :ids order by a.id")
    List<Account> lockAllByIdIn(@Param("ids") Collection<Long> ids);

    @Query("select count(a) from Account a where a.balance < 0")
    long countNegativeBalances();

    long countByStatus(AccountStatus status);
}
