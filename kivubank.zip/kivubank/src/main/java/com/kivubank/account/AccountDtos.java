package com.kivubank.account;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.Instant;

public final class AccountDtos {
    private AccountDtos() {
    }

    public record AccountView(String accountNumber, BigDecimal balance, String currency, AccountStatus status,
                              boolean pinSet, Instant createdAt) {
    }

    public record AdminAccountView(Long id, String accountNumber, String ownerName, String ownerEmail,
                                   BigDecimal balance, String currency, AccountStatus status, Instant createdAt) {
    }

    public record AccountLookup(String accountNumber, String ownerNameMasked, String currency) {
    }

    public record PinCreateRequest(
            @Schema(example = "4829") @NotBlank @Pattern(regexp = "^\\d{4,6}$", message = "PIN must be 4 to 6 digits") String pin,
            @NotBlank @Size(max = 100) String password) {
    }

    public record PinUpdateRequest(
            @NotBlank @Pattern(regexp = "^\\d{4,6}$", message = "PIN must be 4 to 6 digits") String currentPin,
            @Schema(example = "7391") @NotBlank @Pattern(regexp = "^\\d{4,6}$", message = "PIN must be 4 to 6 digits") String newPin,
            @NotBlank @Size(max = 100) String password) {
    }
}
