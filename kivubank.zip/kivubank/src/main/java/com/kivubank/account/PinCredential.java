package com.kivubank.account;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

/** PIN hash and lockout state, stored apart from the balance row so attempt counting never contends with transfers. */
@Entity
@Table(name = "pin_credentials")
public class PinCredential {
    @Id
    @Column(name = "account_id")
    private Long accountId;
    @Column(nullable = false)
    private String pinHash;
    @Column(nullable = false)
    private int failedAttempts;
    private Instant lockedUntil;
    @Column(nullable = false)
    private Instant updatedAt;

    protected PinCredential() {
    }

    public PinCredential(Long accountId, String pinHash, Instant now) {
        this.accountId = accountId;
        this.pinHash = pinHash;
        this.updatedAt = now;
    }

    public void changeHash(String pinHash, Instant now) {
        this.pinHash = pinHash;
        this.failedAttempts = 0;
        this.lockedUntil = null;
        this.updatedAt = now;
    }

    public Long getAccountId() { return accountId; }
    public String getPinHash() { return pinHash; }
    public int getFailedAttempts() { return failedAttempts; }
    public Instant getLockedUntil() { return lockedUntil; }
    public Instant getUpdatedAt() { return updatedAt; }
}
