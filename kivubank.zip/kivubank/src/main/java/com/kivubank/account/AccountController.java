package com.kivubank.account;

import com.kivubank.account.AccountDtos.AccountLookup;
import com.kivubank.account.AccountDtos.AccountView;
import com.kivubank.account.AccountDtos.PinCreateRequest;
import com.kivubank.account.AccountDtos.PinUpdateRequest;
import com.kivubank.auth.AuthenticatedUser;
import com.kivubank.transaction.StatementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import java.time.Instant;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/accounts")
@Validated
@Tag(name = "Accounts", description = "Customer account, balance, PIN management and statements (CUSTOMER role).")
@SecurityRequirement(name = "bearerAuth")
@PreAuthorize("hasRole('CUSTOMER')")
public class AccountController {
    private final AccountService accountService;
    private final PinService pinService;
    private final StatementService statementService;

    public AccountController(AccountService accountService, PinService pinService, StatementService statementService) {
        this.accountService = accountService;
        this.pinService = pinService;
        this.statementService = statementService;
    }

    @GetMapping("/me")
    @Operation(summary = "Get my account", description = "Returns account number, balance, currency, status and whether a PIN is set.")
    public AccountView me() {
        return accountService.viewForUser(AuthenticatedUser.current().id());
    }

    @PostMapping("/me/pin")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Create my transaction PIN",
            description = "Requires the account password. PIN must be 4-6 digits and not trivially guessable.",
            responses = {@ApiResponse(responseCode = "204", description = "PIN created"),
                    @ApiResponse(responseCode = "409", description = "PIN already set")})
    public void createPin(@Valid @RequestBody PinCreateRequest request) {
        pinService.create(AuthenticatedUser.current().id(), request.password(), request.pin());
    }

    @PutMapping("/me/pin")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Change my transaction PIN",
            description = "Requires the current PIN and the account password. Wrong PINs count towards a temporary lockout.")
    public void updatePin(@Valid @RequestBody PinUpdateRequest request) {
        pinService.update(AuthenticatedUser.current().id(), request.currentPin(), request.password(), request.newPin());
    }

    @GetMapping("/lookup/{accountNumber}")
    @Operation(summary = "Look up a destination account",
            description = "Confirms an account exists before a transfer and returns the masked owner name.")
    public AccountLookup lookup(@PathVariable @Pattern(regexp = "^\\d{6,20}$") String accountNumber) {
        return accountService.lookup(accountNumber);
    }

    @GetMapping(value = "/me/statement", produces = "text/csv")
    @Operation(summary = "Download an account statement (CSV)",
            description = "Defaults to the last 30 days; maximum range 366 days. Generates a STATEMENT notification.")
    public ResponseEntity<String> statement(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to) {
        String csv = statementService.generateCsv(AuthenticatedUser.current().id(), from, to);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"kivubank-statement.csv\"")
                .contentType(MediaType.parseMediaType("text/csv"))
                .body(csv);
    }
}
