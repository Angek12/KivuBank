package com.kivubank.account;

import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "accounts")
public class Account {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, unique = true, length = 20)
    private String accountNumber;
    @Column(nullable = false, unique = true)
    private Long userId;
    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal balance = BigDecimal.ZERO.setScale(2);
    @Column(nullable = false, length = 3)
    private String currency;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AccountStatus status = AccountStatus.ACTIVE;
    @Version
    private Long version;
    @Column(nullable = false)
    private Instant createdAt;
    @Column(nullable = false)
    private Instant updatedAt;

    protected Account() {
    }

    public Account(String accountNumber, Long userId, String currency, Instant now) {
        this.accountNumber = accountNumber;
        this.userId = userId;
        this.currency = currency;
        this.createdAt = now;
        this.updatedAt = now;
    }

    public void credit(BigDecimal amount, Instant now) {
        this.balance = balance.add(amount);
        this.updatedAt = now;
    }

    /** Debits the account; callers that want graceful failure must check the balance first. */
    public void debit(BigDecimal amount, Instant now) {
        if (balance.compareTo(amount) < 0) {
            throw new BusinessException(ErrorCode.INSUFFICIENT_FUNDS, "Insufficient funds.");
        }
        this.balance = balance.subtract(amount);
        this.updatedAt = now;
    }

    public boolean isActive() {
        return status == AccountStatus.ACTIVE;
    }

    public void setStatus(AccountStatus status, Instant now) {
        this.status = status;
        this.updatedAt = now;
    }

    public Long getId() { return id; }
    public String getAccountNumber() { return accountNumber; }
    public Long getUserId() { return userId; }
    public BigDecimal getBalance() { return balance; }
    public String getCurrency() { return currency; }
    public AccountStatus getStatus() { return status; }
    public Long getVersion() { return version; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
}
