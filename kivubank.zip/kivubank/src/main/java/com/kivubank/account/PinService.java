package com.kivubank.account;

import com.kivubank.audit.AuditAction;
import com.kivubank.audit.AuditOutcome;
import com.kivubank.audit.AuditService;
import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import com.kivubank.event.DomainEvents.SecurityChangeEvent;
import com.kivubank.user.User;
import com.kivubank.user.UserRepository;
import java.time.Clock;
import java.time.Instant;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** PIN lifecycle: create, change, verify (with lockout). PINs are BCrypt-hashed and never logged. */
@Service
public class PinService {
    private final PinCredentialRepository credentials;
    private final PinAttemptRecorder recorder;
    private final AccountRepository accounts;
    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final AuditService audit;
    private final ApplicationEventPublisher events;
    private final Clock clock;

    public PinService(PinCredentialRepository credentials, PinAttemptRecorder recorder, AccountRepository accounts,
                      UserRepository users, PasswordEncoder encoder, AuditService audit,
                      ApplicationEventPublisher events, Clock clock) {
        this.credentials = credentials;
        this.recorder = recorder;
        this.accounts = accounts;
        this.users = users;
        this.encoder = encoder;
        this.audit = audit;
        this.events = events;
        this.clock = clock;
    }

    public boolean isSet(Long accountId) {
        return credentials.existsById(accountId);
    }

    @Transactional
    public void create(Long userId, String password, String pin) {
        Account account = accountOf(userId);
        requirePassword(userId, password);
        if (credentials.existsById(account.getId())) {
            throw new BusinessException(ErrorCode.ALREADY_EXISTS, "A PIN is already set. Use the update endpoint.");
        }
        requireStrong(pin);
        credentials.save(new PinCredential(account.getId(), encoder.encode(pin), clock.instant()));
        audit.recordForUser(userId, AuditAction.PIN_CREATED, AuditOutcome.SUCCESS, "ACCOUNT", account.getAccountNumber(), null);
        events.publishEvent(new SecurityChangeEvent(userId, "PIN_CREATED"));
    }

    @Transactional
    public void update(Long userId, String currentPin, String password, String newPin) {
        Account account = accountOf(userId);
        requirePassword(userId, password);
        verify(account.getId(), currentPin);
        requireStrong(newPin);
        PinCredential credential = credentials.findById(account.getId())
                .orElseThrow(() -> new BusinessException(ErrorCode.PIN_NOT_SET, "No PIN is set for this account."));
        credential.changeHash(encoder.encode(newPin), clock.instant());
        audit.recordForUser(userId, AuditAction.PIN_CHANGED, AuditOutcome.SUCCESS, "ACCOUNT", account.getAccountNumber(), null);
        events.publishEvent(new SecurityChangeEvent(userId, "PIN_CHANGED"));
    }

    /** Verifies a PIN. Failed attempts are persisted independently and lock the PIN after the configured maximum. */
    public void verify(Long accountId, String pin) {
        PinCredential c = credentials.findById(accountId)
                .orElseThrow(() -> new BusinessException(ErrorCode.PIN_NOT_SET, "Set a PIN before making transactions."));
        Instant now = clock.instant();
        if (c.getLockedUntil() != null && c.getLockedUntil().isAfter(now)) {
            throw new BusinessException(ErrorCode.PIN_LOCKED, "PIN is temporarily locked after too many failed attempts.");
        }
        if (pin == null || !encoder.matches(pin, c.getPinHash())) {
            int remaining = recorder.recordFailure(accountId);
            audit.record(AuditAction.PIN_FAILED, AuditOutcome.FAILURE, "ACCOUNT_ID", String.valueOf(accountId), "remaining=" + remaining);
            if (remaining == 0) {
                audit.record(AuditAction.PIN_LOCKED, AuditOutcome.FAILURE, "ACCOUNT_ID", String.valueOf(accountId), null);
                throw new BusinessException(ErrorCode.PIN_LOCKED, "PIN is temporarily locked after too many failed attempts.");
            }
            throw new BusinessException(ErrorCode.PIN_INVALID, "Incorrect PIN. Attempts remaining: " + remaining + ".");
        }
        if (c.getFailedAttempts() > 0 || c.getLockedUntil() != null) {
            recorder.reset(accountId);
        }
    }

    private Account accountOf(Long userId) {
        return accounts.findByUserId(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.ACCOUNT_NOT_FOUND, "Account not found."));
    }

    private void requirePassword(Long userId, String password) {
        User user = users.findById(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.NOT_FOUND, "User not found."));
        if (password == null || !encoder.matches(password, user.getPasswordHash())) {
            audit.recordForUser(userId, AuditAction.PIN_FAILED, AuditOutcome.FAILURE, "USER", String.valueOf(userId), "wrong password");
            throw new BusinessException(ErrorCode.INVALID_CREDENTIALS, "Password is incorrect.");
        }
    }

    private void requireStrong(String pin) {
        String problem = PinPolicy.violation(pin);
        if (problem != null) {
            throw new BusinessException(ErrorCode.VALIDATION_FAILED, problem);
        }
    }
}
