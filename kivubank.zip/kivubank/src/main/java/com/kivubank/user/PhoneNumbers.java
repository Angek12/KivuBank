package com.kivubank.user;

import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber.PhoneNumber;
import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import org.springframework.stereotype.Component;

/** Validates and normalises phone numbers to E.164 (reuses libphonenumber, as the original project did). */
@Component
public class PhoneNumbers {
    private final PhoneNumberUtil util = PhoneNumberUtil.getInstance();

    public String normalize(String raw) {
        if (raw == null || raw.isBlank()) {
            throw invalid();
        }
        try {
            PhoneNumber parsed = util.parse(raw.trim(), null);
            if (!util.isValidNumber(parsed)) {
                throw invalid();
            }
            return util.format(parsed, PhoneNumberUtil.PhoneNumberFormat.E164);
        } catch (NumberParseException e) {
            throw invalid();
        }
    }

    /** Lenient variant used by the USSD simulator: returns null instead of throwing. */
    public String normalizeOrNull(String raw) {
        try {
            return normalize(raw);
        } catch (BusinessException e) {
            return null;
        }
    }

    private BusinessException invalid() {
        return new BusinessException(ErrorCode.VALIDATION_FAILED,
                "Phone number must be valid and in international format, e.g. +14155552671.");
    }
}
