package com.kivubank.user;

public enum Role {
    CUSTOMER, SUPPORT_AGENT, ADMIN, AUDITOR;

    public boolean isStaff() {
        return this != CUSTOMER;
    }
}
