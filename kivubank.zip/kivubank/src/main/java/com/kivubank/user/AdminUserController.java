package com.kivubank.user;

import com.kivubank.audit.AuditAction;
import com.kivubank.audit.AuditOutcome;
import com.kivubank.audit.AuditService;
import com.kivubank.auth.AuthenticatedUser;
import com.kivubank.auth.PasswordPolicy;
import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import com.kivubank.common.PageResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Locale;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/admin/users")
@Tag(name = "Admin - Users", description = "Staff user management (ADMIN only; AUDITOR may list).")
@SecurityRequirement(name = "bearerAuth")
public class AdminUserController {
    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final PhoneNumbers phones;
    private final AuditService audit;
    private final Clock clock;

    public AdminUserController(UserRepository users, PasswordEncoder encoder, PhoneNumbers phones, AuditService audit, Clock clock) {
        this.users = users;
        this.encoder = encoder;
        this.phones = phones;
        this.audit = audit;
        this.clock = clock;
    }

    public record StaffRequest(
            @NotBlank @Pattern(regexp = "^[\\p{L} .'-]{2,120}$") String fullName,
            @NotBlank @Email @Size(max = 190) String email,
            @NotBlank @Size(max = 25) String phone,
            @NotBlank @Size(max = 100) String password,
            @NotNull Role role) {
    }

    public record StatusRequest(@NotNull UserStatus status) {
    }

    public record UserView(Long id, String fullName, String email, String phone, Role role, UserStatus status,
                           Instant createdAt, Instant lastLoginAt) {
        static UserView of(User u) {
            return new UserView(u.getId(), u.getFullName(), u.getEmail(), u.getPhone(), u.getRole(), u.getStatus(),
                    u.getCreatedAt(), u.getLastLoginAt());
        }
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    @ResponseStatus(HttpStatus.CREATED)
    @Transactional
    @Operation(summary = "Create a staff user", description = "Creates SUPPORT_AGENT, AUDITOR or ADMIN users. Staff have no bank account.")
    public UserView createStaff(@Valid @RequestBody StaffRequest req) {
        if (req.role() == Role.CUSTOMER) {
            throw new BusinessException(ErrorCode.VALIDATION_FAILED, "Customers register themselves; choose a staff role.");
        }
        String email = req.email().trim().toLowerCase(Locale.ROOT);
        List<String> problems = PasswordPolicy.violations(req.password(), email, req.fullName());
        if (!problems.isEmpty()) {
            throw new BusinessException(ErrorCode.VALIDATION_FAILED, String.join(" ", problems));
        }
        String phone = phones.normalize(req.phone());
        if (users.existsByEmail(email) || users.existsByPhone(phone)) {
            throw new BusinessException(ErrorCode.ALREADY_EXISTS, "A user with these details already exists.");
        }
        User saved = users.save(new User(req.fullName().trim(), email, phone, encoder.encode(req.password()), req.role(), clock.instant()));
        audit.record(AuditAction.ADMIN_USER_CREATED, AuditOutcome.SUCCESS, "USER", String.valueOf(saved.getId()), "role=" + req.role());
        return UserView.of(saved);
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','AUDITOR')")
    @Transactional(readOnly = true)
    @Operation(summary = "List users")
    public PageResponse<UserView> list(@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "25") int size) {
        return PageResponse.of(users.findAll(PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100), Sort.by("id"))), UserView::of);
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasRole('ADMIN')")
    @Transactional
    @Operation(summary = "Enable or disable a user", description = "Disabled users cannot authenticate; existing tokens stop working. Admins cannot disable themselves.")
    public UserView setStatus(@PathVariable Long id, @Valid @RequestBody StatusRequest req) {
        if (AuthenticatedUser.current().id().equals(id)) {
            throw new BusinessException(ErrorCode.VALIDATION_FAILED, "You cannot change your own status.");
        }
        User user = users.findById(id).orElseThrow(() -> new BusinessException(ErrorCode.NOT_FOUND, "User not found."));
        user.setStatus(req.status());
        audit.record(AuditAction.ADMIN_USER_STATUS_CHANGED, AuditOutcome.SUCCESS, "USER", String.valueOf(id), "status=" + req.status());
        return UserView.of(user);
    }
}
