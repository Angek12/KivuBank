package com.kivubank.user;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);

    Optional<User> findByPhone(String phone);

    boolean existsByEmail(String email);

    boolean existsByPhone(String phone);

    boolean existsByRole(Role role);

    long countByRole(Role role);

    @Query("select u from User u where u.id = (select a.userId from Account a where a.accountNumber = :accountNumber)")
    Optional<User> findByAccountNumber(@Param("accountNumber") String accountNumber);
}
