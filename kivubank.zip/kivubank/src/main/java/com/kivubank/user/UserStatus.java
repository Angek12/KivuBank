package com.kivubank.user;

public enum UserStatus { ACTIVE, DISABLED }
