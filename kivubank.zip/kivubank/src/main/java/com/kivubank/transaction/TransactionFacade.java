package com.kivubank.transaction;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kivubank.account.AccountRepository;
import com.kivubank.account.PinService;
import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import com.kivubank.common.Hashing;
import com.kivubank.transaction.IdempotencyService.StoredResponse;
import com.kivubank.transaction.TransactionDtos.DepositRequest;
import com.kivubank.transaction.TransactionDtos.TransactionOutcome;
import com.kivubank.transaction.TransactionDtos.TransactionView;
import com.kivubank.transaction.TransactionDtos.TransferRequest;
import com.kivubank.transaction.TransactionDtos.WithdrawalRequest;
import com.kivubank.transaction.TransactionProcessor.MoneyCommand;
import com.kivubank.transaction.TransactionProcessor.TransferCommand;
import java.util.Optional;
import java.util.function.Supplier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Entry point for financial writes: wraps the processor with the idempotency protocol.
 * It is deliberately NOT transactional; idempotency bookkeeping and money movement commit independently.
 */
@Service
public class TransactionFacade {
    private static final Logger log = LoggerFactory.getLogger(TransactionFacade.class);
    private final IdempotencyService idempotency;
    private final TransactionProcessor processor;
    private final AccountRepository accounts;
    private final PinService pins;
    private final ObjectMapper mapper;

    public TransactionFacade(IdempotencyService idempotency, TransactionProcessor processor, AccountRepository accounts,
                             PinService pins, ObjectMapper mapper) {
        this.idempotency = idempotency;
        this.processor = processor;
        this.accounts = accounts;
        this.pins = pins;
        this.mapper = mapper;
    }

    public record IdempotentResult(int httpStatus, TransactionView view, boolean replayed) {
    }

    public IdempotentResult deposit(Long userId, String key, DepositRequest req, Channel channel) {
        String hash = Hashing.sha256Hex("DEPOSIT|" + req.amount().stripTrailingZeros().toPlainString() + "|" + nz(req.description()));
        return run(userId, key, "DEPOSIT", hash,
                req.pin(), () -> processor.deposit(new MoneyCommand(userId, req.amount(), req.description(), channel, key)));
    }

    public IdempotentResult withdraw(Long userId, String key, WithdrawalRequest req, Channel channel) {
        String hash = Hashing.sha256Hex("WITHDRAWAL|" + req.amount().stripTrailingZeros().toPlainString() + "|" + nz(req.description()));
        return run(userId, key, "WITHDRAWAL", hash,
                req.pin(), () -> processor.withdraw(new MoneyCommand(userId, req.amount(), req.description(), channel, key)));
    }

    public IdempotentResult transfer(Long userId, String key, TransferRequest req, Channel channel) {
        String hash = Hashing.sha256Hex("TRANSFER|" + req.targetAccountNumber() + "|" + req.amount().stripTrailingZeros().toPlainString()
                + "|" + nz(req.description()));
        return run(userId, key, "TRANSFER", hash, req.pin(), () -> processor.transfer(new TransferCommand(userId,
                req.targetAccountNumber(), req.amount(), req.description(), channel, key)));
    }

    private IdempotentResult run(Long userId, String key, String operation, String hash, String pin,
                                 Supplier<TransactionOutcome> action) {
        Optional<StoredResponse> replay = idempotency.begin(userId, key, operation, hash);
        if (replay.isPresent()) {
            return new IdempotentResult(replay.get().httpStatus(), fromJson(replay.get().body()), true);
        }
        TransactionOutcome outcome;
        try {
            // PIN check happens before (and outside) the money transaction, so failed attempts are persisted
            // independently and no database connection is held while a second one is needed.
            Long accountId = accounts.findIdByUserId(userId)
                    .orElseThrow(() -> new BusinessException(ErrorCode.ACCOUNT_NOT_FOUND, "Account not found."));
            pins.verify(accountId, pin);
            outcome = action.get();
        } catch (RuntimeException e) {
            // Nothing was committed by the processor: free the key so the client can retry safely.
            idempotency.abandon(userId, key);
            throw e;
        }
        try {
            idempotency.complete(userId, key, outcome.httpStatus(), toJson(outcome.view()), outcome.view().reference());
        } catch (RuntimeException e) {
            // Money already moved. Leave the key IN_PROGRESS (retries get 409) rather than risk a duplicate.
            log.error("Could not store idempotent response for key={} reference={}", key, outcome.view().reference(), e);
        }
        return new IdempotentResult(outcome.httpStatus(), outcome.view(), false);
    }

    private String toJson(TransactionView view) {
        try {
            return mapper.writeValueAsString(view);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Cannot serialise transaction view", e);
        }
    }

    private TransactionView fromJson(String json) {
        try {
            return mapper.readValue(json, TransactionView.class);
        } catch (JsonProcessingException | RuntimeException e) {
            throw new BusinessException(ErrorCode.INTERNAL_ERROR, "Stored response could not be replayed.");
        }
    }

    private static String nz(String s) {
        return s == null ? "" : s.trim();
    }
}
