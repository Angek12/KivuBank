package com.kivubank.transaction;

import java.math.BigDecimal;
import java.time.Instant;

/** Optional filters for transaction history queries. */
public record TransactionFilter(TransactionStatus status, TransactionType type, Instant from, Instant to,
                                BigDecimal minAmount, BigDecimal maxAmount, String reference) {
    public static TransactionFilter none() {
        return new TransactionFilter(null, null, null, null, null, null, null);
    }
}
