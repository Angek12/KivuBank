package com.kivubank.transaction;

import java.time.Clock;
import java.util.Optional;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/** Every operation commits independently of the money-movement transaction. */
@Component
public class IdempotencyStore {
    private final IdempotencyRecordRepository repository;
    private final Clock clock;

    public IdempotencyStore(IdempotencyRecordRepository repository, Clock clock) {
        this.repository = repository;
        this.clock = clock;
    }

    /** Inserts an IN_PROGRESS record; a duplicate (user, key) raises DataIntegrityViolationException. */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void insert(Long userId, String key, String operation, String hash) {
        repository.saveAndFlush(new IdempotencyRecord(userId, key, operation, hash, clock.instant()));
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = true)
    public Optional<IdempotencyRecord> find(Long userId, String key) {
        return repository.findByUserIdAndIdempotencyKey(userId, key);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void complete(Long userId, String key, int httpStatus, String body, String reference) {
        repository.findByUserIdAndIdempotencyKey(userId, key)
                .ifPresent(r -> r.complete(httpStatus, body, reference, clock.instant()));
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void deleteInProgress(Long userId, String key) {
        repository.deleteInProgress(userId, key);
    }
}
