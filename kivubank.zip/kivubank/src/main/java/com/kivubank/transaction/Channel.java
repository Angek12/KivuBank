package com.kivubank.transaction;

/** The e-channel a transaction was initiated from. MOBILE and USSD are simulated channels. */
public enum Channel {
    WEB, MOBILE, USSD, ADMIN;

    public static Channel fromHeader(String value) {
        if (value != null && value.trim().equalsIgnoreCase("MOBILE")) {
            return MOBILE;
        }
        return WEB;
    }
}
