package com.kivubank.transaction;

import com.kivubank.account.Account;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;
import org.springframework.data.jpa.domain.Specification;

public final class TransactionSpecs {
    private TransactionSpecs() {
    }

    /** Transactions where the account is either the source or the target (left joins keep deposits/withdrawals). */
    public static Specification<Transaction> involving(Long accountId) {
        return (root, query, cb) -> {
            Join<Transaction, Account> source = root.join("sourceAccount", JoinType.LEFT);
            Join<Transaction, Account> target = root.join("targetAccount", JoinType.LEFT);
            return cb.or(cb.equal(source.get("id"), accountId), cb.equal(target.get("id"), accountId));
        };
    }

    public static Specification<Transaction> matching(TransactionFilter f) {
        return (root, query, cb) -> {
            List<Predicate> p = new ArrayList<>();
            if (f.status() != null) p.add(cb.equal(root.get("status"), f.status()));
            if (f.type() != null) p.add(cb.equal(root.get("type"), f.type()));
            if (f.from() != null) p.add(cb.greaterThanOrEqualTo(root.get("createdAt"), f.from()));
            if (f.to() != null) p.add(cb.lessThan(root.get("createdAt"), f.to()));
            if (f.minAmount() != null) p.add(cb.greaterThanOrEqualTo(root.get("amount"), f.minAmount()));
            if (f.maxAmount() != null) p.add(cb.lessThanOrEqualTo(root.get("amount"), f.maxAmount()));
            if (f.reference() != null && !f.reference().isBlank()) {
                p.add(cb.equal(root.get("reference"), f.reference().trim()));
            }
            return cb.and(p.toArray(new Predicate[0]));
        };
    }
}
