package com.kivubank.transaction;

import com.kivubank.account.AccountRepository;
import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import com.kivubank.common.PageResponse;
import com.kivubank.transaction.TransactionDtos.TransactionView;
import java.util.List;
import java.util.Set;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true)
public class TransactionQueryService {
    private static final Set<String> SORTABLE = Set.of("createdAt", "amount", "status", "type");
    private final TransactionRepository transactions;
    private final AccountRepository accounts;

    public TransactionQueryService(TransactionRepository transactions, AccountRepository accounts) {
        this.transactions = transactions;
        this.accounts = accounts;
    }

    public PageResponse<TransactionView> listForUser(Long userId, TransactionFilter filter, Pageable pageable) {
        Long accountId = accountIdOf(userId);
        Specification<Transaction> spec = TransactionSpecs.involving(accountId).and(TransactionSpecs.matching(filter));
        return PageResponse.of(transactions.findAll(spec, safe(pageable)), t -> TransactionMapper.toView(t, accountId));
    }

    public TransactionView getForUser(Long userId, String reference) {
        Long accountId = accountIdOf(userId);
        Transaction t = transactions.findByReference(reference).orElseThrow(this::notFound);
        boolean involved = (t.getSourceAccount() != null && accountId.equals(t.getSourceAccount().getId()))
                || (t.getTargetAccount() != null && accountId.equals(t.getTargetAccount().getId()));
        if (!involved) {
            throw notFound(); // 404 rather than 403: do not reveal that the reference exists
        }
        return TransactionMapper.toView(t, accountId);
    }

    public List<TransactionView> recentForUser(Long userId, int limit) {
        Long accountId = accountIdOf(userId);
        Pageable p = PageRequest.of(0, Math.min(Math.max(limit, 1), 50), Sort.by(Sort.Direction.DESC, "createdAt"));
        return transactions.findAll(TransactionSpecs.involving(accountId), p).getContent().stream()
                .map(t -> TransactionMapper.toView(t, accountId)).toList();
    }

    public PageResponse<TransactionView> listAll(TransactionFilter filter, Pageable pageable) {
        return PageResponse.of(transactions.findAll(TransactionSpecs.matching(filter), safe(pageable)),
                t -> TransactionMapper.toView(t, null));
    }

    public TransactionView getAny(String reference) {
        return TransactionMapper.toView(transactions.findByReference(reference).orElseThrow(this::notFound), null);
    }

    private Long accountIdOf(Long userId) {
        return accounts.findIdByUserId(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.ACCOUNT_NOT_FOUND, "Account not found."));
    }

    private BusinessException notFound() {
        return new BusinessException(ErrorCode.TRANSACTION_NOT_FOUND, "Transaction not found.");
    }

    /** Clamps page size and whitelists sort properties so clients cannot sort on arbitrary columns. */
    private Pageable safe(Pageable pageable) {
        Sort sort = Sort.by(pageable.getSort().stream().filter(o -> SORTABLE.contains(o.getProperty())).toList());
        if (sort.isUnsorted()) {
            sort = Sort.by(Sort.Direction.DESC, "createdAt");
        }
        return PageRequest.of(Math.max(pageable.getPageNumber(), 0), Math.min(Math.max(pageable.getPageSize(), 1), 100), sort);
    }
}
