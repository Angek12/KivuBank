package com.kivubank.transaction;

import com.kivubank.transaction.TransactionDtos.TransactionView;
import java.math.BigDecimal;

public final class TransactionMapper {
    private TransactionMapper() {
    }

    /**
     * Maps an entity to its API view. Must be called inside a transaction (accounts are lazy).
     * @param viewerAccountId the account whose perspective to use (direction, balance); null for staff views.
     */
    public static TransactionView toView(Transaction t, Long viewerAccountId) {
        String direction = null;
        BigDecimal balanceAfter = null;
        if (viewerAccountId != null) {
            if (t.getSourceAccount() != null && viewerAccountId.equals(t.getSourceAccount().getId())) {
                direction = "DEBIT";
                balanceAfter = t.getSourceBalanceAfter();
            } else if (t.getTargetAccount() != null && viewerAccountId.equals(t.getTargetAccount().getId())) {
                direction = "CREDIT";
                balanceAfter = t.getTargetBalanceAfter();
            }
        }
        return new TransactionView(t.getReference(), t.getType(), t.getStatus(), direction, t.getAmount(),
                t.getCurrency(),
                t.getSourceAccount() == null ? null : t.getSourceAccount().getAccountNumber(),
                t.getTargetAccount() == null ? null : t.getTargetAccount().getAccountNumber(),
                t.getDescription(), t.getFailureReason(), t.getChannel(), balanceAfter, t.getCreatedAt(),
                t.getCompletedAt());
    }
}
