package com.kivubank.transaction;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface IdempotencyRecordRepository extends JpaRepository<IdempotencyRecord, Long> {
    Optional<IdempotencyRecord> findByUserIdAndIdempotencyKey(Long userId, String idempotencyKey);

    @Modifying
    @Query("delete from IdempotencyRecord r where r.userId = :userId and r.idempotencyKey = :key "
            + "and r.state = com.kivubank.transaction.IdempotencyState.IN_PROGRESS")
    int deleteInProgress(@Param("userId") Long userId, @Param("key") String key);
}
