package com.kivubank.transaction;

public enum TransactionType { DEPOSIT, WITHDRAWAL, TRANSFER, REVERSAL }
