package com.kivubank.transaction;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;

/**
 * Transaction state machine.
 * <pre>
 * PENDING --> PROCESSING --> SUCCESS --> REVERSED
 *    |              \--> FAILED
 *    \--> CANCELLED
 * </pre>
 * FAILED, REVERSED and CANCELLED are terminal.
 */
public enum TransactionStatus {
    PENDING, PROCESSING, SUCCESS, FAILED, REVERSED, CANCELLED;

    private static final Map<TransactionStatus, Set<TransactionStatus>> ALLOWED = new EnumMap<>(TransactionStatus.class);

    static {
        ALLOWED.put(PENDING, EnumSet.of(PROCESSING, CANCELLED));
        ALLOWED.put(PROCESSING, EnumSet.of(SUCCESS, FAILED));
        ALLOWED.put(SUCCESS, EnumSet.of(REVERSED));
        ALLOWED.put(FAILED, EnumSet.noneOf(TransactionStatus.class));
        ALLOWED.put(REVERSED, EnumSet.noneOf(TransactionStatus.class));
        ALLOWED.put(CANCELLED, EnumSet.noneOf(TransactionStatus.class));
    }

    public boolean canTransitionTo(TransactionStatus next) {
        return ALLOWED.get(this).contains(next);
    }

    public boolean isTerminal() {
        return ALLOWED.get(this).isEmpty();
    }
}
