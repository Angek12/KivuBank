package com.kivubank.transaction;

import java.security.SecureRandom;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import org.springframework.stereotype.Component;

/** Generates unique, traceable references such as KB20261003-7XQ4M2PD9T (date + 10 random unambiguous characters). */
@Component
public class ReferenceGenerator {
    private static final char[] ALPHABET = "ABCDEFGHJKMNPQRSTVWXYZ23456789".toCharArray();
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyyMMdd").withZone(ZoneOffset.UTC);
    private final SecureRandom random = new SecureRandom();

    public String next(Instant now) {
        StringBuilder sb = new StringBuilder("KB").append(DATE.format(now)).append('-');
        for (int i = 0; i < 10; i++) {
            sb.append(ALPHABET[random.nextInt(ALPHABET.length)]);
        }
        return sb.toString();
    }
}
