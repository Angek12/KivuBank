package com.kivubank.transaction;

public enum IdempotencyState { IN_PROGRESS, COMPLETED }
