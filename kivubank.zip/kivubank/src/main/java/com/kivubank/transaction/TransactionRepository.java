package com.kivubank.transaction;

import jakarta.persistence.LockModeType;
import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface TransactionRepository extends JpaRepository<Transaction, Long>, JpaSpecificationExecutor<Transaction> {
    Optional<Transaction> findByReference(String reference);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select t from Transaction t where t.reference = :reference")
    Optional<Transaction> findByReferenceForUpdate(@Param("reference") String reference);

    @Query("select t.status, count(t) from Transaction t group by t.status")
    List<Object[]> countGroupedByStatus();

    @Query("select t.status, count(t) from Transaction t where t.createdAt >= :since group by t.status")
    List<Object[]> countGroupedByStatusSince(@Param("since") Instant since);

    @Query("select avg(t.amount) from Transaction t where t.sourceAccount.id = :accountId "
            + "and t.status = com.kivubank.transaction.TransactionStatus.SUCCESS "
            + "and t.createdAt >= :since and t.createdAt < :before and t.id <> :excludeId")
    Double averageOutgoingAmount(@Param("accountId") Long accountId, @Param("since") Instant since,
                                 @Param("before") Instant before, @Param("excludeId") Long excludeId);

    @Query("select count(t) from Transaction t where t.sourceAccount.id = :accountId "
            + "and t.status = com.kivubank.transaction.TransactionStatus.SUCCESS "
            + "and t.createdAt >= :from and t.createdAt < :to and t.id <> :excludeId")
    long countOutgoing(@Param("accountId") Long accountId, @Param("from") Instant from, @Param("to") Instant to,
                       @Param("excludeId") Long excludeId);

    @Query("select count(t) from Transaction t where t.sourceAccount.id = :sourceId and t.targetAccount.id = :targetId "
            + "and t.status = com.kivubank.transaction.TransactionStatus.SUCCESS and t.id <> :excludeId")
    long countPriorTransfers(@Param("sourceId") Long sourceId, @Param("targetId") Long targetId,
                             @Param("excludeId") Long excludeId);

    @Query("select t from Transaction t where t.createdAt >= :from and t.createdAt < :to "
            + "and t.type <> com.kivubank.transaction.TransactionType.REVERSAL and t.status in :statuses order by t.createdAt")
    List<Transaction> findForReconciliation(@Param("from") Instant from, @Param("to") Instant to,
                                            @Param("statuses") Collection<TransactionStatus> statuses);

    @Query("select t.createdAt, t.status from Transaction t where t.createdAt >= :since order by t.createdAt")
    List<Object[]> findTrendRows(@Param("since") Instant since);

    List<Transaction> findAllByOrderByCreatedAtDesc(Pageable pageable);
}
