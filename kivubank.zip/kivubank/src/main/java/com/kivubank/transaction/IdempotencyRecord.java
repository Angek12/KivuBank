package com.kivubank.transaction;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.time.Instant;

/** Persistent idempotency record. UNIQUE(user_id, idempotency_key) is what makes concurrent duplicates safe. */
@Entity
@Table(name = "idempotency_records", uniqueConstraints =
        @UniqueConstraint(name = "uq_idempotency_user_key", columnNames = {"user_id", "idempotency_key"}))
public class IdempotencyRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private Long userId;
    @Column(nullable = false, length = 80)
    private String idempotencyKey;
    @Column(nullable = false, length = 40)
    private String operation;
    @Column(nullable = false, length = 64)
    private String requestHash;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private IdempotencyState state;
    private Integer httpStatus;
    @Column(length = 4000)
    private String responseBody;
    @Column(length = 40)
    private String transactionReference;
    @Column(nullable = false)
    private Instant createdAt;
    private Instant completedAt;

    protected IdempotencyRecord() {
    }

    public IdempotencyRecord(Long userId, String idempotencyKey, String operation, String requestHash, Instant now) {
        this.userId = userId;
        this.idempotencyKey = idempotencyKey;
        this.operation = operation;
        this.requestHash = requestHash;
        this.state = IdempotencyState.IN_PROGRESS;
        this.createdAt = now;
    }

    public void complete(int httpStatus, String responseBody, String transactionReference, Instant now) {
        this.state = IdempotencyState.COMPLETED;
        this.httpStatus = httpStatus;
        this.responseBody = responseBody;
        this.transactionReference = transactionReference;
        this.completedAt = now;
    }

    public Long getId() { return id; }
    public Long getUserId() { return userId; }
    public String getIdempotencyKey() { return idempotencyKey; }
    public String getOperation() { return operation; }
    public String getRequestHash() { return requestHash; }
    public IdempotencyState getState() { return state; }
    public Integer getHttpStatus() { return httpStatus; }
    public String getResponseBody() { return responseBody; }
    public String getTransactionReference() { return transactionReference; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getCompletedAt() { return completedAt; }
}
