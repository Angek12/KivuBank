package com.kivubank.transaction;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.Instant;

public final class TransactionDtos {
    private TransactionDtos() {
    }

    public record DepositRequest(
            @Schema(example = "25000.00") @NotNull @DecimalMin("0.01") @Digits(integer = 15, fraction = 2) BigDecimal amount,
            @Schema(example = "4829") @NotBlank @Pattern(regexp = "^\\d{4,6}$") String pin,
            @Schema(example = "Cash deposit (simulated)") @Size(max = 200) String description) {
    }

    public record WithdrawalRequest(
            @Schema(example = "5000.00") @NotNull @DecimalMin("0.01") @Digits(integer = 15, fraction = 2) BigDecimal amount,
            @NotBlank @Pattern(regexp = "^\\d{4,6}$") String pin,
            @Size(max = 200) String description) {
    }

    public record TransferRequest(
            @Schema(example = "1043820917") @NotBlank @Pattern(regexp = "^\\d{6,20}$") String targetAccountNumber,
            @Schema(example = "1500.00") @NotNull @DecimalMin("0.01") @Digits(integer = 15, fraction = 2) BigDecimal amount,
            @NotBlank @Pattern(regexp = "^\\d{4,6}$") String pin,
            @Schema(example = "Rent share") @Size(max = 200) String description) {
    }

    public record ReverseRequest(@NotBlank @Size(max = 200) String reason) {
    }

    public record TransactionView(String reference, TransactionType type, TransactionStatus status, String direction,
                                  BigDecimal amount, String currency, String sourceAccountNumber,
                                  String targetAccountNumber, String description, String failureReason,
                                  Channel channel, BigDecimal balanceAfter, Instant createdAt, Instant completedAt) {
    }

    /** A view plus the HTTP status that should be returned to the client (201 success, 202 pending review, 422 failed). */
    public record TransactionOutcome(TransactionView view, int httpStatus) {
    }
}
