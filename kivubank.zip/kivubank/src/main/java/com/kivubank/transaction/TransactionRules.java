package com.kivubank.transaction;

import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import java.math.BigDecimal;

/** Pure validation rules for monetary amounts. */
public final class TransactionRules {
    private static final BigDecimal MIN = new BigDecimal("0.01");

    private TransactionRules() {
    }

    /** Validates and normalises an amount to two decimal places. */
    public static BigDecimal validateAmount(BigDecimal amount, BigDecimal max) {
        if (amount == null) {
            throw new BusinessException(ErrorCode.INVALID_AMOUNT, "Amount is required.");
        }
        if (amount.signum() <= 0 || amount.compareTo(MIN) < 0) {
            throw new BusinessException(ErrorCode.INVALID_AMOUNT, "Amount must be at least 0.01.");
        }
        if (amount.stripTrailingZeros().scale() > 2) {
            throw new BusinessException(ErrorCode.INVALID_AMOUNT, "Amount may have at most 2 decimal places.");
        }
        if (max != null && amount.compareTo(max) > 0) {
            throw new BusinessException(ErrorCode.INVALID_AMOUNT, "Amount exceeds the maximum allowed per transaction.");
        }
        return amount.setScale(2, java.math.RoundingMode.UNNECESSARY);
    }
}
