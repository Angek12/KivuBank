package com.kivubank.transaction;

import com.kivubank.auth.AuthenticatedUser;
import com.kivubank.common.PageResponse;
import com.kivubank.transaction.TransactionDtos.ReverseRequest;
import com.kivubank.transaction.TransactionDtos.TransactionView;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import java.math.BigDecimal;
import java.time.Instant;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/admin/transactions")
@Validated
@Tag(name = "Admin - Transactions", description = "Staff transaction oversight, approval of pending transfers and reversals.")
@SecurityRequirement(name = "bearerAuth")
public class AdminTransactionController {
    private final TransactionQueryService queries;
    private final TransactionProcessor processor;

    public AdminTransactionController(TransactionQueryService queries, TransactionProcessor processor) {
        this.queries = queries;
        this.processor = processor;
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','SUPPORT_AGENT','AUDITOR')")
    @Operation(summary = "Search all transactions (staff)")
    public PageResponse<TransactionView> search(
            @RequestParam(required = false) TransactionStatus status,
            @RequestParam(required = false) TransactionType type,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to,
            @RequestParam(required = false) BigDecimal minAmount,
            @RequestParam(required = false) BigDecimal maxAmount,
            @RequestParam(required = false) String reference,
            @PageableDefault(size = 20) Pageable pageable) {
        return queries.listAll(new TransactionFilter(status, type, from, to, minAmount, maxAmount, reference), pageable);
    }

    @GetMapping("/{reference}")
    @PreAuthorize("hasAnyRole('ADMIN','SUPPORT_AGENT','AUDITOR')")
    @Operation(summary = "Get any transaction by reference (staff)")
    public TransactionView get(@PathVariable @Pattern(regexp = "^[A-Z0-9-]{8,40}$") String reference) {
        return queries.getAny(reference);
    }

    @PostMapping("/{reference}/approve")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Approve a PENDING transfer (ADMIN)",
            description = "Moves PENDING -> PROCESSING -> SUCCESS (or FAILED if funds are insufficient).")
    public TransactionView approve(@PathVariable @Pattern(regexp = "^[A-Z0-9-]{8,40}$") String reference) {
        return processor.approve(reference, AuthenticatedUser.current().id()).view();
    }

    @PostMapping("/{reference}/reverse")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Reverse a SUCCESS transaction (ADMIN)",
            description = "Moves funds back, marks the original REVERSED and records a linked REVERSAL transaction. Fails with 422 if the counterparty lacks funds.")
    public TransactionView reverse(@PathVariable @Pattern(regexp = "^[A-Z0-9-]{8,40}$") String reference,
                                   @Valid @RequestBody ReverseRequest request) {
        return processor.reverse(reference, AuthenticatedUser.current().id(), request.reason()).view();
    }
}
