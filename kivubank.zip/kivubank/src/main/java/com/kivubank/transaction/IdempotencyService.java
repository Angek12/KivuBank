package com.kivubank.transaction;

import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import java.util.Optional;
import java.util.regex.Pattern;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

/**
 * Idempotency protocol for financial operations (Idempotency-Key header):
 * <ol>
 *   <li>begin: insert IN_PROGRESS (unique per user+key). Winner proceeds; losers replay a stored response,
 *       get 409 while the original is in flight, or 422 if the same key is reused with a different request.</li>
 *   <li>complete: store the response so retries return the identical result.</li>
 *   <li>abandon: if processing threw before any money moved, free the key so the client may retry.</li>
 * </ol>
 */
@Service
public class IdempotencyService {
    private static final Pattern KEY = Pattern.compile("^[A-Za-z0-9._:-]{8,80}$");
    private final IdempotencyStore store;

    public IdempotencyService(IdempotencyStore store) {
        this.store = store;
    }

    public record StoredResponse(int httpStatus, String body) {
    }

    /** @return empty when the caller must perform the operation; a stored response when it is a replay. */
    public Optional<StoredResponse> begin(Long userId, String key, String operation, String requestHash) {
        if (key == null || !KEY.matcher(key).matches()) {
            throw new BusinessException(ErrorCode.VALIDATION_FAILED,
                    "Idempotency-Key must be 8-80 characters (letters, digits, . _ : -). A UUID is recommended.");
        }
        try {
            store.insert(userId, key, operation, requestHash);
            return Optional.empty();
        } catch (DataIntegrityViolationException duplicate) {
            IdempotencyRecord existing = store.find(userId, key).orElseThrow(() ->
                    new BusinessException(ErrorCode.CONFLICT, "Please retry the request."));
            if (!existing.getRequestHash().equals(requestHash)) {
                throw new BusinessException(ErrorCode.IDEMPOTENCY_KEY_REUSED,
                        "This Idempotency-Key was already used with a different request.");
            }
            if (existing.getState() == IdempotencyState.COMPLETED && existing.getHttpStatus() != null) {
                return Optional.of(new StoredResponse(existing.getHttpStatus(), existing.getResponseBody()));
            }
            throw new BusinessException(ErrorCode.IDEMPOTENCY_IN_PROGRESS,
                    "A request with this Idempotency-Key is still being processed. Retry shortly.");
        }
    }

    public void complete(Long userId, String key, int httpStatus, String body, String reference) {
        store.complete(userId, key, httpStatus, body, reference);
    }

    public void abandon(Long userId, String key) {
        store.deleteInProgress(userId, key);
    }
}
