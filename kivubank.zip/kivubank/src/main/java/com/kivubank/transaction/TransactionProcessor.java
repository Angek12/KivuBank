package com.kivubank.transaction;

import com.kivubank.account.Account;
import com.kivubank.account.AccountRepository;
import com.kivubank.audit.AuditAction;
import com.kivubank.audit.AuditOutcome;
import com.kivubank.audit.AuditService;
import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import com.kivubank.config.KivuBankProperties;
import com.kivubank.event.DomainEvents.TransactionOutcomeEvent;
import com.kivubank.transaction.TransactionDtos.TransactionOutcome;
import com.kivubank.user.Role;
import io.micrometer.core.instrument.MeterRegistry;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * Executes money movements. Every public method runs ONE database transaction (via TransactionTemplate) and publishes
 * its domain event only AFTER the commit, once the database connection has been released:
 * the involved account rows are locked in id order (SELECT ... FOR UPDATE), balances and the
 * transaction record change together, and a CHECK(balance >= 0) constraint backs this up in the database.
 * Business failures such as insufficient funds are persisted as FAILED transactions rather than thrown.
 */
@Service
public class TransactionProcessor {
    private final AccountRepository accounts;
    private final TransactionRepository transactions;
    private final ApplicationEventPublisher events;
    private final KivuBankProperties props;
    private final Clock clock;
    private final ReferenceGenerator references;
    private final AuditService audit;
    private final MeterRegistry meters;
    private final TransactionTemplate txTemplate;

    public TransactionProcessor(AccountRepository accounts, TransactionRepository transactions,
                                ApplicationEventPublisher events, KivuBankProperties props, Clock clock,
                                ReferenceGenerator references, AuditService audit, MeterRegistry meters,
                                PlatformTransactionManager transactionManager) {
        this.accounts = accounts;
        this.transactions = transactions;
        this.events = events;
        this.props = props;
        this.clock = clock;
        this.references = references;
        this.audit = audit;
        this.meters = meters;
        this.txTemplate = new TransactionTemplate(transactionManager);
    }

    /** Commands carry no PIN: it is verified by {@link TransactionFacade} before the transaction starts. */
    public record MoneyCommand(Long userId, BigDecimal amount, String description, Channel channel, String idempotencyKey) {
    }

    public record TransferCommand(Long userId, String targetAccountNumber, BigDecimal amount, String description,
                                  Channel channel, String idempotencyKey) {
    }

    public TransactionOutcome deposit(MoneyCommand c) {
        return execute(() -> doDeposit(c));
    }

    private Done doDeposit(MoneyCommand c) {
        BigDecimal amount = TransactionRules.validateAmount(c.amount(), props.transactions().maxAmount());
        Long accountId = accountIdOf(c.userId());
        Account account = lock(List.of(accountId)).get(accountId);
        requireActive(account);
        Instant now = clock.instant();
        Transaction t = open(TransactionType.DEPOSIT, amount, null, account, c.description(), c.channel(), c.userId(), c.idempotencyKey(), now);
        t.transitionTo(TransactionStatus.PROCESSING, now);
        account.credit(amount, now);
        t.setTargetBalanceAfter(account.getBalance());
        t.transitionTo(TransactionStatus.SUCCESS, now);
        return finish(t, accountId, 201, true);
    }

    public TransactionOutcome withdraw(MoneyCommand c) {
        return execute(() -> doWithdraw(c));
    }

    private Done doWithdraw(MoneyCommand c) {
        BigDecimal amount = TransactionRules.validateAmount(c.amount(), props.transactions().maxAmount());
        Long accountId = accountIdOf(c.userId());
        Account account = lock(List.of(accountId)).get(accountId);
        requireActive(account);
        Instant now = clock.instant();
        Transaction t = open(TransactionType.WITHDRAWAL, amount, account, null, c.description(), c.channel(), c.userId(), c.idempotencyKey(), now);
        t.transitionTo(TransactionStatus.PROCESSING, now);
        if (account.getBalance().compareTo(amount) < 0) {
            t.fail("INSUFFICIENT_FUNDS", now);
            return finish(t, accountId, 422, true);
        }
        account.debit(amount, now);
        t.setSourceBalanceAfter(account.getBalance());
        t.transitionTo(TransactionStatus.SUCCESS, now);
        return finish(t, accountId, 201, true);
    }

    public TransactionOutcome transfer(TransferCommand c) {
        return execute(() -> doTransfer(c));
    }

    private Done doTransfer(TransferCommand c) {
        BigDecimal amount = TransactionRules.validateAmount(c.amount(), props.transactions().maxAmount());
        Long sourceId = accountIdOf(c.userId());
        Long targetId = accounts.findIdByAccountNumber(c.targetAccountNumber())
                .orElseThrow(() -> new BusinessException(ErrorCode.ACCOUNT_NOT_FOUND, "Destination account not found."));
        if (sourceId.equals(targetId)) {
            throw new BusinessException(ErrorCode.SAME_ACCOUNT, "Source and destination accounts must differ.");
        }
        Map<Long, Account> locked = lock(List.of(sourceId, targetId));
        Account source = locked.get(sourceId);
        Account target = locked.get(targetId);
        requireActive(source);
        if (!target.isActive()) {
            throw new BusinessException(ErrorCode.ACCOUNT_FROZEN, "The destination account cannot receive funds.");
        }
        if (!source.getCurrency().equals(target.getCurrency())) {
            throw new BusinessException(ErrorCode.VALIDATION_FAILED, "Cross-currency transfers are not supported.");
        }
        Instant now = clock.instant();
        Transaction t = open(TransactionType.TRANSFER, amount, source, target, c.description(), c.channel(), c.userId(), c.idempotencyKey(), now);
        if (amount.compareTo(props.transactions().reviewThreshold()) >= 0) {
            // Maker-checker: large transfers wait in PENDING until an ADMIN approves or the customer cancels.
            return finish(t, sourceId, 202, true);
        }
        return settleTransfer(t, source, target, now, sourceId, true);
    }

    /** ADMIN approval of a PENDING (manual review) transfer. */
    public TransactionOutcome approve(String reference, Long adminUserId) {
        return execute(() -> doApprove(reference, adminUserId));
    }

    private Done doApprove(String reference, Long adminUserId) {
        Transaction t = transactions.findByReferenceForUpdate(reference)
                .orElseThrow(() -> new BusinessException(ErrorCode.TRANSACTION_NOT_FOUND, "Transaction not found."));
        if (t.getStatus() != TransactionStatus.PENDING) {
            throw new BusinessException(ErrorCode.INVALID_STATE_TRANSITION, "Only PENDING transactions can be approved.");
        }
        Long sourceId = t.getSourceAccount().getId();
        Long targetId = t.getTargetAccount().getId();
        Map<Long, Account> locked = lock(List.of(sourceId, targetId));
        Account source = locked.get(sourceId);
        Account target = locked.get(targetId);
        audit.recordForUser(adminUserId, AuditAction.TRANSACTION_APPROVED, AuditOutcome.SUCCESS, "TRANSACTION", reference, null);
        if (!source.isActive() || !target.isActive()) {
            Instant now = clock.instant();
            t.transitionTo(TransactionStatus.PROCESSING, now);
            t.fail("ACCOUNT_NOT_ACTIVE", now);
            return finish(t, null, 422);
        }
        return settleTransfer(t, source, target, clock.instant(), null, false);
    }

    /** Cancels a PENDING transaction. Allowed for the owner of the source account or any ADMIN. */
    public TransactionOutcome cancel(String reference, Long userId, Role role) {
        return execute(() -> doCancel(reference, userId, role));
    }

    private Done doCancel(String reference, Long userId, Role role) {
        Transaction t = transactions.findByReferenceForUpdate(reference)
                .orElseThrow(() -> new BusinessException(ErrorCode.TRANSACTION_NOT_FOUND, "Transaction not found."));
        boolean owner = t.getSourceAccount() != null && userId.equals(t.getSourceAccount().getUserId());
        if (!owner && role != Role.ADMIN) {
            throw new BusinessException(ErrorCode.TRANSACTION_NOT_FOUND, "Transaction not found.");
        }
        t.transitionTo(TransactionStatus.CANCELLED, clock.instant());
        audit.recordForUser(userId, AuditAction.TRANSACTION_CANCELLED, AuditOutcome.SUCCESS, "TRANSACTION", reference, null);
        return finish(t, owner && t.getSourceAccount() != null ? t.getSourceAccount().getId() : null, 200);
    }

    /** ADMIN reversal of a SUCCESS transaction: money moves back, original becomes REVERSED, a REVERSAL record links both. */
    public TransactionOutcome reverse(String reference, Long adminUserId, String reason) {
        return execute(() -> doReverse(reference, adminUserId, reason));
    }

    private Done doReverse(String reference, Long adminUserId, String reason) {
        Transaction original = transactions.findByReferenceForUpdate(reference)
                .orElseThrow(() -> new BusinessException(ErrorCode.TRANSACTION_NOT_FOUND, "Transaction not found."));
        if (original.getStatus() != TransactionStatus.SUCCESS || original.getType() == TransactionType.REVERSAL) {
            throw new BusinessException(ErrorCode.INVALID_STATE_TRANSITION, "Only SUCCESS transactions can be reversed.");
        }
        Set<Long> ids = new HashSet<>();
        if (original.getSourceAccount() != null) ids.add(original.getSourceAccount().getId());
        if (original.getTargetAccount() != null) ids.add(original.getTargetAccount().getId());
        Map<Long, Account> locked = lock(ids);
        Account source = original.getSourceAccount() == null ? null : locked.get(original.getSourceAccount().getId());
        Account target = original.getTargetAccount() == null ? null : locked.get(original.getTargetAccount().getId());
        Instant now = clock.instant();
        BigDecimal amount = original.getAmount();
        Transaction reversal;
        switch (original.getType()) {
            case TRANSFER -> {
                target.debit(amount, now);
                source.credit(amount, now);
                reversal = open(TransactionType.REVERSAL, amount, target, source, reason, Channel.ADMIN, adminUserId, null, now);
                reversal.setSourceBalanceAfter(target.getBalance());
                reversal.setTargetBalanceAfter(source.getBalance());
            }
            case DEPOSIT -> {
                target.debit(amount, now);
                reversal = open(TransactionType.REVERSAL, amount, target, null, reason, Channel.ADMIN, adminUserId, null, now);
                reversal.setSourceBalanceAfter(target.getBalance());
            }
            case WITHDRAWAL -> {
                source.credit(amount, now);
                reversal = open(TransactionType.REVERSAL, amount, null, source, reason, Channel.ADMIN, adminUserId, null, now);
                reversal.setTargetBalanceAfter(source.getBalance());
            }
            default -> throw new BusinessException(ErrorCode.INVALID_STATE_TRANSITION, "This transaction cannot be reversed.");
        }
        reversal.setReversalOf(original);
        reversal.transitionTo(TransactionStatus.PROCESSING, now);
        reversal.transitionTo(TransactionStatus.SUCCESS, now);
        original.transitionTo(TransactionStatus.REVERSED, now);
        audit.recordForUser(adminUserId, AuditAction.TRANSACTION_REVERSED, AuditOutcome.SUCCESS, "TRANSACTION", reference,
                "reversal=" + reversal.getReference() + " reason=" + reason);
        return finish(original, null, 200);
    }

    private record Done(TransactionOutcome outcome, TransactionOutcomeEvent event) {
    }

    /** Runs the work in one transaction, then publishes the event once the commit succeeded. */
    private TransactionOutcome execute(Supplier<Done> work) {
        Done done = txTemplate.execute(status -> work.get());
        if (done == null) {
            throw new BusinessException(ErrorCode.INTERNAL_ERROR, "Transaction produced no result.");
        }
        events.publishEvent(done.event());
        return done.outcome();
    }

    // ---- internals -------------------------------------------------------------------------------------------

    private Done settleTransfer(Transaction t, Account source, Account target, Instant now, Long viewerAccountId, boolean created) {
        t.transitionTo(TransactionStatus.PROCESSING, now);
        if (source.getBalance().compareTo(t.getAmount()) < 0) {
            t.fail("INSUFFICIENT_FUNDS", now);
            return finish(t, viewerAccountId, 422, created);
        }
        source.debit(t.getAmount(), now);
        target.credit(t.getAmount(), now);
        t.setSourceBalanceAfter(source.getBalance());
        t.setTargetBalanceAfter(target.getBalance());
        t.transitionTo(TransactionStatus.SUCCESS, now);
        return finish(t, viewerAccountId, 201, created);
    }

    private Transaction open(TransactionType type, BigDecimal amount, Account source, Account target, String description,
                             Channel channel, Long userId, String idempotencyKey, Instant now) {
        String currency = source != null ? source.getCurrency() : target.getCurrency();
        String desc = description == null || description.isBlank() ? null : description.trim();
        return transactions.save(new Transaction(references.next(now), type, amount, currency, source, target, desc,
                channel, userId, idempotencyKey, now));
    }

    private Done finish(Transaction t, Long viewerAccountId, int httpStatus) {
        return finish(t, viewerAccountId, httpStatus, false);
    }

    private Done finish(Transaction t, Long viewerAccountId, int httpStatus, boolean created) {
        meters.counter("kivubank.transactions", "type", t.getType().name(), "status", t.getStatus().name()).increment();
        TransactionOutcomeEvent event = new TransactionOutcomeEvent(t.getId(), t.getReference(), t.getType(), t.getStatus(),
                t.getAmount(), t.getCurrency(),
                t.getSourceAccount() == null ? null : t.getSourceAccount().getId(),
                t.getTargetAccount() == null ? null : t.getTargetAccount().getId(),
                t.getSourceAccount() == null ? null : t.getSourceAccount().getUserId(),
                t.getTargetAccount() == null ? null : t.getTargetAccount().getUserId(),
                t.getInitiatedByUserId(), t.getChannel(), t.getFailureReason(), clock.instant(), created);
        return new Done(new TransactionOutcome(TransactionMapper.toView(t, viewerAccountId), httpStatus), event);
    }

    private Long accountIdOf(Long userId) {
        return accounts.findIdByUserId(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.ACCOUNT_NOT_FOUND, "Account not found."));
    }

    private Map<Long, Account> lock(Collection<Long> ids) {
        List<Account> locked = accounts.lockAllByIdIn(ids);
        if (locked.size() != new HashSet<>(ids).size()) {
            throw new BusinessException(ErrorCode.ACCOUNT_NOT_FOUND, "Account not found.");
        }
        return locked.stream().collect(Collectors.toMap(Account::getId, a -> a));
    }

    private void requireActive(Account account) {
        if (!account.isActive()) {
            throw new BusinessException(ErrorCode.ACCOUNT_FROZEN, "This account is not active.");
        }
    }
}
