package com.kivubank.transaction;

import com.kivubank.auth.AuthenticatedUser;
import com.kivubank.common.PageResponse;
import com.kivubank.transaction.TransactionDtos.DepositRequest;
import com.kivubank.transaction.TransactionDtos.TransactionOutcome;
import com.kivubank.transaction.TransactionDtos.TransactionView;
import com.kivubank.transaction.TransactionDtos.TransferRequest;
import com.kivubank.transaction.TransactionDtos.WithdrawalRequest;
import com.kivubank.transaction.TransactionFacade.IdempotentResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import java.math.BigDecimal;
import java.time.Instant;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/transactions")
@Validated
@Tag(name = "Transactions", description = "Deposits, withdrawals, transfers and history (CUSTOMER role). "
        + "All money-moving POSTs require an Idempotency-Key header; PINs are verified server-side.")
@SecurityRequirement(name = "bearerAuth")
@PreAuthorize("hasRole('CUSTOMER')")
public class TransactionController {
    private static final String KEY_DESC = "Unique client-generated key (UUID recommended). Replaying the same key and body returns the original result without moving money again.";
    private final TransactionFacade facade;
    private final TransactionQueryService queries;
    private final TransactionProcessor processor;

    public TransactionController(TransactionFacade facade, TransactionQueryService queries, TransactionProcessor processor) {
        this.facade = facade;
        this.queries = queries;
        this.processor = processor;
    }

    @PostMapping("/deposit")
    @Operation(summary = "Deposit funds (simulated cash deposit)",
            description = "Credits the caller's account. Returns 201 with the transaction, or the stored response on replay (header Idempotent-Replayed: true).",
            responses = {@ApiResponse(responseCode = "201", description = "Deposit successful"),
                    @ApiResponse(responseCode = "403", description = "Wrong or locked PIN, or frozen account"),
                    @ApiResponse(responseCode = "409", description = "Request with this key still in progress"),
                    @ApiResponse(responseCode = "422", description = "Key reused with a different request")})
    public ResponseEntity<TransactionView> deposit(
            @Parameter(description = KEY_DESC) @RequestHeader("Idempotency-Key") String key,
            @RequestHeader(value = "X-Client-Channel", required = false) String channel,
            @Valid @RequestBody DepositRequest request) {
        return respond(facade.deposit(AuthenticatedUser.current().id(), key, request, Channel.fromHeader(channel)));
    }

    @PostMapping("/withdraw")
    @Operation(summary = "Withdraw funds (simulated)",
            description = "Debits the caller's account. A withdrawal exceeding the balance is recorded as a FAILED transaction (HTTP 422, reason INSUFFICIENT_FUNDS).")
    public ResponseEntity<TransactionView> withdraw(
            @Parameter(description = KEY_DESC) @RequestHeader("Idempotency-Key") String key,
            @RequestHeader(value = "X-Client-Channel", required = false) String channel,
            @Valid @RequestBody WithdrawalRequest request) {
        return respond(facade.withdraw(AuthenticatedUser.current().id(), key, request, Channel.fromHeader(channel)));
    }

    @PostMapping("/transfer")
    @Operation(summary = "Transfer funds to another KivuBank account",
            description = "Returns 201 on success, 422 with a FAILED transaction when funds are insufficient, and 202 with a PENDING "
                    + "transaction when the amount reaches the manual-review threshold (an ADMIN must approve it).")
    public ResponseEntity<TransactionView> transfer(
            @Parameter(description = KEY_DESC) @RequestHeader("Idempotency-Key") String key,
            @RequestHeader(value = "X-Client-Channel", required = false) String channel,
            @Valid @RequestBody TransferRequest request) {
        return respond(facade.transfer(AuthenticatedUser.current().id(), key, request, Channel.fromHeader(channel)));
    }

    @GetMapping
    @Operation(summary = "Transaction history",
            description = "Paginated and filterable. Sort with sort=createdAt,desc | amount,asc | status | type. Page size max 100.")
    public PageResponse<TransactionView> history(
            @RequestParam(required = false) TransactionStatus status,
            @RequestParam(required = false) TransactionType type,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to,
            @RequestParam(required = false) BigDecimal minAmount,
            @RequestParam(required = false) BigDecimal maxAmount,
            @PageableDefault(size = 20) Pageable pageable) {
        TransactionFilter filter = new TransactionFilter(status, type, from, to, minAmount, maxAmount, null);
        return queries.listForUser(AuthenticatedUser.current().id(), filter, pageable);
    }

    @GetMapping("/{reference}")
    @Operation(summary = "Transaction details", description = "Only transactions involving the caller's account are visible (others return 404).")
    public TransactionView details(@PathVariable @Pattern(regexp = "^[A-Z0-9-]{8,40}$") String reference) {
        return queries.getForUser(AuthenticatedUser.current().id(), reference);
    }

    @PostMapping("/{reference}/cancel")
    @Operation(summary = "Cancel a PENDING transaction", description = "Only PENDING (awaiting review) transactions can be cancelled.")
    public TransactionView cancel(@PathVariable @Pattern(regexp = "^[A-Z0-9-]{8,40}$") String reference) {
        AuthenticatedUser me = AuthenticatedUser.current();
        TransactionOutcome outcome = processor.cancel(reference, me.id(), me.role());
        return outcome.view();
    }

    private ResponseEntity<TransactionView> respond(IdempotentResult r) {
        ResponseEntity.BodyBuilder b = ResponseEntity.status(r.httpStatus());
        if (r.replayed()) {
            b.header("Idempotent-Replayed", "true");
        }
        return b.body(r.view());
    }
}
