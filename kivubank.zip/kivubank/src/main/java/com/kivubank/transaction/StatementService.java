package com.kivubank.transaction;

import com.kivubank.account.Account;
import com.kivubank.account.AccountRepository;
import com.kivubank.audit.AuditAction;
import com.kivubank.audit.AuditOutcome;
import com.kivubank.audit.AuditService;
import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import com.kivubank.event.DomainEvents.StatementEvent;
import com.kivubank.transaction.TransactionDtos.TransactionView;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Generates CSV statements (max 366 days, 5,000 rows) and emits a statement notification. */
@Service
public class StatementService {
    private static final int MAX_ROWS = 5000;
    private final AccountRepository accounts;
    private final TransactionRepository transactions;
    private final AuditService audit;
    private final ApplicationEventPublisher events;
    private final Clock clock;

    public StatementService(AccountRepository accounts, TransactionRepository transactions, AuditService audit,
                            ApplicationEventPublisher events, Clock clock) {
        this.accounts = accounts;
        this.transactions = transactions;
        this.audit = audit;
        this.events = events;
        this.clock = clock;
    }

    @Transactional
    public String generateCsv(Long userId, Instant from, Instant to) {
        Instant end = to == null ? clock.instant() : to;
        Instant start = from == null ? end.minus(Duration.ofDays(30)) : from;
        if (!start.isBefore(end) || Duration.between(start, end).toDays() > 366) {
            throw new BusinessException(ErrorCode.VALIDATION_FAILED, "Statement range must be positive and at most 366 days.");
        }
        Account account = accounts.findByUserId(userId)
                .orElseThrow(() -> new BusinessException(ErrorCode.ACCOUNT_NOT_FOUND, "Account not found."));
        TransactionFilter filter = new TransactionFilter(null, null, start, end, null, null, null);
        var page = transactions.findAll(TransactionSpecs.involving(account.getId()).and(TransactionSpecs.matching(filter)),
                PageRequest.of(0, MAX_ROWS, Sort.by(Sort.Direction.ASC, "createdAt")));
        StringBuilder csv = new StringBuilder("# KivuBank SIMULATED statement - not a real bank document\n");
        csv.append("# Account,").append(account.getAccountNumber()).append(",Currency,").append(account.getCurrency()).append('\n');
        csv.append("reference,created_at,type,status,direction,amount,currency,counterparty,balance_after,description\n");
        for (Transaction t : page.getContent()) {
            TransactionView v = TransactionMapper.toView(t, account.getId());
            String counterparty = "DEBIT".equals(v.direction()) ? v.targetAccountNumber() : v.sourceAccountNumber();
            csv.append(v.reference()).append(',').append(v.createdAt()).append(',').append(v.type()).append(',')
                    .append(v.status()).append(',').append(nz(v.direction())).append(',').append(v.amount().toPlainString())
                    .append(',').append(v.currency()).append(',').append(nz(counterparty)).append(',')
                    .append(v.balanceAfter() == null ? "" : v.balanceAfter().toPlainString()).append(',')
                    .append(escape(v.description())).append('\n');
        }
        audit.recordForUser(userId, AuditAction.STATEMENT_GENERATED, AuditOutcome.SUCCESS, "ACCOUNT",
                account.getAccountNumber(), "rows=" + page.getNumberOfElements());
        events.publishEvent(new StatementEvent(userId, account.getAccountNumber(), start + " to " + end, page.getNumberOfElements()));
        return csv.toString();
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    /** Quotes the field and neutralises spreadsheet formula injection (=, +, -, @ prefixes). */
    static String escape(String s) {
        if (s == null || s.isEmpty()) {
            return "";
        }
        String v = s.replace("\"", "\"\"");
        if ("=+-@\t\r".indexOf(v.charAt(0)) >= 0) {
            v = "'" + v;
        }
        return "\"" + v + "\"";
    }
}
