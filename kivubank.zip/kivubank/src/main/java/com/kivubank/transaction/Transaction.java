package com.kivubank.transaction;

import com.kivubank.account.Account;
import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "transactions")
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, unique = true, length = 40)
    private String reference;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TransactionType type;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TransactionStatus status;
    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal amount;
    @Column(nullable = false, length = 3)
    private String currency;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "source_account_id")
    private Account sourceAccount;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "target_account_id")
    private Account targetAccount;
    @Column(precision = 19, scale = 2)
    private BigDecimal sourceBalanceAfter;
    @Column(precision = 19, scale = 2)
    private BigDecimal targetBalanceAfter;
    @Column(length = 200)
    private String description;
    @Column(length = 200)
    private String failureReason;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Channel channel;
    private Long initiatedByUserId;
    @Column(length = 80)
    private String idempotencyKey;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "reversal_of_id")
    private Transaction reversalOf;
    @Version
    private Long version;
    @Column(nullable = false)
    private Instant createdAt;
    @Column(nullable = false)
    private Instant updatedAt;
    private Instant completedAt;

    protected Transaction() {
    }

    public Transaction(String reference, TransactionType type, BigDecimal amount, String currency, Account source,
                       Account target, String description, Channel channel, Long initiatedByUserId,
                       String idempotencyKey, Instant now) {
        this.reference = reference;
        this.type = type;
        this.status = TransactionStatus.PENDING;
        this.amount = amount;
        this.currency = currency;
        this.sourceAccount = source;
        this.targetAccount = target;
        this.description = description;
        this.channel = channel;
        this.initiatedByUserId = initiatedByUserId;
        this.idempotencyKey = idempotencyKey;
        this.createdAt = now;
        this.updatedAt = now;
    }

    /** Moves along the state machine; illegal transitions are rejected. */
    public void transitionTo(TransactionStatus next, Instant now) {
        if (!status.canTransitionTo(next)) {
            throw new BusinessException(ErrorCode.INVALID_STATE_TRANSITION,
                    "Cannot move a " + status + " transaction to " + next + ".");
        }
        this.status = next;
        this.updatedAt = now;
        if (next == TransactionStatus.SUCCESS || next == TransactionStatus.FAILED || next == TransactionStatus.CANCELLED) {
            this.completedAt = now;
        }
    }

    public void fail(String reason, Instant now) {
        transitionTo(TransactionStatus.FAILED, now);
        this.failureReason = reason;
    }

    public Long getId() { return id; }
    public String getReference() { return reference; }
    public TransactionType getType() { return type; }
    public TransactionStatus getStatus() { return status; }
    public BigDecimal getAmount() { return amount; }
    public String getCurrency() { return currency; }
    public Account getSourceAccount() { return sourceAccount; }
    public Account getTargetAccount() { return targetAccount; }
    public BigDecimal getSourceBalanceAfter() { return sourceBalanceAfter; }
    public void setSourceBalanceAfter(BigDecimal v) { this.sourceBalanceAfter = v; }
    public BigDecimal getTargetBalanceAfter() { return targetBalanceAfter; }
    public void setTargetBalanceAfter(BigDecimal v) { this.targetBalanceAfter = v; }
    public String getDescription() { return description; }
    public String getFailureReason() { return failureReason; }
    public Channel getChannel() { return channel; }
    public Long getInitiatedByUserId() { return initiatedByUserId; }
    public String getIdempotencyKey() { return idempotencyKey; }
    public Transaction getReversalOf() { return reversalOf; }
    public void setReversalOf(Transaction reversalOf) { this.reversalOf = reversalOf; }
    public Long getVersion() { return version; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
    public Instant getCompletedAt() { return completedAt; }
}
