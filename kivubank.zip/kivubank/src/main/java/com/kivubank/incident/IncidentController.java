package com.kivubank.incident;

import com.kivubank.common.PageResponse;
import com.kivubank.incident.IncidentService.IncidentChange;
import com.kivubank.incident.IncidentService.IncidentView;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/incidents")
@Tag(name = "Incidents", description = "Internal incident management (ADMIN and SUPPORT_AGENT manage; AUDITOR read-only).")
@SecurityRequirement(name = "bearerAuth")
public class IncidentController {
    private final IncidentService service;

    public IncidentController(IncidentService service) {
        this.service = service;
    }

    public record CreateIncidentRequest(
            @Schema(example = "Elevated transfer failures") @NotBlank @Size(max = 150) String title,
            @Schema(example = "Failure rate above 10% for 15 minutes in the simulated environment") @NotBlank @Size(max = 2000) String description,
            @NotNull IncidentSeverity severity,
            @NotNull AffectedService affectedService,
            @Schema(example = "Platform team") @Size(max = 120) String assignee) {
    }

    public record UpdateIncidentRequest(
            @Size(max = 150) String title,
            @Size(max = 2000) String description,
            IncidentSeverity severity,
            AffectedService affectedService,
            @Size(max = 120) String assignee,
            IncidentStatus status,
            @Size(max = 2000) String resolution,
            @Size(max = 2000) String rootCause) {
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','SUPPORT_AGENT')")
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Open an incident")
    public IncidentView create(@Valid @RequestBody CreateIncidentRequest r) {
        return service.create(r.title(), r.description(), r.severity(), r.affectedService(), r.assignee());
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','SUPPORT_AGENT','AUDITOR')")
    @Operation(summary = "List incidents", description = "Filter by status and/or severity; newest first.")
    public PageResponse<IncidentView> list(@RequestParam(required = false) IncidentStatus status,
                                           @RequestParam(required = false) IncidentSeverity severity,
                                           @RequestParam(defaultValue = "0") int page,
                                           @RequestParam(defaultValue = "20") int size) {
        return service.list(status, severity, page, size);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','SUPPORT_AGENT','AUDITOR')")
    @Operation(summary = "Get an incident")
    public IncidentView get(@PathVariable Long id) {
        return service.get(id);
    }

    @PatchMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','SUPPORT_AGENT')")
    @Operation(summary = "Update an incident",
            description = "Partial update. Status follows OPEN -> INVESTIGATING -> MITIGATED -> RESOLVED -> CLOSED. "
                    + "Resolving or closing requires a resolution and a root cause; resolvedAt/closedAt are set automatically.")
    public IncidentView update(@PathVariable Long id, @Valid @RequestBody UpdateIncidentRequest r) {
        return service.update(id, new IncidentChange(r.title(), r.description(), r.severity(), r.affectedService(),
                r.assignee(), r.status(), r.resolution(), r.rootCause()));
    }
}
