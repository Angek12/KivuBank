package com.kivubank.incident;

public enum IncidentSeverity { LOW, MEDIUM, HIGH, CRITICAL }
