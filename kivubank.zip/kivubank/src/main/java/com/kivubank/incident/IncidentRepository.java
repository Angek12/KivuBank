package com.kivubank.incident;

import java.util.Collection;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IncidentRepository extends JpaRepository<Incident, Long> {
    Page<Incident> findByStatus(IncidentStatus status, Pageable pageable);

    Page<Incident> findBySeverity(IncidentSeverity severity, Pageable pageable);

    Page<Incident> findByStatusAndSeverity(IncidentStatus status, IncidentSeverity severity, Pageable pageable);

    long countByStatusIn(Collection<IncidentStatus> statuses);

    List<Incident> findByStatusInAndSeverityIn(Collection<IncidentStatus> statuses, Collection<IncidentSeverity> severities);

    List<Incident> findAllByOrderByCreatedAtDesc(Pageable pageable);
}
