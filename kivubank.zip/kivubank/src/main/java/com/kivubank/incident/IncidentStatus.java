package com.kivubank.incident;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;

/** OPEN -> INVESTIGATING -> MITIGATED -> RESOLVED -> CLOSED (a RESOLVED incident may be reopened to INVESTIGATING). */
public enum IncidentStatus {
    OPEN, INVESTIGATING, MITIGATED, RESOLVED, CLOSED;

    private static final Map<IncidentStatus, Set<IncidentStatus>> ALLOWED = new EnumMap<>(IncidentStatus.class);

    static {
        ALLOWED.put(OPEN, EnumSet.of(INVESTIGATING, MITIGATED, RESOLVED));
        ALLOWED.put(INVESTIGATING, EnumSet.of(MITIGATED, RESOLVED));
        ALLOWED.put(MITIGATED, EnumSet.of(INVESTIGATING, RESOLVED));
        ALLOWED.put(RESOLVED, EnumSet.of(CLOSED, INVESTIGATING));
        ALLOWED.put(CLOSED, EnumSet.noneOf(IncidentStatus.class));
    }

    public boolean canTransitionTo(IncidentStatus next) {
        return ALLOWED.get(this).contains(next);
    }

    public boolean isActive() {
        return this != RESOLVED && this != CLOSED;
    }
}
