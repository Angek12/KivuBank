package com.kivubank.incident;

import com.kivubank.audit.AuditAction;
import com.kivubank.audit.AuditOutcome;
import com.kivubank.audit.AuditService;
import com.kivubank.auth.AuthenticatedUser;
import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import com.kivubank.common.PageResponse;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class IncidentService {
    private final IncidentRepository repository;
    private final AuditService audit;
    private final Clock clock;

    public IncidentService(IncidentRepository repository, AuditService audit, Clock clock) {
        this.repository = repository;
        this.audit = audit;
        this.clock = clock;
    }

    public record IncidentView(Long id, String incidentId, String title, String description, IncidentSeverity severity,
                               AffectedService affectedService, IncidentStatus status, String assignee, Instant createdAt,
                               Instant updatedAt, String resolution, String rootCause, Instant resolvedAt, Instant closedAt) {
        public static IncidentView of(Incident i) {
            return new IncidentView(i.getId(), format(i.getId()), i.getTitle(), i.getDescription(), i.getSeverity(),
                    i.getAffectedService(), i.getStatus(), i.getAssignee(), i.getCreatedAt(), i.getUpdatedAt(),
                    i.getResolution(), i.getRootCause(), i.getResolvedAt(), i.getClosedAt());
        }

        public static String format(Long id) {
            return String.format("INC-%05d", id);
        }
    }

    /** Fields left null are not changed. */
    public record IncidentChange(String title, String description, IncidentSeverity severity, AffectedService affectedService,
                                 String assignee, IncidentStatus status, String resolution, String rootCause) {
    }

    @Transactional
    public IncidentView create(String title, String description, IncidentSeverity severity, AffectedService service, String assignee) {
        Incident saved = repository.save(new Incident(title.trim(), description.trim(), severity, service,
                blankToNull(assignee), AuthenticatedUser.current().id(), clock.instant()));
        audit.record(AuditAction.INCIDENT_CREATED, AuditOutcome.SUCCESS, "INCIDENT", IncidentView.format(saved.getId()),
                "severity=" + severity + " service=" + service);
        return IncidentView.of(saved);
    }

    @Transactional
    public IncidentView update(Long id, IncidentChange c) {
        Incident i = repository.findById(id).orElseThrow(() -> new BusinessException(ErrorCode.NOT_FOUND, "Incident not found."));
        Instant now = clock.instant();
        if (i.getStatus() == IncidentStatus.CLOSED) {
            throw new BusinessException(ErrorCode.INVALID_STATE_TRANSITION, "A closed incident can no longer be modified.");
        }
        if (c.title() != null && !c.title().isBlank()) i.setTitle(c.title().trim());
        if (c.description() != null && !c.description().isBlank()) i.setDescription(c.description().trim());
        if (c.severity() != null) i.setSeverity(c.severity());
        if (c.affectedService() != null) i.setAffectedService(c.affectedService());
        if (c.assignee() != null) i.setAssignee(blankToNull(c.assignee()));
        if (c.resolution() != null) i.setResolution(blankToNull(c.resolution()));
        if (c.rootCause() != null) i.setRootCause(blankToNull(c.rootCause()));
        if (c.status() != null && c.status() != i.getStatus()) {
            if (!i.getStatus().canTransitionTo(c.status())) {
                throw new BusinessException(ErrorCode.INVALID_STATE_TRANSITION,
                        "Cannot move an incident from " + i.getStatus() + " to " + c.status() + ".");
            }
            if (c.status() == IncidentStatus.RESOLVED || c.status() == IncidentStatus.CLOSED) {
                if (i.getResolution() == null || i.getRootCause() == null) {
                    throw new BusinessException(ErrorCode.VALIDATION_FAILED,
                            "A resolution and a root cause are required to resolve or close an incident.");
                }
            }
            if (c.status() == IncidentStatus.RESOLVED) i.setResolvedAt(now);
            if (c.status() == IncidentStatus.CLOSED) i.setClosedAt(now);
            if (c.status() == IncidentStatus.INVESTIGATING && i.getStatus() == IncidentStatus.RESOLVED) {
                i.setResolvedAt(null);   // reopened
            }
            i.setStatus(c.status());
        }
        i.touch(now);
        audit.record(AuditAction.INCIDENT_UPDATED, AuditOutcome.SUCCESS, "INCIDENT", IncidentView.format(i.getId()),
                "status=" + i.getStatus() + " severity=" + i.getSeverity());
        return IncidentView.of(i);
    }

    @Transactional(readOnly = true)
    public IncidentView get(Long id) {
        return repository.findById(id).map(IncidentView::of)
                .orElseThrow(() -> new BusinessException(ErrorCode.NOT_FOUND, "Incident not found."));
    }

    @Transactional(readOnly = true)
    public PageResponse<IncidentView> list(IncidentStatus status, IncidentSeverity severity, int page, int size) {
        PageRequest p = PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100), Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<Incident> result;
        if (status != null && severity != null) result = repository.findByStatusAndSeverity(status, severity, p);
        else if (status != null) result = repository.findByStatus(status, p);
        else if (severity != null) result = repository.findBySeverity(severity, p);
        else result = repository.findAll(p);
        return PageResponse.of(result, IncidentView::of);
    }

    @Transactional(readOnly = true)
    public List<IncidentView> recent(int limit) {
        return repository.findAllByOrderByCreatedAtDesc(PageRequest.of(0, limit)).stream().map(IncidentView::of).toList();
    }

    private static String blankToNull(String s) {
        return s == null || s.isBlank() ? null : s.trim();
    }
}
