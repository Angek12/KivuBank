package com.kivubank.incident;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;

@Entity
@Table(name = "incidents")
public class Incident {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 150)
    private String title;
    @Column(nullable = false, length = 2000)
    private String description;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private IncidentSeverity severity;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AffectedService affectedService;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private IncidentStatus status = IncidentStatus.OPEN;
    @Column(length = 120)
    private String assignee;
    private Long createdByUserId;
    @Column(nullable = false)
    private Instant createdAt;
    @Column(nullable = false)
    private Instant updatedAt;
    @Column(length = 2000)
    private String resolution;
    @Column(length = 2000)
    private String rootCause;
    private Instant resolvedAt;
    private Instant closedAt;

    protected Incident() {
    }

    public Incident(String title, String description, IncidentSeverity severity, AffectedService affectedService,
                    String assignee, Long createdByUserId, Instant now) {
        this.title = title;
        this.description = description;
        this.severity = severity;
        this.affectedService = affectedService;
        this.assignee = assignee;
        this.createdByUserId = createdByUserId;
        this.createdAt = now;
        this.updatedAt = now;
    }

    public void setTitle(String title) { this.title = title; }
    public void setDescription(String description) { this.description = description; }
    public void setSeverity(IncidentSeverity severity) { this.severity = severity; }
    public void setAffectedService(AffectedService s) { this.affectedService = s; }
    public void setAssignee(String assignee) { this.assignee = assignee; }
    public void setResolution(String resolution) { this.resolution = resolution; }
    public void setRootCause(String rootCause) { this.rootCause = rootCause; }
    public void setStatus(IncidentStatus status) { this.status = status; }
    public void setResolvedAt(Instant resolvedAt) { this.resolvedAt = resolvedAt; }
    public void setClosedAt(Instant closedAt) { this.closedAt = closedAt; }
    public void touch(Instant now) { this.updatedAt = now; }

    public Long getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public IncidentSeverity getSeverity() { return severity; }
    public AffectedService getAffectedService() { return affectedService; }
    public IncidentStatus getStatus() { return status; }
    public String getAssignee() { return assignee; }
    public Long getCreatedByUserId() { return createdByUserId; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
    public String getResolution() { return resolution; }
    public String getRootCause() { return rootCause; }
    public Instant getResolvedAt() { return resolvedAt; }
    public Instant getClosedAt() { return closedAt; }
}
