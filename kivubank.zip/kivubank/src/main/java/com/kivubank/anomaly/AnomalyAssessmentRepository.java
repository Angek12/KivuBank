package com.kivubank.anomaly;

import java.time.Instant;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnomalyAssessmentRepository extends JpaRepository<AnomalyAssessment, Long> {
    Page<AnomalyAssessment> findByFlagged(boolean flagged, Pageable pageable);

    boolean existsByTransactionId(Long transactionId);

    long countByFlaggedTrueAndCreatedAtAfter(Instant since);

    long countByFlaggedTrue();

}
