package com.kivubank.anomaly;

import java.util.Random;

/**
 * Generates SYNTHETIC outgoing-transaction feature rows. "Normal" rows follow plausible everyday behaviour;
 * "anomalous" rows follow four hand-written patterns (spike, burst, odd hours, account drain).
 * This is not real customer data and does not represent real-world fraud.
 */
public final class SyntheticTransactionGenerator {
    private final Random random;

    public SyntheticTransactionGenerator(long seed) {
        this.random = new Random(seed);
    }

    public FeatureVector normal() {
        double baseline = Math.exp(9.5 + 0.8 * random.nextGaussian());   // ~13,000 median
        double ratio = clamp(Math.exp(0.5 * random.nextGaussian()), 0.1, 4.0);
        double amount = baseline * ratio;
        int hour = random.nextDouble() < 0.88
                ? 7 + (int) Math.round(clamp(7 + 3.5 * random.nextGaussian(), 0, 14))   // 7..21, peak around 14h
                : pick(5, 6, 22, 23);
        int lastHour = Math.min(6, poisson(0.4));
        boolean withdrawal = random.nextDouble() < 0.35;
        boolean newCounterparty = !withdrawal && random.nextDouble() < 0.2;
        double fraction = clamp(-0.12 * Math.log(1 - random.nextDouble()) + 0.01, 0.01, 0.95);
        return FeatureVector.of(amount, baseline, hour, lastHour, withdrawal, newCounterparty, fraction);
    }

    public FeatureVector anomalous() {
        double baseline = Math.exp(9.5 + 0.8 * random.nextGaussian());
        switch (random.nextInt(4)) {
            case 0: { // amount spike to a new recipient
                double ratio = 6 + random.nextDouble() * 19;
                return FeatureVector.of(baseline * ratio, baseline, 9 + random.nextInt(12), poisson(0.4), false, true,
                        0.6 + random.nextDouble() * 0.4);
            }
            case 1: { // burst of many transactions within an hour
                double ratio = 1 + random.nextDouble() * 2;
                return FeatureVector.of(baseline * ratio, baseline, 8 + random.nextInt(14), 6 + random.nextInt(10),
                        random.nextBoolean(), random.nextBoolean(), 0.1 + random.nextDouble() * 0.4);
            }
            case 2: { // unusual hour and elevated amount
                double ratio = 2 + random.nextDouble() * 6;
                return FeatureVector.of(baseline * ratio, baseline, random.nextInt(5), poisson(0.6), false, true,
                        0.2 + random.nextDouble() * 0.5);
            }
            default: { // draining almost the whole balance
                double ratio = 3 + random.nextDouble() * 9;
                return FeatureVector.of(baseline * ratio, baseline, 6 + random.nextInt(16), poisson(0.5),
                        random.nextBoolean(), true, 0.9 + random.nextDouble() * 0.1);
            }
        }
    }

    private int pick(int... values) {
        return values[random.nextInt(values.length)];
    }

    private int poisson(double lambda) {
        double limit = Math.exp(-lambda);
        double p = 1;
        int k = 0;
        do {
            k++;
            p *= random.nextDouble();
        } while (p > limit && k < 50);
        return k - 1;
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
