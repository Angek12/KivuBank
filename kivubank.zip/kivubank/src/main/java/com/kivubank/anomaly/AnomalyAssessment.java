package com.kivubank.anomaly;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "anomaly_assessments")
public class AnomalyAssessment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, unique = true)
    private Long transactionId;
    @Column(nullable = false, length = 40)
    private String transactionReference;
    @Column(nullable = false)
    private Long accountId;
    @Column(nullable = false, precision = 6, scale = 4)
    private BigDecimal score;
    @Column(nullable = false)
    private boolean flagged;
    @Column(length = 1000)
    private String reasons;
    @Column(length = 500)
    private String features;
    @Column(nullable = false, length = 40)
    private String modelVersion;
    @Column(nullable = false)
    private Instant createdAt;

    protected AnomalyAssessment() {
    }

    public AnomalyAssessment(Long transactionId, String transactionReference, Long accountId, BigDecimal score,
                             boolean flagged, String reasons, String features, String modelVersion, Instant now) {
        this.transactionId = transactionId;
        this.transactionReference = transactionReference;
        this.accountId = accountId;
        this.score = score;
        this.flagged = flagged;
        this.reasons = reasons != null && reasons.length() > 1000 ? reasons.substring(0, 1000) : reasons;
        this.features = features;
        this.modelVersion = modelVersion;
        this.createdAt = now;
    }

    public Long getId() { return id; }
    public Long getTransactionId() { return transactionId; }
    public String getTransactionReference() { return transactionReference; }
    public Long getAccountId() { return accountId; }
    public BigDecimal getScore() { return score; }
    public boolean isFlagged() { return flagged; }
    public String getReasons() { return reasons; }
    public String getFeatures() { return features; }
    public String getModelVersion() { return modelVersion; }
    public Instant getCreatedAt() { return createdAt; }
}
