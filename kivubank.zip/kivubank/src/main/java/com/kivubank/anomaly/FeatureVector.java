package com.kivubank.anomaly;

/**
 * Numeric features describing one outgoing transaction.
 * @param logAmount        ln(1 + amount)
 * @param amountRatio      amount divided by the account's usual outgoing amount (or the population median for new accounts)
 * @param hourUtc          hour of day (0-23, UTC)
 * @param txLastHour       outgoing transactions by the same account in the previous hour
 * @param typeCode         0 = transfer, 1 = withdrawal
 * @param newCounterparty  1 when the recipient was never paid before, else 0
 * @param balanceFraction  share of the available balance this transaction uses (0-1)
 */
public record FeatureVector(double logAmount, double amountRatio, double hourUtc, double txLastHour, double typeCode,
                            double newCounterparty, double balanceFraction) {

    public static final String[] NAMES = {"logAmount", "amountRatio", "hourUtc", "txLastHour", "typeCode",
            "newCounterparty", "balanceFraction"};

    public double[] toArray() {
        return new double[]{logAmount, amountRatio, hourUtc, txLastHour, typeCode, newCounterparty, balanceFraction};
    }

    public static FeatureVector of(double amount, double typicalAmount, int hourUtc, int txLastHour, boolean withdrawal,
                                   boolean newCounterparty, double balanceFraction) {
        double baseline = typicalAmount <= 0 ? 1.0 : typicalAmount;
        return new FeatureVector(Math.log1p(amount), amount / baseline, hourUtc, txLastHour, withdrawal ? 1 : 0,
                newCounterparty ? 1 : 0, Math.min(Math.max(balanceFraction, 0), 1));
    }

    String compact() {
        return String.format(java.util.Locale.ROOT, "ratio=%.2f hour=%d lastHour=%d type=%s newCp=%d balFrac=%.2f",
                amountRatio, (int) hourUtc, (int) txLastHour, typeCode == 0 ? "TRANSFER" : "WITHDRAWAL",
                (int) newCounterparty, balanceFraction);
    }
}
