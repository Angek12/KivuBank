package com.kivubank.anomaly;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Minimal Isolation Forest (Liu, Ting &amp; Zhou, 2008) for unsupervised anomaly detection.
 * Anomalies are isolated by random axis-parallel splits in fewer steps; score = 2^(-E[h(x)]/c(psi)),
 * close to 1 for anomalies and around 0.5 or lower for normal points.
 */
public final class IsolationForest {
    private static final double EULER = 0.5772156649;

    private static final class Node {
        int feature = -1;
        double split;
        Node left;
        Node right;
        int size;
    }

    private final int trees;
    private final int subSampleSize;
    private final Random random;
    private Node[] forest = new Node[0];
    private double normaliser = 1;

    public IsolationForest(int trees, int subSampleSize, long seed) {
        this.trees = trees;
        this.subSampleSize = subSampleSize;
        this.random = new Random(seed);
    }

    public void fit(double[][] data) {
        if (data.length < 2) {
            throw new IllegalArgumentException("Need at least two training rows");
        }
        int psi = Math.min(subSampleSize, data.length);
        int maxDepth = (int) Math.ceil(Math.log(psi) / Math.log(2));
        forest = new Node[trees];
        for (int t = 0; t < trees; t++) {
            forest[t] = build(sample(data, psi), 0, maxDepth);
        }
        normaliser = averagePathLength(psi);
    }

    /** @return anomaly score in (0,1); higher means more anomalous. */
    public double score(double[] x) {
        if (forest.length == 0) {
            throw new IllegalStateException("Model has not been trained");
        }
        double total = 0;
        for (Node root : forest) {
            total += pathLength(root, x, 0);
        }
        double expected = total / forest.length;
        return Math.pow(2, -expected / normaliser);
    }

    private List<double[]> sample(double[][] data, int psi) {
        int[] idx = new int[data.length];
        for (int i = 0; i < idx.length; i++) {
            idx[i] = i;
        }
        for (int i = 0; i < psi; i++) { // partial Fisher-Yates shuffle
            int j = i + random.nextInt(idx.length - i);
            int tmp = idx[i];
            idx[i] = idx[j];
            idx[j] = tmp;
        }
        List<double[]> rows = new ArrayList<>(psi);
        for (int i = 0; i < psi; i++) {
            rows.add(data[idx[i]]);
        }
        return rows;
    }

    private Node build(List<double[]> rows, int depth, int maxDepth) {
        Node node = new Node();
        node.size = rows.size();
        if (depth >= maxDepth || rows.size() <= 1) {
            return node;
        }
        int dims = rows.get(0).length;
        int feature = random.nextInt(dims);
        double min = 0;
        double max = 0;
        boolean splittable = false;
        for (int attempt = 0; attempt < dims && !splittable; attempt++) {
            min = Double.POSITIVE_INFINITY;
            max = Double.NEGATIVE_INFINITY;
            for (double[] r : rows) {
                min = Math.min(min, r[feature]);
                max = Math.max(max, r[feature]);
            }
            if (max > min) {
                splittable = true;
            } else {
                feature = (feature + 1) % dims;
            }
        }
        if (!splittable) {
            return node;
        }
        double split = min + random.nextDouble() * (max - min);
        List<double[]> left = new ArrayList<>();
        List<double[]> right = new ArrayList<>();
        for (double[] r : rows) {
            (r[feature] < split ? left : right).add(r);
        }
        node.feature = feature;
        node.split = split;
        node.left = build(left, depth + 1, maxDepth);
        node.right = build(right, depth + 1, maxDepth);
        return node;
    }

    private double pathLength(Node node, double[] x, int depth) {
        if (node.feature < 0) {
            return depth + averagePathLength(node.size);
        }
        return pathLength(x[node.feature] < node.split ? node.left : node.right, x, depth + 1);
    }

    /** c(n): average path length of an unsuccessful search in a binary search tree of n items. */
    static double averagePathLength(int n) {
        if (n <= 1) {
            return 0;
        }
        if (n == 2) {
            return 1;
        }
        return 2.0 * (Math.log(n - 1.0) + EULER) - 2.0 * (n - 1.0) / n;
    }
}
