package com.kivubank.anomaly;

import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import com.kivubank.config.KivuBankProperties;
import jakarta.annotation.PostConstruct;
import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * EXPERIMENTAL anomaly model: an Isolation Forest trained at start-up on SYNTHETIC data only.
 * It demonstrates the pipeline (features -> score -> flag -> explanation); it is not a fraud-detection product.
 */
@Component
public class AnomalyModel {
    public static final String VERSION = "iforest-synthetic-v1";
    public static final String DISCLAIMER = "EXPERIMENTAL: trained and validated on synthetic data only. "
            + "Scores illustrate anomaly detection; they are not real-world fraud detection.";
    private static final Logger log = LoggerFactory.getLogger(AnomalyModel.class);

    public record Result(double score, boolean flagged, List<String> reasons) {
    }

    public record Info(boolean experimental, String disclaimer, String modelVersion, String trainedOn, int trees,
                       int subSampleSize, int trainingRows, double threshold, double thresholdPercentile,
                       Instant trainedAt, Validation validation) {
    }

    public record Validation(int normalRows, int anomalousRows, int truePositives, int falsePositives,
                             int falseNegatives, double precision, double recall, double f1) {
    }

    private final KivuBankProperties props;
    private final Clock clock;
    private volatile IsolationForest forest;
    private volatile double threshold;
    private volatile double typicalAmount;
    private volatile double[][] featureP95;      // [feature] -> {p50, p95}
    private volatile double[] hourFrequency = new double[24];
    private volatile Info info;

    public AnomalyModel(KivuBankProperties props, Clock clock) {
        this.props = props;
        this.clock = clock;
    }

    @PostConstruct
    void train() {
        KivuBankProperties.Anomaly cfg = props.anomaly();
        if (!cfg.enabled()) {
            log.info("Anomaly detection disabled by configuration");
            return;
        }
        SyntheticTransactionGenerator trainGen = new SyntheticTransactionGenerator(cfg.seed());
        int n = cfg.trainingSamples();
        double[][] train = new double[n][];
        int contaminated = Math.max(1, n / 100);               // 1% anomalies mixed in (unsupervised setting)
        for (int i = 0; i < n; i++) {
            train[i] = (i < contaminated ? trainGen.anomalous() : trainGen.normal()).toArray();
        }
        IsolationForest model = new IsolationForest(cfg.trees(), cfg.subSampleSize(), cfg.seed());
        model.fit(train);

        double[] scores = Arrays.stream(train).mapToDouble(model::score).sorted().toArray();
        this.threshold = percentile(scores, cfg.thresholdPercentile());
        int dims = FeatureVector.NAMES.length;
        double[][] stats = new double[dims][2];
        for (int f = 0; f < dims; f++) {
            final int col = f;
            double[] column = Arrays.stream(train).mapToDouble(r -> r[col]).sorted().toArray();
            stats[f][0] = percentile(column, 50);
            stats[f][1] = percentile(column, 95);
        }
        double[] amounts = Arrays.stream(train).mapToDouble(r -> Math.expm1(r[0])).sorted().toArray();
        this.typicalAmount = percentile(amounts, 50);
        double[] hours = new double[24];
        for (double[] r : train) {
            hours[(int) r[2]]++;
        }
        for (int h = 0; h < 24; h++) {
            hours[h] /= n;
        }
        this.hourFrequency = hours;
        this.featureP95 = stats;
        this.forest = model;
        this.info = new Info(true, DISCLAIMER, VERSION, "synthetic transactions (seeded generator)", cfg.trees(),
                Math.min(cfg.subSampleSize(), n), n, threshold, cfg.thresholdPercentile(), clock.instant(),
                validate(cfg.seed() + 1));
        log.info("Anomaly model trained on {} synthetic rows; threshold={}, validation F1={}",
                n, String.format(Locale.ROOT, "%.4f", threshold), String.format(Locale.ROOT, "%.2f", info.validation().f1()));
    }

    public boolean isReady() {
        return forest != null;
    }

    public double typicalAmount() {
        return typicalAmount;
    }

    public Info info() {
        requireReady();
        return info;
    }

    public Result assess(FeatureVector fv) {
        requireReady();
        double score = forest.score(fv.toArray());
        boolean flagged = score >= threshold;
        return new Result(score, flagged, flagged ? explain(fv) : List.of());
    }

    /** Held-out synthetic validation: fresh generator seed, 1000 normal + 100 anomalous labelled rows. */
    private Validation validate(long seed) {
        SyntheticTransactionGenerator gen = new SyntheticTransactionGenerator(seed);
        int normal = 1000;
        int anomalous = 100;
        int tp = 0;
        int fp = 0;
        int fn = 0;
        for (int i = 0; i < normal; i++) {
            if (forest.score(gen.normal().toArray()) >= threshold) fp++;
        }
        for (int i = 0; i < anomalous; i++) {
            if (forest.score(gen.anomalous().toArray()) >= threshold) tp++; else fn++;
        }
        double precision = tp + fp == 0 ? 0 : (double) tp / (tp + fp);
        double recall = tp + fn == 0 ? 0 : (double) tp / (tp + fn);
        double f1 = precision + recall == 0 ? 0 : 2 * precision * recall / (precision + recall);
        return new Validation(normal, anomalous, tp, fp, fn, round(precision), round(recall), round(f1));
    }

    private List<String> explain(FeatureVector fv) {
        List<String> reasons = new ArrayList<>();
        if (fv.amountRatio() >= 3 && fv.amountRatio() > featureP95[1][1]) {
            reasons.add(String.format(Locale.ROOT, "Amount is %.1fx the account's usual outgoing amount (95%% of synthetic transactions are below %.1fx).",
                    fv.amountRatio(), featureP95[1][1]));
        }
        if (fv.txLastHour() >= 3 && fv.txLastHour() > featureP95[3][1]) {
            reasons.add(String.format(Locale.ROOT, "%d outgoing transactions in the previous hour (95%% of synthetic accounts have %d or fewer).",
                    (int) fv.txLastHour(), (int) featureP95[3][1]));
        }
        int hour = (int) fv.hourUtc();
        if (hourFrequency[Math.min(Math.max(hour, 0), 23)] < 0.01) {
            reasons.add(String.format(Locale.ROOT, "Unusual time of day (%02d:00 UTC); under 1%% of synthetic transactions occur then.", hour));
        }
        if (fv.newCounterparty() == 1 && fv.amountRatio() >= 2) {
            reasons.add("First payment to this recipient combined with an above-average amount.");
        }
        if (fv.balanceFraction() >= 0.8) {
            reasons.add(String.format(Locale.ROOT, "Uses %.0f%% of the available balance.", fv.balanceFraction() * 100));
        }
        if (reasons.isEmpty()) {
            reasons.add("The combination of features is rare in the synthetic training data, with no single dominant factor.");
        }
        return reasons;
    }

    private void requireReady() {
        if (forest == null) {
            throw new BusinessException(ErrorCode.SERVICE_UNAVAILABLE, "Anomaly detection is disabled.");
        }
    }

    static double percentile(double[] sorted, double p) {
        if (sorted.length == 0) {
            return 0;
        }
        double rank = p / 100.0 * (sorted.length - 1);
        int lo = (int) Math.floor(rank);
        int hi = (int) Math.ceil(rank);
        return sorted[lo] + (sorted[hi] - sorted[lo]) * (rank - lo);
    }

    private static double round(double v) {
        return Math.round(v * 1000.0) / 1000.0;
    }
}
