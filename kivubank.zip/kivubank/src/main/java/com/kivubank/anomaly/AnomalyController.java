package com.kivubank.anomaly;

import com.kivubank.anomaly.AnomalyService.AssessmentView;
import com.kivubank.common.PageResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Pattern;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/admin/anomalies")
@Tag(name = "Anomaly detection (experimental)",
        description = "EXPERIMENTAL Isolation Forest trained on SYNTHETIC data. Not real-world fraud detection.")
@SecurityRequirement(name = "bearerAuth")
public class AnomalyController {
    private final AnomalyService service;
    private final AnomalyModel model;

    public AnomalyController(AnomalyService service, AnomalyModel model) {
        this.service = service;
        this.model = model;
    }

    public record EvaluateRequest(
            @Schema(example = "250000") @NotNull BigDecimal amount,
            @Schema(example = "15000", description = "The account's usual outgoing amount") @NotNull BigDecimal typicalAmount,
            @Schema(example = "3") @Min(0) @Max(23) int hourUtc,
            @Schema(example = "1") @Min(0) @Max(100) int transactionsLastHour,
            @Schema(example = "TRANSFER") @NotNull @Pattern(regexp = "TRANSFER|WITHDRAWAL") String type,
            boolean newRecipient,
            @Schema(example = "0.85") @NotNull @PositiveOrZero Double balanceFraction) {
    }

    public record EvaluateResponse(double score, boolean flagged, List<String> reasons, boolean experimental, String disclaimer) {
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','AUDITOR','SUPPORT_AGENT')")
    @Operation(summary = "List anomaly assessments (experimental)", description = "Scores are produced after each successful transfer/withdrawal.")
    public PageResponse<AssessmentView> list(@RequestParam(defaultValue = "true") boolean flaggedOnly,
                                             @RequestParam(defaultValue = "0") int page,
                                             @RequestParam(defaultValue = "25") int size) {
        return service.list(flaggedOnly, page, size);
    }

    @GetMapping("/model")
    @PreAuthorize("hasAnyRole('ADMIN','AUDITOR','SUPPORT_AGENT')")
    @Operation(summary = "Model information and synthetic validation metrics")
    public AnomalyModel.Info modelInfo() {
        return model.info();
    }

    @PostMapping("/evaluate")
    @PreAuthorize("hasAnyRole('ADMIN','AUDITOR')")
    @Operation(summary = "What-if evaluation",
            description = "Scores a hypothetical transaction without storing anything. Useful to demonstrate how the explanation works.")
    public EvaluateResponse evaluate(@Valid @RequestBody EvaluateRequest r) {
        FeatureVector fv = FeatureVector.of(r.amount().doubleValue(), r.typicalAmount().doubleValue(), r.hourUtc(),
                r.transactionsLastHour(), "WITHDRAWAL".equals(r.type()), r.newRecipient(), r.balanceFraction());
        AnomalyModel.Result res = model.assess(fv);
        return new EvaluateResponse(Math.round(res.score() * 10000.0) / 10000.0, res.flagged(), res.reasons(), true,
                AnomalyModel.DISCLAIMER);
    }
}
