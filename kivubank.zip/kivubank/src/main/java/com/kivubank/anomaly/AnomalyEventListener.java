package com.kivubank.anomaly;

import com.kivubank.event.DomainEvents.TransactionOutcomeEvent;
import com.kivubank.transaction.TransactionStatus;
import com.kivubank.transaction.TransactionType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.context.event.EventListener;

@Component
public class AnomalyEventListener {
    private static final Logger log = LoggerFactory.getLogger(AnomalyEventListener.class);
    private final AnomalyService service;

    public AnomalyEventListener(AnomalyService service) {
        this.service = service;
    }

    @EventListener
    public void onOutcome(TransactionOutcomeEvent e) {
        if (e.status() != TransactionStatus.SUCCESS
                || (e.type() != TransactionType.TRANSFER && e.type() != TransactionType.WITHDRAWAL)) {
            return;
        }
        try {
            service.assessTransaction(e.transactionId());
        } catch (RuntimeException ex) {
            log.error("Anomaly assessment failed for {}", e.reference(), ex);
        }
    }
}
