package com.kivubank.anomaly;

import com.kivubank.account.Account;
import com.kivubank.audit.AuditAction;
import com.kivubank.audit.AuditOutcome;
import com.kivubank.audit.AuditService;
import com.kivubank.common.PageResponse;
import com.kivubank.transaction.Transaction;
import com.kivubank.transaction.TransactionRepository;
import com.kivubank.transaction.TransactionType;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AnomalyService {
    private final AnomalyModel model;
    private final TransactionRepository transactions;
    private final AnomalyAssessmentRepository assessments;
    private final AuditService audit;
    private final Clock clock;

    public AnomalyService(AnomalyModel model, TransactionRepository transactions, AnomalyAssessmentRepository assessments,
                          AuditService audit, Clock clock) {
        this.model = model;
        this.transactions = transactions;
        this.assessments = assessments;
        this.audit = audit;
        this.clock = clock;
    }

    public record AssessmentView(Long id, String transactionReference, double score, boolean flagged,
                                 List<String> reasons, String features, String modelVersion, Instant createdAt,
                                 boolean experimental) {
        static AssessmentView of(AnomalyAssessment a) {
            List<String> reasons = a.getReasons() == null || a.getReasons().isBlank() ? List.of()
                    : List.of(a.getReasons().split(" \\| "));
            return new AssessmentView(a.getId(), a.getTransactionReference(), a.getScore().doubleValue(), a.isFlagged(),
                    reasons, a.getFeatures(), a.getModelVersion(), a.getCreatedAt(), true);
        }
    }

    /** Scores one successful outgoing transaction. Runs in its own transaction after the payment committed. */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void assessTransaction(Long transactionId) {
        if (!model.isReady() || assessments.existsByTransactionId(transactionId)) {
            return;
        }
        Transaction t = transactions.findById(transactionId).orElse(null);
        if (t == null || t.getSourceAccount() == null
                || (t.getType() != TransactionType.TRANSFER && t.getType() != TransactionType.WITHDRAWAL)) {
            return;
        }
        FeatureVector fv = extract(t);
        AnomalyModel.Result result = model.assess(fv);
        Account source = t.getSourceAccount();
        assessments.save(new AnomalyAssessment(t.getId(), t.getReference(), source.getId(),
                BigDecimal.valueOf(result.score()).setScale(4, RoundingMode.HALF_UP), result.flagged(),
                String.join(" | ", result.reasons()), fv.compact(), AnomalyModel.VERSION, clock.instant()));
        if (result.flagged()) {
            audit.recordForUser(t.getInitiatedByUserId(), AuditAction.ANOMALY_FLAGGED, AuditOutcome.SUCCESS, "TRANSACTION",
                    t.getReference(), "experimental score=" + String.format(java.util.Locale.ROOT, "%.3f", result.score()));
        }
    }

    FeatureVector extract(Transaction t) {
        Long sourceId = t.getSourceAccount().getId();
        Instant at = t.getCreatedAt();
        Instant since = at.minus(Duration.ofDays(90));
        Double avg = transactions.averageOutgoingAmount(sourceId, since, at, t.getId());
        long history = transactions.countOutgoing(sourceId, since, at, t.getId());
        double typical = avg != null && history >= 3 ? avg : model.typicalAmount();
        long lastHour = transactions.countOutgoing(sourceId, at.minus(Duration.ofHours(1)), at, t.getId());
        boolean transfer = t.getType() == TransactionType.TRANSFER;
        boolean newCounterparty = transfer && t.getTargetAccount() != null
                && transactions.countPriorTransfers(sourceId, t.getTargetAccount().getId(), t.getId()) == 0;
        double amount = t.getAmount().doubleValue();
        double balanceBefore = t.getSourceBalanceAfter() == null ? amount : t.getSourceBalanceAfter().doubleValue() + amount;
        double fraction = balanceBefore <= 0 ? 1 : amount / balanceBefore;
        return FeatureVector.of(amount, typical, at.atZone(ZoneOffset.UTC).getHour(), (int) lastHour, !transfer,
                newCounterparty, fraction);
    }

    @Transactional(readOnly = true)
    public PageResponse<AssessmentView> list(boolean flaggedOnly, int page, int size) {
        PageRequest p = PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100), Sort.by(Sort.Direction.DESC, "createdAt"));
        var result = flaggedOnly ? assessments.findByFlagged(true, p) : assessments.findAll(p);
        return PageResponse.of(result, AssessmentView::of);
    }
}
