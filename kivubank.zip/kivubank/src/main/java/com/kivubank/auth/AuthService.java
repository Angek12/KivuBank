package com.kivubank.auth;

import com.kivubank.account.Account;
import com.kivubank.account.AccountRepository;
import com.kivubank.account.AccountService;
import com.kivubank.audit.AuditAction;
import com.kivubank.audit.AuditOutcome;
import com.kivubank.audit.AuditService;
import com.kivubank.auth.AuthDtos.ChangePasswordRequest;
import com.kivubank.auth.AuthDtos.LoginRequest;
import com.kivubank.auth.AuthDtos.LoginResponse;
import com.kivubank.auth.AuthDtos.RegisterRequest;
import com.kivubank.auth.AuthDtos.UserProfile;
import com.kivubank.common.BusinessException;
import com.kivubank.common.ClientInfo;
import com.kivubank.common.ErrorCode;
import com.kivubank.config.KivuBankProperties;
import com.kivubank.event.DomainEvents.LoginEvent;
import com.kivubank.event.DomainEvents.SecurityChangeEvent;
import com.kivubank.user.PhoneNumbers;
import com.kivubank.user.Role;
import com.kivubank.user.User;
import com.kivubank.user.UserRepository;
import com.kivubank.user.UserStatus;
import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {
    private final UserRepository users;
    private final AccountRepository accounts;
    private final AccountService accountService;
    private final PasswordEncoder encoder;
    private final JwtService jwt;
    private final RevokedTokenRepository revoked;
    private final PhoneNumbers phones;
    private final AuditService audit;
    private final ApplicationEventPublisher events;
    private final KivuBankProperties props;
    private final Clock clock;
    /** Compared against when the identifier is unknown, so response timing does not reveal which users exist. */
    private final String dummyHash;

    public AuthService(UserRepository users, AccountRepository accounts, AccountService accountService,
                       PasswordEncoder encoder, JwtService jwt, RevokedTokenRepository revoked, PhoneNumbers phones,
                       AuditService audit, ApplicationEventPublisher events, KivuBankProperties props, Clock clock) {
        this.users = users;
        this.accounts = accounts;
        this.accountService = accountService;
        this.encoder = encoder;
        this.jwt = jwt;
        this.revoked = revoked;
        this.phones = phones;
        this.audit = audit;
        this.events = events;
        this.props = props;
        this.clock = clock;
        this.dummyHash = encoder.encode("kivubank-timing-equalisation");
    }

    @Transactional
    public UserProfile register(RegisterRequest req) {
        String email = req.email().trim().toLowerCase(Locale.ROOT);
        requireStrongPassword(req.password(), email, req.fullName());
        String phone = phones.normalize(req.phone());
        if (users.existsByEmail(email) || users.existsByPhone(phone)) {
            throw new BusinessException(ErrorCode.ALREADY_EXISTS, "An account with these details already exists.");
        }
        // Role is never taken from the request: public registration always creates a CUSTOMER.
        User user = users.save(new User(req.fullName().trim(), email, phone, encoder.encode(req.password()),
                Role.CUSTOMER, clock.instant()));
        Account account = accountService.openAccount(user.getId());
        audit.recordForUser(user.getId(), AuditAction.ACCOUNT_CREATED, AuditOutcome.SUCCESS, "ACCOUNT",
                account.getAccountNumber(), null);
        return profile(user, account.getAccountNumber());
    }

    @Transactional(noRollbackFor = BusinessException.class)
    public LoginResponse login(LoginRequest req) {
        Instant now = clock.instant();
        Optional<User> found = findByIdentifier(req.identifier().trim());
        if (found.isEmpty()) {
            encoder.matches(req.password(), dummyHash);
            audit.recordAnonymous(AuditAction.LOGIN_FAILURE, AuditOutcome.FAILURE, null, "USER", null, "reason=unknown_identifier");
            throw invalidCredentials();
        }
        User user = found.get();
        if (user.getLockedUntil() != null && !user.isLocked(now)) {
            user.setLockedUntil(null);
            user.setFailedLoginAttempts(0);
        }
        if (user.isLocked(now)) {
            audit.recordAnonymous(AuditAction.LOGIN_FAILURE, AuditOutcome.FAILURE, user.getEmail(), "USER",
                    String.valueOf(user.getId()), "reason=locked");
            throw new BusinessException(ErrorCode.ACCOUNT_LOCKED, "Account is temporarily locked. Try again later.");
        }
        boolean passwordOk = encoder.matches(req.password(), user.getPasswordHash());
        if (!passwordOk || user.getStatus() != UserStatus.ACTIVE) {
            if (!passwordOk) {
                int attempts = user.getFailedLoginAttempts() + 1;
                user.setFailedLoginAttempts(attempts);
                if (attempts >= props.security().maxFailedLogins()) {
                    user.setLockedUntil(now.plus(props.security().lockDuration()));
                }
            }
            audit.recordAnonymous(AuditAction.LOGIN_FAILURE, AuditOutcome.FAILURE, user.getEmail(), "USER",
                    String.valueOf(user.getId()), passwordOk ? "reason=disabled" : "reason=bad_password");
            throw invalidCredentials();
        }
        user.setFailedLoginAttempts(0);
        user.setLockedUntil(null);
        user.setLastLoginAt(now);
        JwtService.IssuedToken token = jwt.issue(user);
        audit.recordForUser(user.getId(), AuditAction.LOGIN_SUCCESS, AuditOutcome.SUCCESS, "USER", String.valueOf(user.getId()), null);
        events.publishEvent(new LoginEvent(user.getId(), ClientInfo.currentIp()));
        String accountNumber = accounts.findByUserId(user.getId()).map(Account::getAccountNumber).orElse(null);
        return new LoginResponse(token.token(), "Bearer", token.expiresInSeconds(), profile(user, accountNumber));
    }

    @Transactional
    public void logout() {
        AuthenticatedUser me = AuthenticatedUser.current();
        String jti = AuthenticatedUser.currentJti();
        Instant exp = AuthenticatedUser.currentTokenExpiry();
        Instant now = clock.instant();
        if (jti != null && exp != null && !revoked.existsById(jti)) {
            revoked.save(new RevokedToken(jti, exp, now));
        }
        revoked.deleteExpired(now);
        audit.recordForUser(me.id(), AuditAction.LOGOUT, AuditOutcome.SUCCESS, "USER", String.valueOf(me.id()), null);
    }

    @Transactional
    public void changePassword(ChangePasswordRequest req) {
        AuthenticatedUser me = AuthenticatedUser.current();
        User user = users.findById(me.id()).orElseThrow(() -> new BusinessException(ErrorCode.NOT_FOUND, "User not found."));
        if (!encoder.matches(req.currentPassword(), user.getPasswordHash())) {
            audit.recordForUser(me.id(), AuditAction.PASSWORD_CHANGED, AuditOutcome.FAILURE, "USER", String.valueOf(me.id()), "reason=bad_current_password");
            throw new BusinessException(ErrorCode.INVALID_CREDENTIALS, "Current password is incorrect.");
        }
        requireStrongPassword(req.newPassword(), user.getEmail(), user.getFullName());
        if (encoder.matches(req.newPassword(), user.getPasswordHash())) {
            throw new BusinessException(ErrorCode.VALIDATION_FAILED, "New password must differ from the current password.");
        }
        user.setPasswordHash(encoder.encode(req.newPassword()));
        user.setPasswordChangedAt(clock.instant());
        audit.recordForUser(me.id(), AuditAction.PASSWORD_CHANGED, AuditOutcome.SUCCESS, "USER", String.valueOf(me.id()), null);
        events.publishEvent(new SecurityChangeEvent(me.id(), "PASSWORD_CHANGED"));
    }

    @Transactional(readOnly = true)
    public UserProfile me() {
        User user = users.findById(AuthenticatedUser.current().id())
                .orElseThrow(() -> new BusinessException(ErrorCode.NOT_FOUND, "User not found."));
        String accountNumber = accounts.findByUserId(user.getId()).map(Account::getAccountNumber).orElse(null);
        return profile(user, accountNumber);
    }

    private Optional<User> findByIdentifier(String identifier) {
        if (identifier.contains("@")) {
            return users.findByEmail(identifier.toLowerCase(Locale.ROOT));
        }
        return users.findByAccountNumber(identifier);
    }

    private void requireStrongPassword(String password, String email, String fullName) {
        List<String> problems = PasswordPolicy.violations(password, email, fullName);
        if (!problems.isEmpty()) {
            throw new BusinessException(ErrorCode.VALIDATION_FAILED, String.join(" ", problems));
        }
    }

    private BusinessException invalidCredentials() {
        return new BusinessException(ErrorCode.INVALID_CREDENTIALS, "Invalid credentials.");
    }

    static UserProfile profile(User u, String accountNumber) {
        return new UserProfile(u.getId(), u.getFullName(), u.getEmail(), u.getPhone(), u.getRole(), accountNumber);
    }
}
