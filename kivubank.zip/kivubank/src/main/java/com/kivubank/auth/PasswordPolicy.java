package com.kivubank.auth;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Password rules: length, character classes, no whitespace, no common passwords, no personal data. */
public final class PasswordPolicy {
    private static final Set<String> COMMON = Set.of("password", "password1", "password123", "passw0rd", "qwerty123",
            "letmein123", "welcome123", "admin12345", "iloveyou123", "changeme123");
    public static final int MIN_LENGTH = 10;
    public static final int MAX_LENGTH = 100;

    private PasswordPolicy() {
    }

    public static List<String> violations(String password, String email, String fullName) {
        List<String> out = new ArrayList<>();
        if (password == null || password.length() < MIN_LENGTH) {
            out.add("Password must be at least " + MIN_LENGTH + " characters long.");
            return out;
        }
        if (password.length() > MAX_LENGTH) {
            out.add("Password must be at most " + MAX_LENGTH + " characters long.");
        }
        if (password.chars().anyMatch(Character::isWhitespace)) {
            out.add("Password must not contain whitespace.");
        }
        if (password.chars().noneMatch(Character::isUpperCase)) {
            out.add("Password must contain an uppercase letter.");
        }
        if (password.chars().noneMatch(Character::isLowerCase)) {
            out.add("Password must contain a lowercase letter.");
        }
        if (password.chars().noneMatch(Character::isDigit)) {
            out.add("Password must contain a digit.");
        }
        if (password.chars().allMatch(Character::isLetterOrDigit)) {
            out.add("Password must contain a special character.");
        }
        String lower = password.toLowerCase(Locale.ROOT);
        if (COMMON.contains(lower)) {
            out.add("Password is too common.");
        }
        if (email != null && email.contains("@")) {
            String local = email.substring(0, email.indexOf('@')).toLowerCase(Locale.ROOT);
            if (local.length() >= 4 && lower.contains(local)) {
                out.add("Password must not contain your email name.");
            }
        }
        if (fullName != null) {
            for (String part : fullName.toLowerCase(Locale.ROOT).split("\\s+")) {
                if (part.length() >= 4 && lower.contains(part)) {
                    out.add("Password must not contain your name.");
                    break;
                }
            }
        }
        return out;
    }
}
