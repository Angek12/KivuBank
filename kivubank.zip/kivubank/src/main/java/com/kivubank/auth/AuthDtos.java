package com.kivubank.auth;

import com.kivubank.user.Role;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public final class AuthDtos {
    private AuthDtos() {
    }

    public record RegisterRequest(
            @Schema(example = "Amina Uwase") @NotBlank @Pattern(regexp = "^[\\p{L} .'-]{2,120}$", message = "Name may contain letters, spaces and . ' - only (2-120 chars)") String fullName,
            @Schema(example = "amina@example.com") @NotBlank @Email @Size(max = 190) String email,
            @Schema(example = "+14155552671", description = "International (E.164) format") @NotBlank @Size(max = 25) String phone,
            @Schema(example = "S3cure-Passw0rd!") @NotBlank @Size(max = 100) String password) {
    }

    public record LoginRequest(
            @Schema(description = "E-mail address or account number", example = "amina@example.com") @NotBlank @Size(max = 190) String identifier,
            @NotBlank @Size(max = 100) String password) {
    }

    public record ChangePasswordRequest(
            @NotBlank @Size(max = 100) String currentPassword,
            @NotBlank @Size(max = 100) String newPassword) {
    }

    public record UserProfile(Long id, String fullName, String email, String phone, Role role, String accountNumber) {
    }

    public record LoginResponse(String accessToken, String tokenType, long expiresInSeconds, UserProfile user) {
    }
}
