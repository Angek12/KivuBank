package com.kivubank.auth;

import com.kivubank.auth.AuthDtos.ChangePasswordRequest;
import com.kivubank.auth.AuthDtos.LoginRequest;
import com.kivubank.auth.AuthDtos.LoginResponse;
import com.kivubank.auth.AuthDtos.RegisterRequest;
import com.kivubank.auth.AuthDtos.UserProfile;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
@Tag(name = "Authentication", description = "Registration, login, logout and password management.")
public class AuthController {
    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    @SecurityRequirements
    @Operation(summary = "Register a customer",
            description = "Public. Creates a CUSTOMER user and a zero-balance simulated account. Rate limited.",
            responses = {@ApiResponse(responseCode = "201", description = "Registered"),
                    @ApiResponse(responseCode = "409", description = "E-mail or phone already registered")})
    public UserProfile register(@Valid @RequestBody RegisterRequest request) {
        return authService.register(request);
    }

    @PostMapping("/login")
    @SecurityRequirements
    @Operation(summary = "Log in",
            description = "Public. Identify with e-mail or account number. Returns a short-lived Bearer JWT. "
                    + "Repeated failures temporarily lock the user. Rate limited.",
            responses = {@ApiResponse(responseCode = "200", description = "Authenticated"),
                    @ApiResponse(responseCode = "401", description = "Invalid credentials"),
                    @ApiResponse(responseCode = "423", description = "Account temporarily locked")})
    public LoginResponse login(@Valid @RequestBody LoginRequest request) {
        return authService.login(request);
    }

    @PostMapping("/logout")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @SecurityRequirement(name = "bearerAuth")
    @Operation(summary = "Log out", description = "Revokes the presented token immediately.")
    public void logout() {
        authService.logout();
    }

    @GetMapping("/me")
    @SecurityRequirement(name = "bearerAuth")
    @Operation(summary = "Current user profile")
    public UserProfile me() {
        return authService.me();
    }

    @PostMapping("/change-password")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @SecurityRequirement(name = "bearerAuth")
    @Operation(summary = "Change password",
            description = "Requires the current password. All previously issued tokens become invalid; log in again.")
    public void changePassword(@Valid @RequestBody ChangePasswordRequest request) {
        authService.changePassword(request);
    }
}
