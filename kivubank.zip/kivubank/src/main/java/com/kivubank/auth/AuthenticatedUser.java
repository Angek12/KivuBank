package com.kivubank.auth;

import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import com.kivubank.user.Role;
import java.time.Instant;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

/** The authenticated principal placed in the security context by the JWT filter. */
public record AuthenticatedUser(Long id, String email, Role role) {

    public static AuthenticatedUser current() {
        var auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.getPrincipal() instanceof AuthenticatedUser user) {
            return user;
        }
        throw new BusinessException(ErrorCode.UNAUTHENTICATED, "Authentication is required.");
    }

    public static String currentJti() {
        var auth = SecurityContextHolder.getContext().getAuthentication();
        return auth instanceof KivuAuthentication k ? k.getJti() : null;
    }

    public static Instant currentTokenExpiry() {
        var auth = SecurityContextHolder.getContext().getAuthentication();
        return auth instanceof KivuAuthentication k ? k.getExpiresAt() : null;
    }

    /** Spring Security authentication carrying the user plus token metadata. */
    public static class KivuAuthentication extends AbstractAuthenticationToken {
        private final AuthenticatedUser user;
        private final String jti;
        private final Instant expiresAt;

        public KivuAuthentication(AuthenticatedUser user, String jti, Instant expiresAt) {
            super(java.util.List.of(new SimpleGrantedAuthority("ROLE_" + user.role().name())));
            this.user = user;
            this.jti = jti;
            this.expiresAt = expiresAt;
            setAuthenticated(true);
        }

        @Override
        public Object getCredentials() {
            return null;
        }

        @Override
        public Object getPrincipal() {
            return user;
        }

        public String getJti() {
            return jti;
        }

        public Instant getExpiresAt() {
            return expiresAt;
        }
    }
}
