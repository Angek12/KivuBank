package com.kivubank.auth;

import com.kivubank.config.KivuBankProperties;
import com.kivubank.user.Role;
import com.kivubank.user.User;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.Optional;
import java.util.UUID;
import javax.crypto.SecretKey;
import org.springframework.stereotype.Service;

/**
 * Issues and verifies HS512 JWTs. The signing key comes from KIVUBANK_JWT_SECRET (Base64, at least 64 bytes);
 * the application refuses to start without a strong key. Tokens carry issuer, subject, role, jti and expiry.
 */
@Service
public class JwtService {
    private final SecretKey key;
    private final String issuer;
    private final Duration ttl;
    private final Clock clock;

    public JwtService(KivuBankProperties props, Clock clock) {
        String secret = props.jwt().secret();
        if (secret == null || secret.isBlank()) {
            throw new IllegalStateException(
                    "KIVUBANK_JWT_SECRET is not set. Generate one with: openssl rand -base64 64");
        }
        byte[] bytes;
        try {
            bytes = Decoders.BASE64.decode(secret.trim());
        } catch (RuntimeException e) {
            throw new IllegalStateException("KIVUBANK_JWT_SECRET must be valid Base64.", e);
        }
        if (bytes.length < 64) {
            throw new IllegalStateException("KIVUBANK_JWT_SECRET must decode to at least 64 bytes.");
        }
        this.key = Keys.hmacShaKeyFor(bytes);
        this.issuer = props.jwt().issuer();
        this.ttl = props.jwt().accessTokenTtl();
        this.clock = clock;
    }

    public IssuedToken issue(User user) {
        Instant now = clock.instant();
        Instant exp = now.plus(ttl);
        String jti = UUID.randomUUID().toString();
        String token = Jwts.builder()
                .issuer(issuer)
                .subject(String.valueOf(user.getId()))
                .id(jti)
                .claim("role", user.getRole().name())
                .issuedAt(Date.from(now))
                .expiration(Date.from(exp))
                .signWith(key, Jwts.SIG.HS512)
                .compact();
        return new IssuedToken(token, jti, exp, ttl.toSeconds());
    }

    public Optional<TokenClaims> parse(String token) {
        try {
            Claims c = Jwts.parser().verifyWith(key).requireIssuer(issuer).build()
                    .parseSignedClaims(token).getPayload();
            return Optional.of(new TokenClaims(Long.valueOf(c.getSubject()), c.getId(),
                    c.getIssuedAt().toInstant(), c.getExpiration().toInstant(), Role.valueOf(c.get("role", String.class))));
        } catch (JwtException | IllegalArgumentException e) {
            return Optional.empty();
        }
    }

    public record IssuedToken(String token, String jti, Instant expiresAt, long expiresInSeconds) {
    }

    public record TokenClaims(Long userId, String jti, Instant issuedAt, Instant expiresAt, Role role) {
    }
}
