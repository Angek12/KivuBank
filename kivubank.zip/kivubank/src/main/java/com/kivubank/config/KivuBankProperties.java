package com.kivubank.config;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.List;
import org.springframework.boot.context.properties.ConfigurationProperties;

/** All KivuBank configuration. Secrets come from environment variables, never from source code. */
@ConfigurationProperties(prefix = "kivubank")
public record KivuBankProperties(Jwt jwt, Transactions transactions, RateLimit rateLimit, Security security,
                                 Bootstrap bootstrap, Notifications notifications, Simulators simulators,
                                 Anomaly anomaly) {

    public record Jwt(String secret, String issuer, Duration accessTokenTtl) {
    }

    public record Transactions(String currency, BigDecimal maxAmount, BigDecimal reviewThreshold) {
    }

    public record RateLimit(boolean enabled, int loginPerMinute, int registerPerMinute, int financialPerMinute,
                            int pinPerMinute, int ussdPerMinute) {
    }

    public record Security(int maxFailedLogins, Duration lockDuration, int maxPinAttempts, Duration pinLockDuration,
                           int bcryptStrength, List<String> allowedOrigins) {
    }

    public record Bootstrap(String adminEmail, String adminPassword, String adminName, String adminPhone) {
    }

    public record Notifications(String provider) {
    }

    public record Simulators(boolean ussdEnabled) {
    }

    public record Anomaly(boolean enabled, int trainingSamples, int trees, int subSampleSize, long seed,
                          double thresholdPercentile) {
    }
}
