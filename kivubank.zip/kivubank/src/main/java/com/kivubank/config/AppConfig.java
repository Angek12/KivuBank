package com.kivubank.config;

import java.time.Clock;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;

/** Async is used only for fire-and-forget notifications that must not hold the request's database connection. */
@Configuration
@EnableAsync
public class AppConfig {
    @Bean
    public Clock clock() {
        return Clock.systemUTC();
    }
}
