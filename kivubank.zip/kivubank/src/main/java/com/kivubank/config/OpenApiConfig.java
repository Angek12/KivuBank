package com.kivubank.config;

import com.kivubank.common.ApiError;
import io.swagger.v3.core.converter.ModelConverters;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.media.Content;
import io.swagger.v3.oas.models.media.MediaType;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.responses.ApiResponse;
import io.swagger.v3.oas.models.responses.ApiResponses;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springdoc.core.customizers.OperationCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** OpenAPI metadata, the Bearer-JWT scheme and the standard error responses added to every operation. */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI kivuBankOpenApi() {
        Components components = new Components().addSecuritySchemes("bearerAuth",
                new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").bearerFormat("JWT")
                        .description("Obtain a token from POST /api/auth/login and send it as 'Authorization: Bearer <token>'."));
        ModelConverters.getInstance().readAll(ApiError.class).forEach(components::addSchemas);
        return new OpenAPI()
                .info(new Info().title("KivuBank API").version("0.1.0")
                        .description("KivuBank is a SIMULATED digital banking platform for learning and portfolio purposes. "
                                + "No real money, customers or banks are involved. Derived from the MIT-licensed BankingPortal-API "
                                + "by Abhishek Tiwari. Experimental components (anomaly detection, reconciliation, USSD) are labelled as such.")
                        .license(new License().name("MIT").url("https://opensource.org/licenses/MIT"))
                        .contact(new Contact().name("KivuBank project")))
                .components(components)
                .addSecurityItem(new SecurityRequirement().addList("bearerAuth"));
    }

    @Bean
    public OperationCustomizer standardErrorResponses() {
        return (operation, handlerMethod) -> {
            ApiResponses responses = operation.getResponses();
            if (responses == null) {
                return operation;
            }
            add(responses, "400", "Validation failed or malformed request");
            add(responses, "401", "Missing, invalid, expired or revoked token");
            add(responses, "403", "Authenticated but not permitted (role or PIN)");
            add(responses, "429", "Rate limit exceeded");
            add(responses, "500", "Unexpected error (no internal details are returned)");
            return operation;
        };
    }

    private static void add(ApiResponses responses, String code, String description) {
        if (responses.containsKey(code)) {
            return;
        }
        Schema<?> ref = new Schema<>().$ref("#/components/schemas/ApiError");
        responses.addApiResponse(code, new ApiResponse().description(description)
                .content(new Content().addMediaType("application/json", new MediaType().schema(ref))));
    }
}
