package com.kivubank.anomaly;

import static org.assertj.core.api.Assertions.assertThat;

import com.kivubank.config.KivuBankProperties;
import java.time.Clock;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class AnomalyModelTest {
    private static AnomalyModel model;

    @BeforeAll
    static void train() {
        KivuBankProperties props = new KivuBankProperties(null, null, null, null, null, null, null,
                new KivuBankProperties.Anomaly(true, 3000, 100, 256, 42L, 97.5));
        model = new AnomalyModel(props, Clock.systemUTC());
        model.train();
    }

    @Test
    void isLabelledExperimentalAndSynthetic() {
        AnomalyModel.Info info = model.info();
        assertThat(info.experimental()).isTrue();
        assertThat(info.trainedOn()).contains("synthetic");
        assertThat(info.disclaimer()).containsIgnoringCase("synthetic");
    }

    @Test
    void obviousOutlierIsFlaggedWithReasons() {
        FeatureVector outlier = FeatureVector.of(450_000, 15_000, 3, 12, false, true, 0.97);
        AnomalyModel.Result r = model.assess(outlier);
        assertThat(r.flagged()).isTrue();
        assertThat(r.reasons()).isNotEmpty();
        assertThat(r.score()).isGreaterThan(0.5).isLessThanOrEqualTo(1.0);
    }

    @Test
    void ordinaryTransactionIsNotFlagged() {
        FeatureVector normal = FeatureVector.of(14_000, 13_000, 14, 0, false, false, 0.05);
        AnomalyModel.Result r = model.assess(normal);
        assertThat(r.flagged()).isFalse();
        assertThat(r.reasons()).isEmpty();
    }

    @Test
    void outlierScoresHigherThanNormal() {
        double normal = model.assess(FeatureVector.of(14_000, 13_000, 14, 0, false, false, 0.05)).score();
        double outlier = model.assess(FeatureVector.of(450_000, 15_000, 3, 12, false, true, 0.97)).score();
        assertThat(outlier).isGreaterThan(normal);
    }

    @Test
    void syntheticValidationIsBetterThanChance() {
        AnomalyModel.Validation v = model.info().validation();
        assertThat(v.recall()).isGreaterThan(0.5);
        assertThat(v.precision()).isGreaterThan(0.5);
    }
}
