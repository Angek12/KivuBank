package com.kivubank.anomaly;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.Random;
import org.junit.jupiter.api.Test;

class IsolationForestTest {

    @Test
    void isolatesFarPointsFasterThanClusterPoints() {
        Random rnd = new Random(7);
        double[][] data = new double[500][2];
        for (double[] row : data) {
            row[0] = rnd.nextGaussian();
            row[1] = rnd.nextGaussian();
        }
        IsolationForest forest = new IsolationForest(100, 256, 1L);
        forest.fit(data);
        double inlier = forest.score(new double[]{0.0, 0.0});
        double outlier = forest.score(new double[]{8.0, 8.0});
        assertThat(outlier).isGreaterThan(inlier);
        assertThat(outlier).isGreaterThan(0.6);
        assertThat(inlier).isLessThan(0.55);
    }

    @Test
    void sameSeedGivesSameScores() {
        double[][] data = new double[200][1];
        Random rnd = new Random(3);
        for (double[] row : data) row[0] = rnd.nextDouble();
        IsolationForest a = new IsolationForest(50, 128, 9L);
        IsolationForest b = new IsolationForest(50, 128, 9L);
        a.fit(data);
        b.fit(data);
        assertThat(a.score(new double[]{0.5})).isEqualTo(b.score(new double[]{0.5}));
    }

    @Test
    void requiresTrainingData() {
        IsolationForest forest = new IsolationForest(10, 32, 1L);
        assertThatThrownBy(() -> forest.score(new double[]{1})).isInstanceOf(IllegalStateException.class);
        assertThatThrownBy(() -> forest.fit(new double[][]{{1}})).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void averagePathLengthMatchesKnownValues() {
        assertThat(IsolationForest.averagePathLength(1)).isEqualTo(0.0);
        assertThat(IsolationForest.averagePathLength(2)).isEqualTo(1.0);
        assertThat(IsolationForest.averagePathLength(256)).isBetween(10.0, 11.0);
    }
}
