package com.kivubank.transaction;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class StatementEscapeTest {
    @Test
    void neutralisesSpreadsheetFormulas() {
        assertThat(StatementService.escape("=HYPERLINK(\"http://x\")")).startsWith("\"'=");
        assertThat(StatementService.escape("+1+1")).startsWith("\"'+");
        assertThat(StatementService.escape("@cmd")).startsWith("\"'@");
    }

    @Test
    void quotesPlainTextAndEscapesQuotes() {
        assertThat(StatementService.escape("Rent, July")).isEqualTo("\"Rent, July\"");
        assertThat(StatementService.escape("say \"hi\"")).isEqualTo("\"say \"\"hi\"\"\"");
        assertThat(StatementService.escape(null)).isEmpty();
    }
}
