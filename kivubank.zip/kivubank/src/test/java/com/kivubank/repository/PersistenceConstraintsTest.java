package com.kivubank.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.kivubank.account.Account;
import com.kivubank.account.AccountRepository;
import com.kivubank.transaction.Channel;
import com.kivubank.transaction.IdempotencyRecord;
import com.kivubank.transaction.IdempotencyRecordRepository;
import com.kivubank.transaction.Transaction;
import com.kivubank.transaction.TransactionFilter;
import com.kivubank.transaction.TransactionRepository;
import com.kivubank.transaction.TransactionSpecs;
import com.kivubank.transaction.TransactionStatus;
import com.kivubank.transaction.TransactionType;
import com.kivubank.user.Role;
import com.kivubank.user.User;
import com.kivubank.user.UserRepository;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.context.ActiveProfiles;

/** Verifies that integrity is enforced by the database (Flyway schema), not just by application code. */
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
class PersistenceConstraintsTest {
    @Autowired UserRepository users;
    @Autowired AccountRepository accounts;
    @Autowired TransactionRepository transactions;
    @Autowired IdempotencyRecordRepository idempotency;

    private User user() {
        String id = UUID.randomUUID().toString().substring(0, 8);
        return users.saveAndFlush(new User("Repo Tester", id + "@example.com", "+1" + (4150000000L + Math.abs(id.hashCode() % 9999999)), "hash", Role.CUSTOMER, Instant.now()));
    }

    private Account account() {
        User u = user();
        return accounts.saveAndFlush(new Account("10" + String.format("%08d", Math.abs(u.getId().intValue() * 7919 % 100000000)), u.getId(), "RWF", Instant.now()));
    }

    @Test
    void negativeBalanceIsRejectedByTheDatabase() {
        Account a = account();
        a.credit(new BigDecimal("-1.00"), Instant.now());
        assertThatThrownBy(() -> accounts.saveAndFlush(a)).isInstanceOf(DataIntegrityViolationException.class);
    }

    @Test
    void duplicateEmailAndAccountNumberAreRejected() {
        User u = user();
        assertThatThrownBy(() -> users.saveAndFlush(new User("Other", u.getEmail(), "+14150000001", "h", Role.CUSTOMER, Instant.now())))
                .isInstanceOf(DataIntegrityViolationException.class);
    }

    @Test
    void transactionReferenceIsUnique() {
        Account a = account();
        String ref = "KB20260101-" + UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase();
        transactions.saveAndFlush(new Transaction(ref, TransactionType.DEPOSIT, new BigDecimal("10.00"), "RWF", null, a, null, Channel.WEB, 1L, null, Instant.now()));
        assertThatThrownBy(() -> transactions.saveAndFlush(new Transaction(ref, TransactionType.DEPOSIT, new BigDecimal("5.00"), "RWF", null, a, null, Channel.WEB, 1L, null, Instant.now())))
                .isInstanceOf(DataIntegrityViolationException.class);
    }

    @Test
    void zeroAmountIsRejectedByTheDatabase() {
        Account a = account();
        assertThatThrownBy(() -> transactions.saveAndFlush(new Transaction("KB20260101-ZERO000000", TransactionType.DEPOSIT, BigDecimal.ZERO.setScale(2), "RWF", null, a, null, Channel.WEB, 1L, null, Instant.now())))
                .isInstanceOf(DataIntegrityViolationException.class);
    }

    @Test
    void idempotencyKeyIsUniquePerUser() {
        User u1 = user();
        User u2 = user();
        idempotency.saveAndFlush(new IdempotencyRecord(u1.getId(), "key-12345678", "DEPOSIT", "hash", Instant.now()));
        idempotency.saveAndFlush(new IdempotencyRecord(u2.getId(), "key-12345678", "DEPOSIT", "hash", Instant.now()));
        assertThatThrownBy(() -> idempotency.saveAndFlush(new IdempotencyRecord(u1.getId(), "key-12345678", "TRANSFER", "other", Instant.now())))
                .isInstanceOf(DataIntegrityViolationException.class);
    }

    @Test
    void specificationsFilterByAccountStatusAndAmount() {
        Account a = account();
        Account b = account();
        Instant now = Instant.now();
        Transaction t1 = new Transaction("KB20260101-SPEC000001", TransactionType.TRANSFER, new BigDecimal("50.00"), "RWF", a, b, null, Channel.WEB, 1L, null, now);
        Transaction t2 = new Transaction("KB20260101-SPEC000002", TransactionType.DEPOSIT, new BigDecimal("500.00"), "RWF", null, a, null, Channel.WEB, 1L, null, now);
        transactions.saveAndFlush(t1);
        transactions.saveAndFlush(t2);
        t1.transitionTo(TransactionStatus.PROCESSING, now);
        t1.transitionTo(TransactionStatus.SUCCESS, now);
        transactions.saveAndFlush(t1);

        List<Transaction> involvingA = transactions.findAll(TransactionSpecs.involving(a.getId()));
        List<Transaction> involvingB = transactions.findAll(TransactionSpecs.involving(b.getId()));
        assertThat(involvingA).extracting(Transaction::getReference).containsExactlyInAnyOrder("KB20260101-SPEC000001", "KB20260101-SPEC000002");
        assertThat(involvingB).extracting(Transaction::getReference).containsExactly("KB20260101-SPEC000001");

        TransactionFilter success = new TransactionFilter(TransactionStatus.SUCCESS, null, null, null, null, null, null);
        assertThat(transactions.findAll(TransactionSpecs.involving(a.getId()).and(TransactionSpecs.matching(success))))
                .extracting(Transaction::getReference).containsExactly("KB20260101-SPEC000001");
        TransactionFilter big = new TransactionFilter(null, null, null, null, new BigDecimal("100"), null, null);
        assertThat(transactions.findAll(TransactionSpecs.involving(a.getId()).and(TransactionSpecs.matching(big))))
                .extracting(Transaction::getReference).containsExactly("KB20260101-SPEC000002");
    }
}
