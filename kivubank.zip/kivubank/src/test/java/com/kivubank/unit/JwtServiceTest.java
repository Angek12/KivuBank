package com.kivubank.unit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.kivubank.auth.JwtService;
import com.kivubank.config.KivuBankProperties;
import com.kivubank.user.Role;
import com.kivubank.user.User;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

class JwtServiceTest {
    private static final String SECRET = Base64.getEncoder().encodeToString(new byte[64]).replace("AAAA", "QUJD");

    private static KivuBankProperties props(String secret, Duration ttl) {
        return new KivuBankProperties(new KivuBankProperties.Jwt(secret, "kivubank", ttl), null, null, null, null, null, null, null);
    }

    private static User user(Role role) {
        User u = new User("Jwt Tester", "jwt@example.com", "+14155550000", "hash", role, Instant.now());
        ReflectionTestUtils.setField(u, "id", 42L);
        return u;
    }

    @Test
    void issuesAndParsesToken() {
        JwtService svc = new JwtService(props(SECRET, Duration.ofMinutes(5)), Clock.systemUTC());
        JwtService.IssuedToken issued = svc.issue(user(Role.ADMIN));
        var claims = svc.parse(issued.token());
        assertThat(claims).isPresent();
        assertThat(claims.get().userId()).isEqualTo(42L);
        assertThat(claims.get().role()).isEqualTo(Role.ADMIN);
        assertThat(claims.get().jti()).isEqualTo(issued.jti());
    }

    @Test
    void rejectsTamperedAndExpiredAndGarbageTokens() {
        JwtService svc = new JwtService(props(SECRET, Duration.ofMinutes(5)), Clock.systemUTC());
        String token = svc.issue(user(Role.CUSTOMER)).token();
        String tampered = token.substring(0, token.length() - 3) + (token.endsWith("AAA") ? "BBB" : "AAA");
        assertThat(svc.parse(tampered)).isEmpty();
        assertThat(svc.parse("not-a-jwt")).isEmpty();
        JwtService expiring = new JwtService(props(SECRET, Duration.ofSeconds(-5)), Clock.systemUTC());
        assertThat(expiring.parse(expiring.issue(user(Role.CUSTOMER)).token())).isEmpty();
    }

    @Test
    void tokenSignedWithAnotherKeyIsRejected() {
        String otherSecret = Base64.getEncoder().encodeToString("another-secret-another-secret-another-secret-another-secret-123456".getBytes());
        JwtService a = new JwtService(props(SECRET, Duration.ofMinutes(5)), Clock.systemUTC());
        JwtService b = new JwtService(props(otherSecret, Duration.ofMinutes(5)), Clock.systemUTC());
        assertThat(b.parse(a.issue(user(Role.ADMIN)).token())).isEmpty();
    }

    @Test
    void refusesToStartWithMissingOrWeakSecret() {
        assertThatThrownBy(() -> new JwtService(props("", Duration.ofMinutes(5)), Clock.systemUTC())).isInstanceOf(IllegalStateException.class);
        assertThatThrownBy(() -> new JwtService(props(Base64.getEncoder().encodeToString("short".getBytes()), Duration.ofMinutes(5)), Clock.systemUTC()))
                .isInstanceOf(IllegalStateException.class);
        assertThatThrownBy(() -> new JwtService(props("%%%not base64%%%", Duration.ofMinutes(5)), Clock.systemUTC()))
                .isInstanceOf(IllegalStateException.class);
    }
}
