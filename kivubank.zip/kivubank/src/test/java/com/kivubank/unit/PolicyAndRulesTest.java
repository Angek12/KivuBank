package com.kivubank.unit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.kivubank.account.Account;
import com.kivubank.account.PinPolicy;
import com.kivubank.auth.PasswordPolicy;
import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import com.kivubank.transaction.TransactionRules;
import java.math.BigDecimal;
import java.time.Instant;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class PolicyAndRulesTest {
    private static final BigDecimal MAX = new BigDecimal("5000000");

    @Test
    void strongPasswordPasses() {
        assertThat(PasswordPolicy.violations("Gr3at-Passphrase!", "amina@example.com", "Amina Uwase")).isEmpty();
    }

    @ParameterizedTest
    @ValueSource(strings = {"short1!A", "alllowercase123!", "ALLUPPERCASE123!", "NoDigitsHere!!!", "NoSymbolsHere123", "Has Space 123!Aa"})
    void weakPasswordsAreRejected(String pw) {
        assertThat(PasswordPolicy.violations(pw, "someone@example.com", "Some One")).isNotEmpty();
    }

    @Test
    void passwordMustNotContainEmailNameOrPersonName() {
        assertThat(PasswordPolicy.violations("Amina-2026-Secure!", "amina@example.com", "X Y")).isNotEmpty();
        assertThat(PasswordPolicy.violations("Zz-Uwase-2026-Aa!", "q@example.com", "Amina Uwase")).isNotEmpty();
    }

    @ParameterizedTest
    @ValueSource(strings = {"0000", "1111", "1234", "4321", "123456", "98765", "abcd", "12", "1234567"})
    void weakOrMalformedPinsAreRejected(String pin) {
        assertThat(PinPolicy.violation(pin)).isNotNull();
    }

    @ParameterizedTest
    @ValueSource(strings = {"4829", "7391", "135790", "5602"})
    void acceptablePins(String pin) {
        assertThat(PinPolicy.violation(pin)).isNull();
    }

    @Test
    void amountRulesNormaliseAndReject() {
        assertThat(TransactionRules.validateAmount(new BigDecimal("100"), MAX)).isEqualByComparingTo("100.00");
        assertThat(TransactionRules.validateAmount(new BigDecimal("0.01"), MAX).scale()).isEqualTo(2);
        for (String bad : new String[]{"0", "-5", "0.001", "10.123"}) {
            assertThatThrownBy(() -> TransactionRules.validateAmount(new BigDecimal(bad), MAX))
                    .isInstanceOf(BusinessException.class)
                    .extracting(e -> ((BusinessException) e).getCode()).isEqualTo(ErrorCode.INVALID_AMOUNT);
        }
        assertThatThrownBy(() -> TransactionRules.validateAmount(new BigDecimal("5000000.01"), MAX)).isInstanceOf(BusinessException.class);
        assertThatThrownBy(() -> TransactionRules.validateAmount(null, MAX)).isInstanceOf(BusinessException.class);
    }

    @Test
    void accountDebitNeverGoesNegative() {
        Account a = new Account("1000000003", 3L, "RWF", Instant.now());
        a.credit(new BigDecimal("50.00"), Instant.now());
        a.debit(new BigDecimal("50.00"), Instant.now());
        assertThat(a.getBalance()).isEqualByComparingTo("0.00");
        assertThatThrownBy(() -> a.debit(new BigDecimal("0.01"), Instant.now()))
                .isInstanceOf(BusinessException.class)
                .extracting(e -> ((BusinessException) e).getCode()).isEqualTo(ErrorCode.INSUFFICIENT_FUNDS);
    }
}
