package com.kivubank.unit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.kivubank.account.Account;
import com.kivubank.common.BusinessException;
import com.kivubank.common.ErrorCode;
import com.kivubank.transaction.Channel;
import com.kivubank.transaction.Transaction;
import com.kivubank.transaction.TransactionStatus;
import com.kivubank.transaction.TransactionType;
import java.math.BigDecimal;
import java.time.Instant;
import org.junit.jupiter.api.Test;

class TransactionStatusTest {

    @Test
    void happyPathIsPendingProcessingSuccessReversed() {
        assertThat(TransactionStatus.PENDING.canTransitionTo(TransactionStatus.PROCESSING)).isTrue();
        assertThat(TransactionStatus.PROCESSING.canTransitionTo(TransactionStatus.SUCCESS)).isTrue();
        assertThat(TransactionStatus.SUCCESS.canTransitionTo(TransactionStatus.REVERSED)).isTrue();
    }

    @Test
    void pendingCanBeCancelledButNotCompletedDirectly() {
        assertThat(TransactionStatus.PENDING.canTransitionTo(TransactionStatus.CANCELLED)).isTrue();
        assertThat(TransactionStatus.PENDING.canTransitionTo(TransactionStatus.SUCCESS)).isFalse();
        assertThat(TransactionStatus.PENDING.canTransitionTo(TransactionStatus.FAILED)).isFalse();
    }

    @Test
    void terminalStatesHaveNoExits() {
        for (TransactionStatus terminal : new TransactionStatus[]{TransactionStatus.FAILED, TransactionStatus.REVERSED, TransactionStatus.CANCELLED}) {
            assertThat(terminal.isTerminal()).isTrue();
            for (TransactionStatus next : TransactionStatus.values()) {
                assertThat(terminal.canTransitionTo(next)).as(terminal + " -> " + next).isFalse();
            }
        }
        assertThat(TransactionStatus.SUCCESS.isTerminal()).isFalse();
    }

    @Test
    void entityRejectsIllegalTransitions() {
        Transaction t = new Transaction("KB20260101-AAAAAAAAAA", TransactionType.DEPOSIT, new BigDecimal("10.00"), "RWF",
                null, new Account("1000000001", 1L, "RWF", Instant.now()), null, Channel.WEB, 1L, null, Instant.now());
        assertThatThrownBy(() -> t.transitionTo(TransactionStatus.SUCCESS, Instant.now()))
                .isInstanceOf(BusinessException.class)
                .extracting(e -> ((BusinessException) e).getCode()).isEqualTo(ErrorCode.INVALID_STATE_TRANSITION);
        t.transitionTo(TransactionStatus.PROCESSING, Instant.now());
        t.transitionTo(TransactionStatus.SUCCESS, Instant.now());
        assertThat(t.getCompletedAt()).isNotNull();
        assertThatThrownBy(() -> t.transitionTo(TransactionStatus.FAILED, Instant.now())).isInstanceOf(BusinessException.class);
    }

    @Test
    void failRecordsReason() {
        Transaction t = new Transaction("KB20260101-BBBBBBBBBB", TransactionType.WITHDRAWAL, new BigDecimal("10.00"), "RWF",
                new Account("1000000002", 2L, "RWF", Instant.now()), null, null, Channel.WEB, 2L, null, Instant.now());
        t.transitionTo(TransactionStatus.PROCESSING, Instant.now());
        t.fail("INSUFFICIENT_FUNDS", Instant.now());
        assertThat(t.getStatus()).isEqualTo(TransactionStatus.FAILED);
        assertThat(t.getFailureReason()).isEqualTo("INSUFFICIENT_FUNDS");
    }
}
