package com.kivubank.integration;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.JsonNode;
import com.kivubank.support.IntegrationTestBase;
import java.util.Map;
import org.junit.jupiter.api.Test;

class UssdIntegrationTest extends IntegrationTestBase {

    private JsonNode dial(String session, String phone, String text) throws Exception {
        var r = postJson("/api/ussd/session", null, Map.of("sessionId", session, "serviceCode", "*123#", "phoneNumber", phone, "text", text));
        assertThat(r.getResponse().getStatus()).isEqualTo(200);
        return body(r);
    }

    @Test
    void mainMenuListsTheFourOptionsAndIsLabelledSimulator() throws Exception {
        Customer c = newCustomer();
        JsonNode r = dial("s-menu-1", c.phone(), "");
        assertThat(r.get("sessionEnded").asBoolean()).isFalse();
        assertThat(r.get("simulator").asBoolean()).isTrue();
        assertThat(r.get("message").asText()).contains("1. Check Balance", "2. Transfer Money", "3. Mini Statement", "4. Exit", "SIMULATOR");
        assertThat(r.get("display").asText()).startsWith("CON ");
    }

    @Test
    void balanceRequiresPinAndShowsBalance() throws Exception {
        Customer c = fundedCustomer("1234.50");
        assertThat(dial("s-bal-1", c.phone(), "1").get("message").asText()).contains("PIN");
        JsonNode ok = dial("s-bal-1", c.phone(), "1*" + c.pin());
        assertThat(ok.get("sessionEnded").asBoolean()).isTrue();
        assertThat(ok.get("message").asText()).contains("1234.50");
        JsonNode bad = dial("s-bal-2", c.phone(), "1*1357");
        assertThat(bad.get("sessionEnded").asBoolean()).isTrue();
        assertThat(bad.get("message").asText()).containsIgnoringCase("incorrect pin");
        assertThat(bad.get("message").asText()).doesNotContain("1234.50");
    }

    @Test
    void transferFlowMovesMoneyThroughTheSameServicesAndIsIdempotent() throws Exception {
        Customer a = fundedCustomer("1000.00");
        Customer b = newCustomer();
        String base = "2*" + b.accountNumber() + "*250*" + a.pin();
        assertThat(dial("s-tr-1", a.phone(), "2").get("message").asText()).contains("recipient account");
        assertThat(dial("s-tr-1", a.phone(), "2*" + b.accountNumber()).get("message").asText()).contains("amount");
        assertThat(dial("s-tr-1", a.phone(), "2*" + b.accountNumber() + "*250").get("message").asText()).contains("PIN");
        assertThat(dial("s-tr-1", a.phone(), base).get("message").asText()).contains("Confirm", "250");
        JsonNode done = dial("s-tr-1", a.phone(), base + "*1");
        assertThat(done.get("message").asText()).contains("Transfer successful");
        assertThat(balanceOf(a)).isEqualByComparingTo("750.00");
        assertThat(balanceOf(b)).isEqualByComparingTo("250.00");

        // the aggregator retries the same final hop: no second debit
        assertThat(dial("s-tr-1", a.phone(), base + "*1").get("message").asText()).contains("Transfer successful");
        assertThat(balanceOf(a)).isEqualByComparingTo("750.00");

        var history = body(getJson("/api/transactions?type=TRANSFER", a.token())).get("content");
        assertThat(history).hasSize(1);
        assertThat(history.get(0).get("channel").asText()).isEqualTo("USSD");
    }

    @Test
    void cancellingAndBadInputDoNotMoveMoney() throws Exception {
        Customer a = fundedCustomer("500.00");
        Customer b = newCustomer();
        assertThat(dial("s-c-1", a.phone(), "2*" + b.accountNumber() + "*100*" + a.pin() + "*2").get("message").asText()).contains("cancelled");
        assertThat(dial("s-c-2", a.phone(), "2*" + b.accountNumber() + "*abc").get("message").asText()).containsIgnoringCase("invalid amount");
        assertThat(dial("s-c-3", a.phone(), "2*9999999999").get("message").asText()).containsIgnoringCase("not found");
        assertThat(dial("s-c-4", a.phone(), "9").get("message").asText()).containsIgnoringCase("invalid choice");
        assertThat(balanceOf(a)).isEqualByComparingTo("500.00");
    }

    @Test
    void insufficientFundsIsReportedAndPinLockoutAppliesToUssdToo() throws Exception {
        Customer a = fundedCustomer("10.00");
        Customer b = newCustomer();
        JsonNode r = dial("s-f-1", a.phone(), "2*" + b.accountNumber() + "*500*" + a.pin() + "*1");
        assertThat(r.get("message").asText()).containsIgnoringCase("failed");
        for (int i = 0; i < 3; i++) {
            dial("s-lock-" + i, a.phone(), "1*1357");
        }
        JsonNode locked = dial("s-lock-9", a.phone(), "1*" + a.pin());
        assertThat(locked.get("message").asText()).containsIgnoringCase("locked");
    }

    @Test
    void miniStatementListsRecentTransactions() throws Exception {
        Customer c = fundedCustomer("100.00");
        money("withdraw", c, java.util.UUID.randomUUID().toString(), Map.of("amount", "30.00", "pin", c.pin()));
        JsonNode r = dial("s-ms-1", c.phone(), "3*" + c.pin());
        assertThat(r.get("message").asText()).contains("Mini statement", "+100.00", "-30.00");
    }

    @Test
    void unknownNumberWrongCodeAndExitAreHandled() throws Exception {
        Customer c = newCustomer();
        assertThat(dial("s-u-1", "+14155559999", "").get("message").asText()).containsIgnoringCase("not registered");
        var wrongCode = postJson("/api/ussd/session", null, Map.of("sessionId", "s-u-2", "serviceCode", "*999#", "phoneNumber", c.phone(), "text", ""));
        assertThat(body(wrongCode).get("message").asText()).containsIgnoringCase("invalid ussd code");
        JsonNode exit = dial("s-u-3", c.phone(), "4");
        assertThat(exit.get("sessionEnded").asBoolean()).isTrue();
        assertThat(exit.get("display").asText()).startsWith("END ");
    }

    @Test
    void ussdInputIsValidated() throws Exception {
        var r = postJson("/api/ussd/session", null, Map.of("sessionId", "bad id!", "serviceCode", "*123#", "phoneNumber", "+14155552671", "text", ""));
        assertThat(r.getResponse().getStatus()).isEqualTo(400);
    }
}
