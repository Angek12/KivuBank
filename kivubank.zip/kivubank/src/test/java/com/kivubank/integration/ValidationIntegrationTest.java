package com.kivubank.integration;

import static org.assertj.core.api.Assertions.assertThat;

import com.kivubank.support.IntegrationTestBase;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MvcResult;

class ValidationIntegrationTest extends IntegrationTestBase {

    private void expect400(MvcResult r, String field) throws Exception {
        assertThat(r.getResponse().getStatus()).isEqualTo(400);
        assertThat(errorCode(r)).isEqualTo("VALIDATION_FAILED");
        if (field != null) {
            assertThat(body(r).get("violations").toString()).contains(field);
        }
    }

    @Test
    void moneyRequestsAreValidated() throws Exception {
        Customer c = newCustomer();
        expect400(money("deposit", c, UUID.randomUUID().toString(), Map.of("pin", c.pin())), "amount");
        expect400(money("deposit", c, UUID.randomUUID().toString(), Map.of("amount", "10")), "pin");
        expect400(money("deposit", c, UUID.randomUUID().toString(), Map.of("amount", "10", "pin", "12ab")), "pin");
        expect400(money("transfer", c, UUID.randomUUID().toString(), Map.of("amount", "10", "pin", c.pin(), "targetAccountNumber", "abc")), "targetAccountNumber");
        expect400(money("transfer", c, UUID.randomUUID().toString(), Map.of("amount", "10", "pin", c.pin())), "targetAccountNumber");
        Map<String, Object> longDesc = new HashMap<>(Map.of("amount", "10", "pin", c.pin()));
        longDesc.put("description", "x".repeat(201));
        expect400(money("deposit", c, UUID.randomUUID().toString(), longDesc), "description");
        assertThat(balanceOf(c)).isEqualByComparingTo("0.00");
    }

    @Test
    void malformedJsonAndWrongTypesAreRejectedSafely() throws Exception {
        Customer c = newCustomer();
        MvcResult r = call(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post("/api/transactions/deposit")
                .header("Authorization", "Bearer " + c.token()).header("Idempotency-Key", UUID.randomUUID().toString())
                .contentType("application/json").content("{\"amount\": \"ten\", \"pin\": \"4829\"}"));
        assertThat(r.getResponse().getStatus()).isEqualTo(400);
        assertThat(r.getResponse().getContentAsString()).doesNotContain("NumberFormatException").doesNotContain("com.kivubank");
    }

    @Test
    void pathAndQueryParametersAreValidated() throws Exception {
        Customer c = newCustomer();
        assertThat(getJson("/api/transactions/not%20a%20reference!", c.token()).getResponse().getStatus()).isEqualTo(400);
        assertThat(getJson("/api/accounts/lookup/abc", c.token()).getResponse().getStatus()).isEqualTo(400);
        assertThat(getJson("/api/transactions?from=yesterday", c.token()).getResponse().getStatus()).isEqualTo(400);
        assertThat(getJson("/api/transactions/KB20260101-ZZZZZZZZZZ", c.token()).getResponse().getStatus()).isEqualTo(404);
        assertThat(getJson("/api/accounts/lookup/9999999999", c.token()).getResponse().getStatus()).isEqualTo(404);
    }

    @Test
    void lookupMasksTheOwnerName() throws Exception {
        Customer c = newCustomer();
        Customer other = newCustomer();
        var r = body(getJson("/api/accounts/lookup/" + other.accountNumber(), c.token()));
        assertThat(r.get("ownerNameMasked").asText()).isEqualTo("T*** P***");
        assertThat(r.toString()).doesNotContain("Test Person");
    }

    @Test
    void statementRangeIsLimited() throws Exception {
        Customer c = newCustomer();
        assertThat(getJson("/api/accounts/me/statement?from=2020-01-01T00:00:00Z&to=2026-01-01T00:00:00Z", c.token()).getResponse().getStatus()).isEqualTo(400);
        assertThat(getJson("/api/accounts/me/statement?from=2026-02-01T00:00:00Z&to=2026-01-01T00:00:00Z", c.token()).getResponse().getStatus()).isEqualTo(400);
    }

    @Test
    void unknownRoutesAndMethodsReturnSafeErrors() throws Exception {
        String admin = adminToken();
        assertThat(getJson("/api/does-not-exist", admin).getResponse().getStatus()).isEqualTo(404);
        MvcResult wrongMethod = call(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete("/api/auth/me")
                .header("Authorization", "Bearer " + admin));
        assertThat(wrongMethod.getResponse().getStatus()).isEqualTo(405);
        assertThat(wrongMethod.getResponse().getContentAsString()).doesNotContain("Exception");
    }

    @Test
    void securityHeadersArePresent() throws Exception {
        var r = getJson("/actuator/health", null).getResponse();
        assertThat(r.getHeader("X-Content-Type-Options")).isEqualTo("nosniff");
        assertThat(r.getHeader("X-Frame-Options")).isEqualTo("DENY");
        assertThat(r.getHeader("X-Request-Id")).isNotBlank();
    }
}
