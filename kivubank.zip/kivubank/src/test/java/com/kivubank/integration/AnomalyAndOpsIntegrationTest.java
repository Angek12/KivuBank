package com.kivubank.integration;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.JsonNode;
import com.kivubank.support.IntegrationTestBase;
import java.util.Map;
import org.junit.jupiter.api.Test;

class AnomalyAndOpsIntegrationTest extends IntegrationTestBase {

    @Test
    void everySuccessfulTransferIsScoredAndLabelledExperimental() throws Exception {
        String admin = adminToken();
        Customer a = fundedCustomer("5000.00");
        Customer b = newCustomer();
        String ref = body(transfer(a, b, "100.00")).get("reference").asText();
        JsonNode page = body(getJson("/api/admin/anomalies?flaggedOnly=false&size=100", admin));
        JsonNode mine = null;
        for (JsonNode n : page.get("content")) {
            if (ref.equals(n.get("transactionReference").asText())) mine = n;
        }
        assertThat(mine).as("assessment for " + ref).isNotNull();
        assertThat(mine.get("experimental").asBoolean()).isTrue();
        assertThat(mine.get("score").asDouble()).isBetween(0.0, 1.0);
        assertThat(mine.get("modelVersion").asText()).contains("synthetic");
    }

    @Test
    void failedTransfersAreNotScored() throws Exception {
        String admin = adminToken();
        Customer a = fundedCustomer("5.00");
        Customer b = newCustomer();
        String ref = body(transfer(a, b, "100.00")).get("reference").asText();
        String all = getJson("/api/admin/anomalies?flaggedOnly=false&size=100", admin).getResponse().getContentAsString();
        assertThat(all).doesNotContain(ref);
    }

    @Test
    void whatIfEvaluationFlagsExtremeInputAndExplainsWhy() throws Exception {
        String admin = adminToken();
        var extreme = body(postJson("/api/admin/anomalies/evaluate", admin, Map.of("amount", 900000, "typicalAmount", 15000, "hourUtc", 3,
                "transactionsLastHour", 12, "type", "TRANSFER", "newRecipient", true, "balanceFraction", 0.98)));
        assertThat(extreme.get("flagged").asBoolean()).isTrue();
        assertThat(extreme.get("reasons")).isNotEmpty();
        assertThat(extreme.get("experimental").asBoolean()).isTrue();
        assertThat(extreme.get("disclaimer").asText()).containsIgnoringCase("synthetic");

        var normal = body(postJson("/api/admin/anomalies/evaluate", admin, Map.of("amount", 14000, "typicalAmount", 13000, "hourUtc", 14,
                "transactionsLastHour", 0, "type", "TRANSFER", "newRecipient", false, "balanceFraction", 0.05)));
        assertThat(normal.get("flagged").asBoolean()).isFalse();
        assertThat(normal.get("score").asDouble()).isLessThan(extreme.get("score").asDouble());
    }

    @Test
    void modelInfoExposesSyntheticValidationAndInputsAreValidated() throws Exception {
        String admin = adminToken();
        JsonNode info = body(getJson("/api/admin/anomalies/model", admin));
        assertThat(info.get("experimental").asBoolean()).isTrue();
        assertThat(info.get("validation").get("recall").asDouble()).isGreaterThan(0.5);
        assertThat(postJson("/api/admin/anomalies/evaluate", admin, Map.of("amount", 1, "typicalAmount", 1, "hourUtc", 30,
                "transactionsLastHour", 0, "type", "TRANSFER", "newRecipient", false, "balanceFraction", 0.1)).getResponse().getStatus()).isEqualTo(400);
        assertThat(postJson("/api/admin/anomalies/evaluate", admin, Map.of("amount", 1, "typicalAmount", 1, "hourUtc", 3,
                "transactionsLastHour", 0, "type", "PAYMENT", "newRecipient", false, "balanceFraction", 0.1)).getResponse().getStatus()).isEqualTo(400);
    }

    @Test
    void dashboardReportsTransactionsHealthAlertsAndDisclosure() throws Exception {
        String admin = adminToken();
        Customer c = fundedCustomer("100.00");
        money("withdraw", c, java.util.UUID.randomUUID().toString(), Map.of("amount", "999.00", "pin", c.pin()));   // one FAILED
        getJson("/api/accounts/me", c.token());
        JsonNode d = body(getJson("/api/ops/dashboard", admin));
        assertThat(d.get("dataDisclosure").asText()).contains("SIMULATED");
        assertThat(d.get("health").get("status").asText()).isEqualTo("UP");
        assertThat(d.get("health").get("databaseLatencyMs").asLong()).isGreaterThanOrEqualTo(0);
        boolean hasLedger = false;
        for (JsonNode comp : d.get("health").get("components")) {
            if ("ledger".equals(comp.get("name").asText())) hasLedger = comp.get("status").asText().equals("UP");
        }
        assertThat(hasLedger).isTrue();
        JsonNode tx = d.get("transactions");
        assertThat(tx.get("total").asInt()).isGreaterThanOrEqualTo(2);
        assertThat(tx.get("byStatus").get("SUCCESS").asInt()).isGreaterThanOrEqualTo(1);
        assertThat(tx.get("byStatus").get("FAILED").asInt()).isGreaterThanOrEqualTo(1);
        assertThat(tx.get("successRateAllTime").asDouble()).isBetween(0.0, 100.0);
        assertThat(d.get("http").get("totalRequests").asLong()).isGreaterThanOrEqualTo(1);
        assertThat(d.get("alerts").isArray()).isTrue();
        assertThat(d.get("recentAuditEvents")).isNotEmpty();
        assertThat(d.get("jvm").get("heapMaxMb").asLong()).isPositive();
        assertThat(d.get("users").get("activeUsersLast30Min").asLong()).isGreaterThanOrEqualTo(1);
    }

    @Test
    void trendHealthAndMetricsEndpoints() throws Exception {
        String admin = adminToken();
        JsonNode trend = body(getJson("/api/ops/transactions/trend?hours=6", admin));
        assertThat(trend.size()).isBetween(6, 8);
        assertThat(body(getJson("/api/ops/health", admin)).get("uptimeSeconds").asLong()).isGreaterThanOrEqualTo(0);
        JsonNode metrics = body(getJson("/api/ops/metrics", admin));
        assertThat(metrics.get("http").has("averageResponseMs")).isTrue();
        assertThat(metrics.get("jvm").get("liveThreads").asInt()).isPositive();
        assertThat(getJson("/actuator/health", null).getResponse().getContentAsString()).contains("UP").doesNotContain("diskSpace");
        assertThat(getJson("/actuator/prometheus", admin).getResponse().getContentAsString()).contains("kivubank_transactions");
    }

    @Test
    void openApiDocumentDescribesSecurityHeadersAndErrors() throws Exception {
        JsonNode api = body(getJson("/v3/api-docs", null));
        assertThat(api.at("/info/description").asText()).contains("SIMULATED");
        assertThat(api.at("/components/securitySchemes/bearerAuth/scheme").asText()).isEqualTo("bearer");
        JsonNode transfer = api.at("/paths/~1api~1transactions~1transfer/post");
        assertThat(transfer.at("/summary").asText()).isNotBlank();
        boolean hasIdemKey = false;
        for (JsonNode p : transfer.get("parameters")) {
            if ("Idempotency-Key".equals(p.get("name").asText())) hasIdemKey = true;
        }
        assertThat(hasIdemKey).isTrue();
        assertThat(transfer.at("/responses").has("401")).isTrue();
        assertThat(transfer.at("/responses").has("400")).isTrue();
        assertThat(api.at("/paths/~1api~1auth~1login/post/security").size()).as("login is public").isZero();
        assertThat(api.at("/paths/~1api~1ussd~1session/post").isMissingNode()).isFalse();
    }
}
