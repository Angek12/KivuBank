package com.kivubank.integration;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.JsonNode;
import com.kivubank.support.IntegrationTestBase;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MvcResult;

class IncidentIntegrationTest extends IntegrationTestBase {

    private JsonNode open(String token, String severity) throws Exception {
        MvcResult r = postJson("/api/incidents", token, Map.of("title", "Elevated errors", "description", "Seen in the simulator",
                "severity", severity, "affectedService", "TRANSACTIONS", "assignee", "Platform team"));
        assertThat(r.getResponse().getStatus()).isEqualTo(201);
        return body(r);
    }

    @Test
    void createReturnsFormattedIdAndOpenStatus() throws Exception {
        JsonNode i = open(adminToken(), "HIGH");
        assertThat(i.get("incidentId").asText()).matches("INC-\\d{5}");
        assertThat(i.get("status").asText()).isEqualTo("OPEN");
        assertThat(i.get("severity").asText()).isEqualTo("HIGH");
        assertThat(i.get("createdAt").asText()).isNotBlank();
        assertThat(i.has("resolvedAt")).isFalse();
    }

    @Test
    void fullLifecycleSetsTimestampsAndEnforcesRules() throws Exception {
        String admin = adminToken();
        long id = open(admin, "MEDIUM").get("id").asLong();
        String url = "/api/incidents/" + id;

        assertThat(body(patchJson(url, admin, Map.of("status", "INVESTIGATING", "assignee", "On-call"))).get("status").asText()).isEqualTo("INVESTIGATING");
        assertThat(body(patchJson(url, admin, Map.of("status", "MITIGATED"))).get("status").asText()).isEqualTo("MITIGATED");

        MvcResult noRoot = patchJson(url, admin, Map.of("status", "RESOLVED"));
        assertThat(noRoot.getResponse().getStatus()).isEqualTo(400);

        JsonNode resolved = body(patchJson(url, admin, Map.of("status", "RESOLVED", "resolution", "Restarted worker", "rootCause", "Memory leak in simulator")));
        assertThat(resolved.get("status").asText()).isEqualTo("RESOLVED");
        assertThat(resolved.get("resolvedAt").asText()).isNotBlank();
        assertThat(resolved.get("rootCause").asText()).isEqualTo("Memory leak in simulator");

        JsonNode closed = body(patchJson(url, admin, Map.of("status", "CLOSED")));
        assertThat(closed.get("closedAt").asText()).isNotBlank();
        MvcResult afterClose = patchJson(url, admin, Map.of("title", "Changed"));
        assertThat(afterClose.getResponse().getStatus()).isEqualTo(409);
    }

    @Test
    void invalidTransitionsAreRejected() throws Exception {
        String admin = adminToken();
        long id = open(admin, "LOW").get("id").asLong();
        MvcResult r = patchJson("/api/incidents/" + id, admin, Map.of("status", "CLOSED"));
        assertThat(r.getResponse().getStatus()).isEqualTo(409);
        assertThat(errorCode(r)).isEqualTo("INVALID_STATE_TRANSITION");
    }

    @Test
    void reopeningAResolvedIncidentClearsResolvedAt() throws Exception {
        String admin = adminToken();
        long id = open(admin, "LOW").get("id").asLong();
        String url = "/api/incidents/" + id;
        patchJson(url, admin, Map.of("status", "RESOLVED", "resolution", "Fixed", "rootCause", "Config"));
        JsonNode reopened = body(patchJson(url, admin, Map.of("status", "INVESTIGATING")));
        assertThat(reopened.get("status").asText()).isEqualTo("INVESTIGATING");
        assertThat(reopened.has("resolvedAt")).isFalse();
    }

    @Test
    void listFiltersAndValidation() throws Exception {
        String admin = adminToken();
        open(admin, "CRITICAL");
        JsonNode critical = body(getJson("/api/incidents?severity=CRITICAL&status=OPEN", admin));
        assertThat(critical.get("totalElements").asInt()).isGreaterThanOrEqualTo(1);
        critical.get("content").forEach(n -> assertThat(n.get("severity").asText()).isEqualTo("CRITICAL"));

        assertThat(postJson("/api/incidents", admin, Map.of("title", "", "description", "x", "severity", "LOW", "affectedService", "API")).getResponse().getStatus()).isEqualTo(400);
        assertThat(postJson("/api/incidents", admin, Map.of("title", "x", "description", "y", "severity", "SEV9", "affectedService", "API")).getResponse().getStatus()).isEqualTo(400);
        assertThat(getJson("/api/incidents/999999", admin).getResponse().getStatus()).isEqualTo(404);
    }

    @Test
    void incidentChangesAreAudited() throws Exception {
        String admin = adminToken();
        open(admin, "LOW");
        JsonNode events = body(getJson("/api/admin/audit-events?action=INCIDENT_CREATED", admin));
        assertThat(events.get("totalElements").asInt()).isGreaterThanOrEqualTo(1);
    }
}
