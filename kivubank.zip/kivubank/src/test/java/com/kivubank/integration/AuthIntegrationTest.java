package com.kivubank.integration;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.JsonNode;
import com.kivubank.support.IntegrationTestBase;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MvcResult;

class AuthIntegrationTest extends IntegrationTestBase {

    private Map<String, Object> registration(String suffix) {
        return Map.of("fullName", "Auth Tester", "email", "auth" + suffix + "@example.com",
                "phone", "+1415557" + String.format("%04d", Integer.parseInt(suffix) % 10000), "password", PASSWORD);
    }

    @Test
    void registerCreatesCustomerWithAccountAndIgnoresRoleInjection() throws Exception {
        String s = uniqueSuffix();
        Map<String, Object> req = new java.util.HashMap<>(registration(s));
        req.put("role", "ADMIN");   // mass-assignment attempt
        MvcResult r = postJson("/api/auth/register", null, req);
        assertThat(r.getResponse().getStatus()).isEqualTo(201);
        JsonNode b = body(r);
        assertThat(b.get("role").asText()).isEqualTo("CUSTOMER");
        assertThat(b.get("accountNumber").asText()).matches("\\d{10}");
        assertThat(b.has("passwordHash")).isFalse();
    }

    @Test
    void duplicateRegistrationIsRejected() throws Exception {
        String s = uniqueSuffix();
        assertThat(postJson("/api/auth/register", null, registration(s)).getResponse().getStatus()).isEqualTo(201);
        MvcResult dup = postJson("/api/auth/register", null, registration(s));
        assertThat(dup.getResponse().getStatus()).isEqualTo(409);
        assertThat(errorCode(dup)).isEqualTo("ALREADY_EXISTS");
    }

    @Test
    void weakPasswordAndBadPhoneAreRejected() throws Exception {
        String s = uniqueSuffix();
        Map<String, Object> weak = new java.util.HashMap<>(registration(s));
        weak.put("password", "password");
        MvcResult r1 = postJson("/api/auth/register", null, weak);
        assertThat(r1.getResponse().getStatus()).isEqualTo(400);
        assertThat(errorCode(r1)).isEqualTo("VALIDATION_FAILED");

        Map<String, Object> badPhone = new java.util.HashMap<>(registration(uniqueSuffix()));
        badPhone.put("phone", "12345");
        assertThat(postJson("/api/auth/register", null, badPhone).getResponse().getStatus()).isEqualTo(400);

        Map<String, Object> blankName = new java.util.HashMap<>(registration(uniqueSuffix()));
        blankName.put("fullName", "");
        MvcResult r3 = postJson("/api/auth/register", null, blankName);
        assertThat(r3.getResponse().getStatus()).isEqualTo(400);
        assertThat(body(r3).get("violations").isArray()).isTrue();
    }

    @Test
    void loginWithEmailAndAccountNumber() throws Exception {
        Customer c = newCustomer();
        assertThat(loginToken(c.email(), PASSWORD)).isNotBlank();
        assertThat(loginToken(c.accountNumber(), PASSWORD)).isNotBlank();
    }

    @Test
    void wrongPasswordAndUnknownUserGiveTheSameGenericError() throws Exception {
        Customer c = newCustomer();
        MvcResult wrong = postJson("/api/auth/login", null, Map.of("identifier", c.email(), "password", "Wrong-Passw0rd!x"));
        MvcResult unknown = postJson("/api/auth/login", null, Map.of("identifier", "nobody" + uniqueSuffix() + "@example.com", "password", PASSWORD));
        assertThat(wrong.getResponse().getStatus()).isEqualTo(401);
        assertThat(unknown.getResponse().getStatus()).isEqualTo(401);
        assertThat(body(wrong).get("message").asText()).isEqualTo(body(unknown).get("message").asText());
        assertThat(errorCode(wrong)).isEqualTo("INVALID_CREDENTIALS");
    }

    @Test
    void accountLocksAfterRepeatedFailures() throws Exception {
        Customer c = newCustomer();
        for (int i = 0; i < 5; i++) {
            postJson("/api/auth/login", null, Map.of("identifier", c.email(), "password", "Wrong-Passw0rd!x"));
        }
        MvcResult locked = postJson("/api/auth/login", null, Map.of("identifier", c.email(), "password", PASSWORD));
        assertThat(locked.getResponse().getStatus()).isEqualTo(423);
        assertThat(errorCode(locked)).isEqualTo("ACCOUNT_LOCKED");
    }

    @Test
    void protectedEndpointsNeedAValidToken() throws Exception {
        assertThat(getJson("/api/auth/me", null).getResponse().getStatus()).isEqualTo(401);
        assertThat(getJson("/api/auth/me", "garbage.token.value").getResponse().getStatus()).isEqualTo(401);
        Customer c = newCustomer();
        MvcResult me = getJson("/api/auth/me", c.token());
        assertThat(me.getResponse().getStatus()).isEqualTo(200);
        assertThat(body(me).get("email").asText()).isEqualTo(c.email());
    }

    @Test
    void logoutRevokesTheToken() throws Exception {
        Customer c = newCustomer();
        assertThat(postJson("/api/auth/logout", c.token(), Map.of()).getResponse().getStatus()).isEqualTo(204);
        assertThat(getJson("/api/auth/me", c.token()).getResponse().getStatus()).isEqualTo(401);
        assertThat(getJson("/api/auth/me", loginToken(c.email(), PASSWORD)).getResponse().getStatus()).isEqualTo(200);
    }

    @Test
    void changingPasswordInvalidatesOlderTokens() throws Exception {
        Customer c = newCustomer();
        Thread.sleep(1100);   // JWT iat has one-second resolution
        MvcResult change = postJson("/api/auth/change-password", c.token(),
                Map.of("currentPassword", PASSWORD, "newPassword", "Another-Str0ng-Passw0rd!"));
        assertThat(change.getResponse().getStatus()).isEqualTo(204);
        assertThat(getJson("/api/auth/me", c.token()).getResponse().getStatus()).isEqualTo(401);
        assertThat(loginToken(c.email(), "Another-Str0ng-Passw0rd!")).isNotBlank();
    }

    @Test
    void changePasswordNeedsCorrectCurrentPassword() throws Exception {
        Customer c = newCustomer();
        MvcResult r = postJson("/api/auth/change-password", c.token(),
                Map.of("currentPassword", "Wrong-Passw0rd!x", "newPassword", "Another-Str0ng-Passw0rd!"));
        assertThat(r.getResponse().getStatus()).isEqualTo(401);
    }

    @Test
    void errorsNeverLeakInternals() throws Exception {
        MvcResult malformed = call(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post("/api/auth/login")
                .contentType("application/json").content("{ not json"));
        assertThat(malformed.getResponse().getStatus()).isEqualTo(400);
        String text = malformed.getResponse().getContentAsString();
        assertThat(text).doesNotContain("Exception").doesNotContain("at com.").doesNotContain("trace");
        assertThat(malformed.getResponse().getHeader("X-Request-Id")).isNotBlank();
    }
}
