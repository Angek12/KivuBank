package com.kivubank.integration;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.JsonNode;
import com.kivubank.support.IntegrationTestBase;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;

class ReconciliationIntegrationTest extends IntegrationTestBase {
    /** Each test works in its own time window so tests cannot influence each other's counts. */
    private Instant start;

    @org.junit.jupiter.api.BeforeEach
    void markStart() throws Exception {
        Thread.sleep(25);
        start = Instant.now();
        Thread.sleep(25);
    }

    private Map<String, Object> settlement(double drop, double dup, double drift, double flip, int orphans) {
        Map<String, Object> m = new HashMap<>();
        m.put("from", start.toString());
        m.put("dropRate", drop);
        m.put("duplicateRate", dup);
        m.put("amountDriftRate", drift);
        m.put("statusFlipRate", flip);
        m.put("timeoutRate", 0.0);
        m.put("orphanCount", orphans);
        m.put("seed", 1);
        return m;
    }

    private JsonNode run(String admin) throws Exception {
        var r = postJson("/api/admin/reconciliation/runs", admin, Map.of("from", start.toString()));
        assertThat(r.getResponse().getStatus()).isEqualTo(201);
        return body(r);
    }

    private void createActivity() throws Exception {
        Customer a = fundedCustomer("1000.00");
        Customer b = newCustomer();
        transfer(a, b, "100.00");
        transfer(a, b, "99999.00");   // fails: insufficient funds -> FAILED transaction
    }

    @Test
    void cleanSettlementMatchesEverything() throws Exception {
        String admin = adminToken();
        createActivity();
        postJson("/api/admin/reconciliation/simulate-settlement", admin, settlement(0, 0, 0, 0, 0));
        JsonNode run = run(admin);
        assertThat(run.get("simulation").asBoolean()).isTrue();
        assertThat(run.get("matched").asInt()).isEqualTo(run.get("internalCount").asInt());
        assertThat(run.get("missingExternal").asInt()).isZero();
        assertThat(run.get("amountMismatch").asInt()).isZero();
        assertThat(run.get("duplicates").asInt()).isZero();
        assertThat(run.get("statusMismatch").asInt()).isZero();
    }

    @Test
    void droppedPaymentsAreReportedAsMissingExternal() throws Exception {
        String admin = adminToken();
        postJson("/api/admin/reconciliation/simulate-settlement", admin, settlement(0, 0, 0, 0, 0));
        createActivity();
        postJson("/api/admin/reconciliation/simulate-settlement", admin, settlement(1, 0, 0, 0, 0));
        JsonNode run = run(admin);
        assertThat(run.get("missingExternal").asInt()).isEqualTo(3);
        assertThat(run.get("matched").asInt()).isZero();
    }

    @Test
    void duplicatesAmountDriftStatusFlipsAndOrphansAreDetected() throws Exception {
        String admin = adminToken();
        postJson("/api/admin/reconciliation/simulate-settlement", admin, settlement(0, 0, 0, 0, 0));
        createActivity();
        var sim = postJson("/api/admin/reconciliation/simulate-settlement", admin, settlement(0, 1, 1, 1, 2));
        assertThat(sim.getResponse().getStatus()).isEqualTo(200);
        assertThat(body(sim).get("simulation").asBoolean()).isTrue();

        JsonNode run = run(admin);
        assertThat(run.get("duplicates").asInt()).isEqualTo(3);
        assertThat(run.get("amountMismatch").asInt()).isEqualTo(3);
        assertThat(run.get("statusMismatch").asInt()).isEqualTo(3);
        assertThat(run.get("missingInternal").asInt()).isEqualTo(2);
        assertThat(run.get("matched").asInt()).isZero();

        long runId = run.get("id").asLong();
        for (String category : new String[]{"DUPLICATE", "AMOUNT_MISMATCH", "STATUS_MISMATCH", "MISSING_INTERNAL"}) {
            JsonNode items = body(getJson("/api/admin/reconciliation/runs/" + runId + "/items?category=" + category, admin));
            assertThat(items.get("totalElements").asInt()).as(category).isGreaterThanOrEqualTo(1);
            items.get("content").forEach(i -> assertThat(i.get("category").asText()).isEqualTo(category));
        }
        assertThat(body(getJson("/api/admin/reconciliation/runs/" + runId, admin)).get("id").asLong()).isEqualTo(runId);
    }

    @Test
    void providerSimulatorReturnsAllFourStates() throws Exception {
        String admin = adminToken();
        for (String state : new String[]{"SUCCESS", "FAILED", "PENDING", "TIMEOUT"}) {
            var r = postJson("/api/admin/simulator/provider/payments", admin, Map.of("amount", "10.00", "forceStatus", state));
            assertThat(r.getResponse().getStatus()).isEqualTo(200);
            assertThat(body(r).get("status").asText()).isEqualTo(state);
            assertThat(body(r).get("providerReference").asText()).startsWith("EXT-");
        }
    }

    @Test
    void onlyAdminsRunAndAuditorsCanRead() throws Exception {
        String auditor = staffToken("AUDITOR");
        String admin = adminToken();
        assertThat(postJson("/api/admin/reconciliation/runs", auditor, Map.of()).getResponse().getStatus()).isEqualTo(403);
        assertThat(postJson("/api/admin/reconciliation/simulate-settlement", auditor, settlement(0, 0, 0, 0, 0)).getResponse().getStatus()).isEqualTo(403);
        run(admin);
        assertThat(getJson("/api/admin/reconciliation/runs", auditor).getResponse().getStatus()).isEqualTo(200);
    }

    @Test
    void rejectsInvalidWindowAndRates() throws Exception {
        String admin = adminToken();
        var bad = postJson("/api/admin/reconciliation/runs", admin, Map.of("from", "2026-02-01T00:00:00Z", "to", "2026-01-01T00:00:00Z"));
        assertThat(bad.getResponse().getStatus()).isEqualTo(400);
        assertThat(postJson("/api/admin/reconciliation/simulate-settlement", admin, settlement(-1, 0, 0, 0, 0)).getResponse().getStatus()).isEqualTo(400);
    }
}
