package com.kivubank.integration;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.JsonNode;
import com.kivubank.notification.Notification;
import com.kivubank.notification.NotificationChannel;
import com.kivubank.notification.NotificationRepository;
import com.kivubank.support.IntegrationTestBase;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

class AuditAndNotificationIntegrationTest extends IntegrationTestBase {
    @Autowired NotificationRepository notificationRepository;

    private JsonNode audit(String admin, String query) throws Exception {
        return body(getJson("/api/admin/audit-events?" + query, admin));
    }

    private boolean hasAction(JsonNode page, String targetId) {
        for (JsonNode e : page.get("content")) {
            if (targetId == null || targetId.equals(e.path("targetId").asText())) {
                return true;
            }
        }
        return false;
    }

    @Test
    void securityAndFinancialEventsAreAudited() throws Exception {
        String admin = adminToken();
        Customer a = fundedCustomer("1000.00");
        Customer b = newCustomer();
        postJson("/api/auth/login", null, Map.of("identifier", a.email(), "password", "Wrong-Passw0rd!x"));
        String ref = body(transfer(a, b, "100.00")).get("reference").asText();
        money("withdraw", a, UUID.randomUUID().toString(), Map.of("amount", "5.00", "pin", a.pin()));
        money("withdraw", a, UUID.randomUUID().toString(), Map.of("amount", "5.00", "pin", "1357"));
        postJson("/api/auth/change-password", a.token(), Map.of("currentPassword", PASSWORD, "newPassword", "Another-Str0ng-Passw0rd!"));

        assertThat(hasAction(audit(admin, "action=ACCOUNT_CREATED&actor=" + a.email()), a.accountNumber())).isTrue();
        assertThat(audit(admin, "action=LOGIN_SUCCESS&actor=" + a.email()).get("totalElements").asInt()).isGreaterThanOrEqualTo(1);
        assertThat(audit(admin, "action=LOGIN_FAILURE&outcome=FAILURE&actor=" + a.email()).get("totalElements").asInt()).isGreaterThanOrEqualTo(1);
        assertThat(hasAction(audit(admin, "action=TRANSFER_CREATED&actor=" + a.email()), ref)).isTrue();
        assertThat(hasAction(audit(admin, "action=TRANSFER_COMPLETED&actor=" + a.email()), ref)).isTrue();
        assertThat(audit(admin, "action=WITHDRAWAL&actor=" + a.email()).get("totalElements").asInt()).isGreaterThanOrEqualTo(1);
        assertThat(audit(admin, "action=PIN_CREATED&actor=" + a.email()).get("totalElements").asInt()).isEqualTo(1);
        assertThat(audit(admin, "action=PIN_FAILED&actor=" + a.email()).get("totalElements").asInt()).isGreaterThanOrEqualTo(1);
        assertThat(audit(admin, "action=PASSWORD_CHANGED&actor=" + a.email()).get("totalElements").asInt()).isEqualTo(1);
    }

    @Test
    void failedTransfersAndAdminActionsAreAudited() throws Exception {
        String admin = adminToken();
        Customer a = fundedCustomer("10.00");
        Customer b = newCustomer();
        String failedRef = body(transfer(a, b, "500.00")).get("reference").asText();
        assertThat(hasAction(audit(admin, "action=TRANSFER_FAILED&outcome=FAILURE&actor=" + a.email()), failedRef)).isTrue();

        postJson("/api/admin/accounts/" + b.accountNumber() + "/freeze", admin, Map.of());
        assertThat(hasAction(audit(admin, "action=ADMIN_ACCOUNT_FROZEN"), b.accountNumber())).isTrue();
        postJson("/api/admin/users", admin, Map.of("fullName", "New Auditor", "email", "na" + uniqueSuffix() + "@example.com",
                "phone", "+14155550177", "password", PASSWORD, "role", "AUDITOR"));
        assertThat(audit(admin, "action=ADMIN_USER_CREATED").get("totalElements").asInt()).isGreaterThanOrEqualTo(1);
    }

    @Test
    void auditTrailNeverContainsSecrets() throws Exception {
        String admin = adminToken();
        Customer a = fundedCustomer("100.00");
        money("withdraw", a, UUID.randomUUID().toString(), Map.of("amount", "5.00", "pin", "1357"));
        String all = getJson("/api/admin/audit-events?size=100", admin).getResponse().getContentAsString();
        assertThat(all).doesNotContain(PASSWORD).doesNotContain("passwordHash").doesNotContain(a.token());
    }

    @Test
    void auditEntriesCarryRequestIdAndActor() throws Exception {
        String admin = adminToken();
        Customer a = newCustomer();
        JsonNode first = audit(admin, "action=ACCOUNT_CREATED&actor=" + a.email()).get("content").get(0);
        assertThat(first.path("requestId").asText()).isNotBlank();
        assertThat(first.path("actorEmail").asText()).isEqualTo(a.email());
        assertThat(first.path("actorRole").asText()).isEqualTo("CUSTOMER");
    }

    @Test
    void transferNotificationsReachBothPartiesThroughTheSimulatedProvider() throws Exception {
        Customer a = fundedCustomer("1000.00");
        Customer b = newCustomer();
        transfer(a, b, "100.00");
        String aInbox = getJson("/api/notifications", a.token()).getResponse().getContentAsString();
        String bInbox = getJson("/api/notifications", b.token()).getResponse().getContentAsString();
        assertThat(aInbox).contains("Transfer successful");
        assertThat(bInbox).contains("Funds received");
        assertThat(body(getJson("/api/notifications/unread-count", b.token())).get("unread").asInt()).isGreaterThanOrEqualTo(1);

        long smsRows = notificationRepository.findAll().stream()
                .filter(n -> n.getUserId().equals(a.id()) && n.getChannel() == NotificationChannel.SMS)
                .filter(n -> "simulated".equals(n.getProvider()) && n.getStatus() == Notification.DeliveryStatus.SENT).count();
        assertThat(smsRows).isGreaterThanOrEqualTo(1);
    }

    @Test
    void failedTransferAndSecurityNotificationsAreCreated() throws Exception {
        Customer a = fundedCustomer("10.00");
        Customer b = newCustomer();
        transfer(a, b, "99.00");
        assertThat(getJson("/api/notifications", a.token()).getResponse().getContentAsString()).contains("Transfer failed");
        // login / PIN notifications are delivered asynchronously
        Awaitility.await().atMost(Duration.ofSeconds(10)).untilAsserted(() -> {
            String inbox = getJson("/api/notifications?size=50", a.token()).getResponse().getContentAsString();
            assertThat(inbox).contains("New sign-in").contains("PIN updated");
        });
    }

    @Test
    void notificationCanBeMarkedReadAndStatementGeneratesOne() throws Exception {
        Customer c = fundedCustomer("50.00");
        getJson("/api/accounts/me/statement", c.token());
        Awaitility.await().atMost(Duration.ofSeconds(10)).untilAsserted(() ->
                assertThat(getJson("/api/notifications?size=50", c.token()).getResponse().getContentAsString()).contains("Statement generated"));
        JsonNode first = body(getJson("/api/notifications?size=1", c.token())).get("content").get(0);
        long id = first.get("id").asLong();
        assertThat(call(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post("/api/notifications/" + id + "/read")
                .header("Authorization", "Bearer " + c.token())).getResponse().getStatus()).isEqualTo(204);
        Customer other = newCustomer();
        assertThat(call(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post("/api/notifications/" + id + "/read")
                .header("Authorization", "Bearer " + other.token())).getResponse().getStatus()).isEqualTo(404);
    }
}
