package com.kivubank.integration;

import static org.assertj.core.api.Assertions.assertThat;

import com.kivubank.support.IntegrationTestBase;
import java.util.Map;
import org.junit.jupiter.api.Test;

class RbacIntegrationTest extends IntegrationTestBase {

    private int status(String url, String token) throws Exception {
        return getJson(url, token).getResponse().getStatus();
    }

    @Test
    void anonymousUsersGet401OnApiAndCanReachPublicEndpoints() throws Exception {
        assertThat(status("/api/accounts/me", null)).isEqualTo(401);
        assertThat(status("/api/ops/dashboard", null)).isEqualTo(401);
        assertThat(status("/actuator/health", null)).isEqualTo(200);
        assertThat(status("/v3/api-docs", null)).isEqualTo(200);
    }

    @Test
    void customersCannotUseStaffEndpoints() throws Exception {
        Customer c = newCustomer();
        for (String url : new String[]{"/api/admin/audit-events", "/api/ops/dashboard", "/api/incidents",
                "/api/admin/users", "/api/admin/accounts", "/api/admin/transactions", "/api/admin/anomalies",
                "/api/admin/reconciliation/runs", "/actuator/metrics", "/actuator/prometheus"}) {
            assertThat(status(url, c.token())).as(url).isEqualTo(403);
        }
    }

    @Test
    void staffCannotUseCustomerBankingEndpoints() throws Exception {
        String support = staffToken("SUPPORT_AGENT");
        assertThat(status("/api/accounts/me", support)).isEqualTo(403);
        assertThat(postJson("/api/transactions/deposit", support, Map.of("amount", "10", "pin", "4829")).getResponse().getStatus())
                .isIn(400, 403);
    }

    @Test
    void auditorIsReadOnly() throws Exception {
        String auditor = staffToken("AUDITOR");
        assertThat(status("/api/admin/audit-events", auditor)).isEqualTo(200);
        assertThat(status("/api/incidents", auditor)).isEqualTo(200);
        assertThat(status("/api/ops/dashboard", auditor)).isEqualTo(200);
        assertThat(postJson("/api/incidents", auditor, Map.of("title", "x", "description", "y", "severity", "LOW",
                "affectedService", "API")).getResponse().getStatus()).isEqualTo(403);
        assertThat(postJson("/api/admin/users", auditor, Map.of("fullName", "A B", "email", "x@example.com", "phone", "+14155550199",
                "password", PASSWORD, "role", "ADMIN")).getResponse().getStatus()).isEqualTo(403);
    }

    @Test
    void supportAgentCanManageIncidentsButNotAdminActions() throws Exception {
        String support = staffToken("SUPPORT_AGENT");
        assertThat(postJson("/api/incidents", support, Map.of("title", "Latency", "description", "Slow responses", "severity", "LOW",
                "affectedService", "API")).getResponse().getStatus()).isEqualTo(201);
        assertThat(postJson("/api/admin/transactions/KB20260101-AAAAAAAAAA/approve", support, Map.of()).getResponse().getStatus()).isEqualTo(403);
        assertThat(postJson("/api/admin/accounts/1000000000/freeze", support, Map.of()).getResponse().getStatus()).isEqualTo(403);
        assertThat(status("/api/admin/audit-events", support)).isEqualTo(403);
    }

    @Test
    void adminHasFullAccess() throws Exception {
        String admin = adminToken();
        for (String url : new String[]{"/api/admin/audit-events", "/api/ops/dashboard", "/api/ops/health", "/api/ops/metrics",
                "/api/incidents", "/api/admin/users", "/api/admin/accounts", "/api/admin/transactions", "/api/admin/anomalies/model",
                "/api/admin/reconciliation/runs", "/actuator/metrics"}) {
            assertThat(status(url, admin)).as(url).isEqualTo(200);
        }
    }

    @Test
    void disabledUsersLoseAccessImmediately() throws Exception {
        Customer c = newCustomer();
        assertThat(status("/api/accounts/me", c.token())).isEqualTo(200);
        var res = patchJson("/api/admin/users/" + c.id() + "/status", adminToken(), Map.of("status", "DISABLED"));
        assertThat(res.getResponse().getStatus()).isEqualTo(200);
        assertThat(status("/api/accounts/me", c.token())).isEqualTo(401);
        assertThat(postJson("/api/auth/login", null, Map.of("identifier", c.email(), "password", PASSWORD)).getResponse().getStatus()).isEqualTo(401);
    }

    @Test
    void adminCannotDisableThemselvesAndCustomerRoleCannotBeCreatedAsStaff() throws Exception {
        String admin = adminToken();
        Long adminId = body(getJson("/api/auth/me", admin)).get("id").asLong();
        assertThat(patchJson("/api/admin/users/" + adminId + "/status", admin, Map.of("status", "DISABLED")).getResponse().getStatus()).isEqualTo(400);
        assertThat(postJson("/api/admin/users", admin, Map.of("fullName", "Cust Omer", "email", "c" + uniqueSuffix() + "@example.com",
                "phone", "+14155550198", "password", PASSWORD, "role", "CUSTOMER")).getResponse().getStatus()).isEqualTo(400);
    }
}
