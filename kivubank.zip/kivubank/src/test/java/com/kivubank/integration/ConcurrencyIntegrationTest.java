package com.kivubank.integration;

import static org.assertj.core.api.Assertions.assertThat;

import com.kivubank.support.IntegrationTestBase;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MvcResult;

/** Hammers the money paths from many threads: no overdraft, no lost update, no duplicate, no deadlock. */
class ConcurrencyIntegrationTest extends IntegrationTestBase {

    private List<MvcResult> runParallel(int threads, Callable<MvcResult> task) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch ready = new CountDownLatch(threads);
        CountDownLatch go = new CountDownLatch(1);
        List<Future<MvcResult>> futures = new ArrayList<>();
        for (int i = 0; i < threads; i++) {
            futures.add(pool.submit(() -> {
                ready.countDown();
                go.await();
                return task.call();
            }));
        }
        ready.await();
        go.countDown();
        List<MvcResult> results = new ArrayList<>();
        for (Future<MvcResult> f : futures) {
            results.add(f.get(90, TimeUnit.SECONDS));   // a deadlock would surface here as a timeout
        }
        pool.shutdownNow();
        return results;
    }

    private long count(List<MvcResult> results, int status) {
        return results.stream().filter(r -> r.getResponse().getStatus() == status).count();
    }

    @Test
    void parallelTransfersNeverOverdrawTheSourceAccount() throws Exception {
        Customer a = fundedCustomer("100.00");
        Customer b = newCustomer();
        List<MvcResult> results = runParallel(20, () -> transfer(a, b, "10.00"));
        assertThat(count(results, 201)).isEqualTo(10);
        assertThat(count(results, 422)).isEqualTo(10);
        assertThat(balanceOf(a)).isEqualByComparingTo("0.00");
        assertThat(balanceOf(b)).isEqualByComparingTo("100.00");
    }

    @Test
    void parallelWithdrawalsNeverGoNegative() throws Exception {
        Customer c = fundedCustomer("100.00");
        List<MvcResult> results = runParallel(15, () ->
                money("withdraw", c, UUID.randomUUID().toString(), Map.of("amount", "10.00", "pin", c.pin())));
        assertThat(count(results, 201)).isEqualTo(10);
        assertThat(count(results, 422)).isEqualTo(5);
        assertThat(balanceOf(c)).isEqualByComparingTo("0.00");
    }

    @Test
    void parallelDepositsAreAllApplied() throws Exception {
        Customer c = newCustomer();
        List<MvcResult> results = runParallel(20, () -> deposit(c, "5.00"));
        assertThat(count(results, 201)).isEqualTo(20);
        assertThat(balanceOf(c)).isEqualByComparingTo("100.00");
    }

    @Test
    void sameIdempotencyKeyFiredConcurrentlyMovesMoneyOnce() throws Exception {
        Customer a = fundedCustomer("1000.00");
        Customer b = newCustomer();
        String key = UUID.randomUUID().toString();
        Map<String, Object> req = Map.of("targetAccountNumber", b.accountNumber(), "amount", "100.00", "pin", a.pin());
        List<MvcResult> results = runParallel(10, () -> money("transfer", a, key, req));

        long created = results.stream().filter(r -> r.getResponse().getStatus() == 201 && r.getResponse().getHeader("Idempotent-Replayed") == null).count();
        long replayed = results.stream().filter(r -> r.getResponse().getStatus() == 201 && "true".equals(r.getResponse().getHeader("Idempotent-Replayed"))).count();
        long inProgress = count(results, 409);
        assertThat(created).isEqualTo(1);
        assertThat(created + replayed + inProgress).isEqualTo(10);
        assertThat(balanceOf(a)).isEqualByComparingTo("900.00");
        assertThat(balanceOf(b)).isEqualByComparingTo("100.00");
        assertThat(body(getJson("/api/transactions?type=TRANSFER", a.token())).get("totalElements").asInt()).isEqualTo(1);
    }

    @Test
    void opposingTransfersDoNotDeadlockAndConserveMoney() throws Exception {
        Customer a = fundedCustomer("1000.00");
        Customer b = fundedCustomer("1000.00");
        AtomicCounter flip = new AtomicCounter();
        List<MvcResult> results = runParallel(20, () -> flip.next() % 2 == 0 ? transfer(a, b, "10.00") : transfer(b, a, "10.00"));
        assertThat(count(results, 201)).isEqualTo(20);
        BigDecimal total = balanceOf(a).add(balanceOf(b));
        assertThat(total).isEqualByComparingTo("2000.00");
    }

    private static final class AtomicCounter {
        private final java.util.concurrent.atomic.AtomicInteger n = new java.util.concurrent.atomic.AtomicInteger();

        int next() {
            return n.getAndIncrement();
        }
    }
}
