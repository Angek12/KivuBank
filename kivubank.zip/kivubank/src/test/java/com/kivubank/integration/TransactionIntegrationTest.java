package com.kivubank.integration;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.JsonNode;
import com.kivubank.support.IntegrationTestBase;
import java.math.BigDecimal;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MvcResult;

class TransactionIntegrationTest extends IntegrationTestBase {

    @Test
    void depositIncreasesBalanceAndReturnsTransactionWithUniqueReference() throws Exception {
        Customer c = newCustomer();
        MvcResult r = deposit(c, "2500.50");
        assertThat(r.getResponse().getStatus()).isEqualTo(201);
        JsonNode t = body(r);
        assertThat(t.get("status").asText()).isEqualTo("SUCCESS");
        assertThat(t.get("type").asText()).isEqualTo("DEPOSIT");
        assertThat(t.get("reference").asText()).matches("KB\\d{8}-[A-Z0-9]{10}");
        assertThat(t.get("direction").asText()).isEqualTo("CREDIT");
        assertThat(balanceOf(c)).isEqualByComparingTo("2500.50");
        String second = body(deposit(c, "1.00")).get("reference").asText();
        assertThat(second).isNotEqualTo(t.get("reference").asText());
    }

    @Test
    void withdrawalReducesBalanceAndInsufficientFundsIsRecordedAsFailed() throws Exception {
        Customer c = fundedCustomer("1000.00");
        MvcResult ok = money("withdraw", c, UUID.randomUUID().toString(), Map.of("amount", "400.00", "pin", c.pin()));
        assertThat(ok.getResponse().getStatus()).isEqualTo(201);
        assertThat(balanceOf(c)).isEqualByComparingTo("600.00");

        MvcResult tooMuch = money("withdraw", c, UUID.randomUUID().toString(), Map.of("amount", "600.01", "pin", c.pin()));
        assertThat(tooMuch.getResponse().getStatus()).isEqualTo(422);
        JsonNode failed = body(tooMuch);
        assertThat(failed.get("status").asText()).isEqualTo("FAILED");
        assertThat(failed.get("failureReason").asText()).isEqualTo("INSUFFICIENT_FUNDS");
        assertThat(balanceOf(c)).isEqualByComparingTo("600.00");

        MvcResult history = getJson("/api/transactions?status=FAILED", c.token());
        assertThat(body(history).get("totalElements").asInt()).isEqualTo(1);
    }

    @Test
    void transferMovesMoneyBetweenAccountsAndShowsDirectionPerViewer() throws Exception {
        Customer a = fundedCustomer("5000.00");
        Customer b = newCustomer();
        MvcResult r = transfer(a, b, "1250.25");
        assertThat(r.getResponse().getStatus()).isEqualTo(201);
        String ref = body(r).get("reference").asText();
        assertThat(balanceOf(a)).isEqualByComparingTo("3749.75");
        assertThat(balanceOf(b)).isEqualByComparingTo("1250.25");
        assertThat(body(getJson("/api/transactions/" + ref, a.token())).get("direction").asText()).isEqualTo("DEBIT");
        assertThat(body(getJson("/api/transactions/" + ref, b.token())).get("direction").asText()).isEqualTo("CREDIT");
        assertThat(body(getJson("/api/transactions/" + ref, b.token())).get("balanceAfter").decimalValue()).isEqualByComparingTo("1250.25");
    }

    @Test
    void transferValidation() throws Exception {
        Customer a = fundedCustomer("100.00");
        Customer b = newCustomer();
        MvcResult unknown = money("transfer", a, UUID.randomUUID().toString(), Map.of("targetAccountNumber", "9999999999", "amount", "5", "pin", a.pin()));
        assertThat(unknown.getResponse().getStatus()).isEqualTo(404);
        assertThat(errorCode(unknown)).isEqualTo("ACCOUNT_NOT_FOUND");

        MvcResult self = money("transfer", a, UUID.randomUUID().toString(), Map.of("targetAccountNumber", a.accountNumber(), "amount", "5", "pin", a.pin()));
        assertThat(self.getResponse().getStatus()).isEqualTo(400);
        assertThat(errorCode(self)).isEqualTo("SAME_ACCOUNT");

        for (String bad : new String[]{"0", "-10", "10.999", "abc"}) {
            MvcResult r = money("transfer", a, UUID.randomUUID().toString(), Map.of("targetAccountNumber", b.accountNumber(), "amount", bad, "pin", a.pin()));
            assertThat(r.getResponse().getStatus()).as("amount " + bad).isEqualTo(400);
        }
        MvcResult huge = money("transfer", a, UUID.randomUUID().toString(), Map.of("targetAccountNumber", b.accountNumber(), "amount", "5000000.01", "pin", a.pin()));
        assertThat(huge.getResponse().getStatus()).isEqualTo(400);
        assertThat(errorCode(huge)).isEqualTo("INVALID_AMOUNT");
        assertThat(balanceOf(a)).isEqualByComparingTo("100.00");
    }

    @Test
    void insufficientFundsTransferFailsWithoutMovingMoney() throws Exception {
        Customer a = fundedCustomer("50.00");
        Customer b = newCustomer();
        MvcResult r = transfer(a, b, "50.01");
        assertThat(r.getResponse().getStatus()).isEqualTo(422);
        assertThat(body(r).get("status").asText()).isEqualTo("FAILED");
        assertThat(balanceOf(a)).isEqualByComparingTo("50.00");
        assertThat(balanceOf(b)).isEqualByComparingTo("0.00");
    }

    @Test
    void idempotencyKeyIsRequiredOnMoneyOperations() throws Exception {
        Customer c = newCustomer();
        MvcResult r = money("deposit", c, null, Map.of("amount", "10", "pin", c.pin()));
        assertThat(r.getResponse().getStatus()).isEqualTo(400);
        assertThat(errorCode(r)).isEqualTo("IDEMPOTENCY_KEY_REQUIRED");
        MvcResult shortKey = money("deposit", c, "abc", Map.of("amount", "10", "pin", c.pin()));
        assertThat(shortKey.getResponse().getStatus()).isEqualTo(400);
        assertThat(balanceOf(c)).isEqualByComparingTo("0.00");
    }

    @Test
    void replayingTheSameRequestDoesNotMoveMoneyTwice() throws Exception {
        Customer a = fundedCustomer("1000.00");
        Customer b = newCustomer();
        String key = UUID.randomUUID().toString();
        Map<String, Object> req = Map.of("targetAccountNumber", b.accountNumber(), "amount", "100.00", "pin", a.pin());
        MvcResult first = money("transfer", a, key, req);
        MvcResult second = money("transfer", a, key, req);
        assertThat(first.getResponse().getStatus()).isEqualTo(201);
        assertThat(second.getResponse().getStatus()).isEqualTo(201);
        assertThat(second.getResponse().getHeader("Idempotent-Replayed")).isEqualTo("true");
        assertThat(first.getResponse().getHeader("Idempotent-Replayed")).isNull();
        assertThat(body(second).get("reference").asText()).isEqualTo(body(first).get("reference").asText());
        assertThat(balanceOf(a)).isEqualByComparingTo("900.00");
        assertThat(balanceOf(b)).isEqualByComparingTo("100.00");
        assertThat(body(getJson("/api/transactions?type=TRANSFER", a.token())).get("totalElements").asInt()).isEqualTo(1);
    }

    @Test
    void reusingAKeyWithADifferentRequestIsRejected() throws Exception {
        Customer a = fundedCustomer("1000.00");
        Customer b = newCustomer();
        String key = UUID.randomUUID().toString();
        assertThat(money("transfer", a, key, Map.of("targetAccountNumber", b.accountNumber(), "amount", "100.00", "pin", a.pin()))
                .getResponse().getStatus()).isEqualTo(201);
        MvcResult other = money("transfer", a, key, Map.of("targetAccountNumber", b.accountNumber(), "amount", "200.00", "pin", a.pin()));
        assertThat(other.getResponse().getStatus()).isEqualTo(422);
        assertThat(errorCode(other)).isEqualTo("IDEMPOTENCY_KEY_REUSED");
        assertThat(balanceOf(a)).isEqualByComparingTo("900.00");
    }

    @Test
    void sameKeyByDifferentUsersAreIndependent() throws Exception {
        Customer a = newCustomer();
        Customer b = newCustomer();
        String key = UUID.randomUUID().toString();
        assertThat(money("deposit", a, key, Map.of("amount", "10", "pin", a.pin())).getResponse().getStatus()).isEqualTo(201);
        assertThat(money("deposit", b, key, Map.of("amount", "10", "pin", b.pin())).getResponse().getStatus()).isEqualTo(201);
        assertThat(balanceOf(b)).isEqualByComparingTo("10.00");
    }

    @Test
    void failedValidationDoesNotConsumeTheKey() throws Exception {
        Customer c = newCustomer();
        String key = UUID.randomUUID().toString();
        MvcResult wrongPin = money("deposit", c, key, Map.of("amount", "10", "pin", "1357"));
        assertThat(wrongPin.getResponse().getStatus()).isEqualTo(403);
        MvcResult retry = money("deposit", c, key, Map.of("amount", "10", "pin", c.pin()));
        assertThat(retry.getResponse().getStatus()).isEqualTo(201);
        assertThat(balanceOf(c)).isEqualByComparingTo("10.00");
    }

    @Test
    void wrongPinIsRejectedAndLocksAfterRepeatedFailures() throws Exception {
        Customer c = fundedCustomer("100.00");
        for (int i = 0; i < 2; i++) {
            MvcResult r = money("withdraw", c, UUID.randomUUID().toString(), Map.of("amount", "5", "pin", "1357"));
            assertThat(r.getResponse().getStatus()).isEqualTo(403);
            assertThat(errorCode(r)).isEqualTo("PIN_INVALID");
        }
        MvcResult third = money("withdraw", c, UUID.randomUUID().toString(), Map.of("amount", "5", "pin", "1357"));
        assertThat(third.getResponse().getStatus()).isEqualTo(423);
        assertThat(errorCode(third)).isEqualTo("PIN_LOCKED");
        MvcResult correctButLocked = money("withdraw", c, UUID.randomUUID().toString(), Map.of("amount", "5", "pin", c.pin()));
        assertThat(correctButLocked.getResponse().getStatus()).isEqualTo(423);
        assertThat(balanceOf(c)).isEqualByComparingTo("100.00");
    }

    @Test
    void transactionsRequireAPin() throws Exception {
        String s = uniqueSuffix();
        postJson("/api/auth/register", null, Map.of("fullName", "No Pin", "email", "nopin" + s + "@example.com",
                "phone", "+1415558" + String.format("%04d", Integer.parseInt(s) % 10000), "password", PASSWORD));
        String token = loginToken("nopin" + s + "@example.com", PASSWORD);
        MvcResult r = call(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post("/api/transactions/deposit")
                .header("Authorization", "Bearer " + token).header("Idempotency-Key", UUID.randomUUID().toString())
                .contentType("application/json").content("{\"amount\":\"10\",\"pin\":\"4829\"}"));
        assertThat(r.getResponse().getStatus()).isEqualTo(409);
        assertThat(errorCode(r)).isEqualTo("PIN_NOT_SET");
    }

    @Test
    void pinPolicyAndUpdate() throws Exception {
        Customer c = newCustomer();
        assertThat(postJson("/api/accounts/me/pin", c.token(), Map.of("pin", "1357", "password", PASSWORD)).getResponse().getStatus()).isEqualTo(409);
        assertThat(putJson("/api/accounts/me/pin", c.token(), Map.of("currentPin", c.pin(), "newPin", "1234", "password", PASSWORD))
                .getResponse().getStatus()).isEqualTo(400);
        assertThat(putJson("/api/accounts/me/pin", c.token(), Map.of("currentPin", c.pin(), "newPin", "7391", "password", PASSWORD))
                .getResponse().getStatus()).isEqualTo(204);
        assertThat(money("deposit", c, UUID.randomUUID().toString(), Map.of("amount", "10", "pin", c.pin())).getResponse().getStatus()).isEqualTo(403);
        assertThat(money("deposit", c, UUID.randomUUID().toString(), Map.of("amount", "10", "pin", "7391")).getResponse().getStatus()).isEqualTo(201);
    }

    @Test
    void historySupportsPaginationFilteringAndSorting() throws Exception {
        Customer c = newCustomer();
        deposit(c, "10.00");
        deposit(c, "20.00");
        deposit(c, "30.00");
        money("withdraw", c, UUID.randomUUID().toString(), Map.of("amount", "5.00", "pin", c.pin()));

        JsonNode page0 = body(getJson("/api/transactions?size=3&page=0", c.token()));
        assertThat(page0.get("totalElements").asInt()).isEqualTo(4);
        assertThat(page0.get("totalPages").asInt()).isEqualTo(2);
        assertThat(page0.get("content")).hasSize(3);
        assertThat(body(getJson("/api/transactions?size=3&page=1", c.token())).get("content")).hasSize(1);

        assertThat(body(getJson("/api/transactions?type=DEPOSIT", c.token())).get("totalElements").asInt()).isEqualTo(3);
        assertThat(body(getJson("/api/transactions?type=WITHDRAWAL", c.token())).get("totalElements").asInt()).isEqualTo(1);
        assertThat(body(getJson("/api/transactions?minAmount=15&maxAmount=25", c.token())).get("totalElements").asInt()).isEqualTo(1);

        JsonNode sorted = body(getJson("/api/transactions?sort=amount,asc&size=10", c.token())).get("content");
        assertThat(sorted.get(0).get("amount").decimalValue()).isEqualByComparingTo("5.00");
        assertThat(sorted.get(3).get("amount").decimalValue()).isEqualByComparingTo("30.00");

        assertThat(getJson("/api/transactions?status=NOT_A_STATUS", c.token()).getResponse().getStatus()).isEqualTo(400);
        // arbitrary sort columns are ignored rather than passed to the database
        assertThat(getJson("/api/transactions?sort=passwordHash,asc", c.token()).getResponse().getStatus()).isEqualTo(200);
        assertThat(body(getJson("/api/transactions?size=5000", c.token())).get("size").asInt()).isLessThanOrEqualTo(100);
    }

    @Test
    void customersCannotSeeOthersTransactions() throws Exception {
        Customer a = newCustomer();
        Customer b = newCustomer();
        String ref = body(deposit(a, "10")).get("reference").asText();
        MvcResult r = getJson("/api/transactions/" + ref, b.token());
        assertThat(r.getResponse().getStatus()).isEqualTo(404);
        assertThat(errorCode(r)).isEqualTo("TRANSACTION_NOT_FOUND");
    }

    @Test
    void largeTransferWaitsForApprovalAndCanBeApproved() throws Exception {
        Customer a = fundedCustomer("3000000.00");
        Customer b = newCustomer();
        MvcResult r = transfer(a, b, "1000000.00");
        assertThat(r.getResponse().getStatus()).isEqualTo(202);
        assertThat(body(r).get("status").asText()).isEqualTo("PENDING");
        String ref = body(r).get("reference").asText();
        assertThat(balanceOf(a)).isEqualByComparingTo("3000000.00");
        assertThat(balanceOf(b)).isEqualByComparingTo("0.00");

        String admin = adminToken();
        MvcResult approved = postJson("/api/admin/transactions/" + ref + "/approve", admin, Map.of());
        assertThat(approved.getResponse().getStatus()).isEqualTo(200);
        assertThat(body(approved).get("status").asText()).isEqualTo("SUCCESS");
        assertThat(balanceOf(a)).isEqualByComparingTo("2000000.00");
        assertThat(balanceOf(b)).isEqualByComparingTo("1000000.00");

        MvcResult again = postJson("/api/admin/transactions/" + ref + "/approve", admin, Map.of());
        assertThat(again.getResponse().getStatus()).isEqualTo(409);
        assertThat(errorCode(again)).isEqualTo("INVALID_STATE_TRANSITION");
    }

    @Test
    void pendingTransferCanBeCancelledByOwnerOnly() throws Exception {
        Customer a = fundedCustomer("2000000.00");
        Customer b = newCustomer();
        String ref = body(transfer(a, b, "1500000.00")).get("reference").asText();
        assertThat(postJson("/api/transactions/" + ref + "/cancel", b.token(), Map.of()).getResponse().getStatus()).isEqualTo(404);
        MvcResult cancelled = postJson("/api/transactions/" + ref + "/cancel", a.token(), Map.of());
        assertThat(cancelled.getResponse().getStatus()).isEqualTo(200);
        assertThat(body(cancelled).get("status").asText()).isEqualTo("CANCELLED");
        assertThat(postJson("/api/admin/transactions/" + ref + "/approve", adminToken(), Map.of()).getResponse().getStatus()).isEqualTo(409);
        assertThat(balanceOf(a)).isEqualByComparingTo("2000000.00");
    }

    @Test
    void adminCanReverseASuccessfulTransfer() throws Exception {
        Customer a = fundedCustomer("1000.00");
        Customer b = newCustomer();
        String ref = body(transfer(a, b, "400.00")).get("reference").asText();
        MvcResult rev = postJson("/api/admin/transactions/" + ref + "/reverse", adminToken(), Map.of("reason", "Customer dispute"));
        assertThat(rev.getResponse().getStatus()).isEqualTo(200);
        assertThat(body(rev).get("status").asText()).isEqualTo("REVERSED");
        assertThat(balanceOf(a)).isEqualByComparingTo("1000.00");
        assertThat(balanceOf(b)).isEqualByComparingTo("0.00");
        assertThat(postJson("/api/admin/transactions/" + ref + "/reverse", adminToken(), Map.of("reason", "again")).getResponse().getStatus()).isEqualTo(409);
    }

    @Test
    void reversalFailsWhenCounterpartyHasSpentTheMoney() throws Exception {
        Customer a = fundedCustomer("500.00");
        Customer b = newCustomer();
        String ref = body(transfer(a, b, "500.00")).get("reference").asText();
        money("withdraw", b, UUID.randomUUID().toString(), Map.of("amount", "500.00", "pin", b.pin()));
        MvcResult rev = postJson("/api/admin/transactions/" + ref + "/reverse", adminToken(), Map.of("reason", "test"));
        assertThat(rev.getResponse().getStatus()).isEqualTo(422);
        assertThat(errorCode(rev)).isEqualTo("INSUFFICIENT_FUNDS");
        assertThat(balanceOf(b)).isEqualByComparingTo("0.00");
        assertThat(balanceOf(a)).isEqualByComparingTo("0.00");
    }

    @Test
    void frozenAccountsCannotTransact() throws Exception {
        Customer a = fundedCustomer("100.00");
        Customer b = newCustomer();
        String admin = adminToken();
        assertThat(postJson("/api/admin/accounts/" + a.accountNumber() + "/freeze", admin, Map.of()).getResponse().getStatus()).isEqualTo(204);
        MvcResult r = transfer(a, b, "10");
        assertThat(r.getResponse().getStatus()).isEqualTo(403);
        assertThat(errorCode(r)).isEqualTo("ACCOUNT_FROZEN");
        assertThat(transfer(b, a, "1").getResponse().getStatus()).isIn(403, 422);   // b has no funds; destination frozen is checked first
        assertThat(postJson("/api/admin/accounts/" + a.accountNumber() + "/unfreeze", admin, Map.of()).getResponse().getStatus()).isEqualTo(204);
        assertThat(transfer(a, b, "10").getResponse().getStatus()).isEqualTo(201);
    }

    @Test
    void statementIsGeneratedAsCsvAndSanitised() throws Exception {
        Customer c = newCustomer();
        money("deposit", c, UUID.randomUUID().toString(), Map.of("amount", "10", "pin", c.pin(), "description", "=HYPERLINK(\"http://evil\")"));
        MvcResult r = getJson("/api/accounts/me/statement", c.token());
        assertThat(r.getResponse().getStatus()).isEqualTo(200);
        String csv = r.getResponse().getContentAsString();
        assertThat(csv).contains("SIMULATED").contains("reference,created_at").contains("\"'=HYPERLINK");
        assertThat(r.getResponse().getContentType()).contains("text/csv");
        assertThat(new BigDecimal("1")).isNotNull();
    }
}
