package com.kivubank.support;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

/** Shared helpers for full-stack tests (real Spring context, Flyway-migrated H2 database in MySQL mode). */
@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureObservability
@ActiveProfiles("test")
public abstract class IntegrationTestBase {
    public static final String PASSWORD = "Str0ng-Passw0rd!x";
    public static final String ADMIN_EMAIL = "admin@kivubank.test";
    public static final String ADMIN_PASSWORD = "Adm1n-Test-Passw0rd!";
    private static final AtomicInteger SEQ = new AtomicInteger(1000);

    @Autowired protected MockMvc mvc;
    @Autowired protected ObjectMapper json;

    public record Customer(Long id, String email, String phone, String token, String accountNumber, String pin) {
    }

    protected String uniqueSuffix() {
        return String.valueOf(SEQ.incrementAndGet());
    }

    // ---- requests --------------------------------------------------------------------------------------------
    protected MockHttpServletRequestBuilder authed(MockHttpServletRequestBuilder b, String token) {
        return token == null ? b : b.header("Authorization", "Bearer " + token);
    }

    protected MvcResult call(MockHttpServletRequestBuilder b) throws Exception {
        return mvc.perform(b).andReturn();
    }

    protected MvcResult postJson(String url, String token, Object body) throws Exception {
        return call(authed(post(url), token).contentType(MediaType.APPLICATION_JSON).content(json.writeValueAsString(body)));
    }

    protected MvcResult patchJson(String url, String token, Object body) throws Exception {
        return call(authed(patch(url), token).contentType(MediaType.APPLICATION_JSON).content(json.writeValueAsString(body)));
    }

    protected MvcResult putJson(String url, String token, Object body) throws Exception {
        return call(authed(put(url), token).contentType(MediaType.APPLICATION_JSON).content(json.writeValueAsString(body)));
    }

    protected MvcResult getJson(String url, String token) throws Exception {
        return call(authed(get(url), token));
    }

    protected MvcResult money(String op, Customer c, String key, Map<String, Object> body) throws Exception {
        MockHttpServletRequestBuilder b = authed(post("/api/transactions/" + op), c.token()).contentType(MediaType.APPLICATION_JSON)
                .content(json.writeValueAsString(body));
        if (key != null) {
            b.header("Idempotency-Key", key);
        }
        return call(b);
    }

    protected MvcResult deposit(Customer c, String amount) throws Exception {
        return money("deposit", c, UUID.randomUUID().toString(), Map.of("amount", amount, "pin", c.pin()));
    }

    protected MvcResult transfer(Customer from, Customer to, String amount) throws Exception {
        return money("transfer", from, UUID.randomUUID().toString(),
                Map.of("targetAccountNumber", to.accountNumber(), "amount", amount, "pin", from.pin()));
    }

    // ---- fixtures --------------------------------------------------------------------------------------------
    protected JsonNode body(MvcResult r) throws Exception {
        String s = r.getResponse().getContentAsString();
        return s.isEmpty() ? json.createObjectNode() : json.readTree(s);
    }

    protected String loginToken(String identifier, String password) throws Exception {
        MvcResult r = postJson("/api/auth/login", null, Map.of("identifier", identifier, "password", password));
        if (r.getResponse().getStatus() != 200) {
            throw new IllegalStateException("Login failed for " + identifier + ": " + r.getResponse().getContentAsString());
        }
        return body(r).get("accessToken").asText();
    }

    protected String adminToken() throws Exception {
        return loginToken(ADMIN_EMAIL, ADMIN_PASSWORD);
    }

    /** Registers a customer, logs in and sets a PIN. */
    protected Customer newCustomer() throws Exception {
        String n = uniqueSuffix();
        String email = "cust" + n + "@example.com";
        String phone = "+1415555" + String.format("%04d", Integer.parseInt(n) % 10000);
        MvcResult reg = postJson("/api/auth/register", null,
                Map.of("fullName", "Test Person", "email", email, "phone", phone, "password", PASSWORD));
        if (reg.getResponse().getStatus() != 201) {
            throw new IllegalStateException("Registration failed: " + reg.getResponse().getContentAsString());
        }
        JsonNode profile = body(reg);
        String token = loginToken(email, PASSWORD);
        String pin = "4829";
        MvcResult pinResult = postJson("/api/accounts/me/pin", token, Map.of("pin", pin, "password", PASSWORD));
        if (pinResult.getResponse().getStatus() != 204) {
            throw new IllegalStateException("PIN creation failed: " + pinResult.getResponse().getContentAsString());
        }
        return new Customer(profile.get("id").asLong(), email, phone, token, profile.get("accountNumber").asText(), pin);
    }

    protected Customer fundedCustomer(String amount) throws Exception {
        Customer c = newCustomer();
        MvcResult r = deposit(c, amount);
        if (r.getResponse().getStatus() != 201) {
            throw new IllegalStateException("Funding failed: " + r.getResponse().getContentAsString());
        }
        return c;
    }

    protected String staffToken(String role) throws Exception {
        String n = uniqueSuffix();
        String email = "staff" + n + "@example.com";
        MvcResult r = postJson("/api/admin/users", adminToken(), Map.of("fullName", "Staff Member", "email", email,
                "phone", "+1415556" + String.format("%04d", Integer.parseInt(n) % 10000), "password", PASSWORD, "role", role));
        if (r.getResponse().getStatus() != 201) {
            throw new IllegalStateException("Staff creation failed: " + r.getResponse().getContentAsString());
        }
        return loginToken(email, PASSWORD);
    }

    protected BigDecimal balanceOf(Customer c) throws Exception {
        return new BigDecimal(body(getJson("/api/accounts/me", c.token())).get("balance").asText());
    }

    protected String errorCode(MvcResult r) throws Exception {
        return body(r).path("code").asText();
    }
}
