package com.kivubank.security;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kivubank.config.KivuBankProperties;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import org.junit.jupiter.api.Test;

class RateLimitFilterTest {

    /** Clock whose time can be advanced manually. */
    static class MutableClock extends Clock {
        private Instant now = Instant.parse("2026-01-01T00:00:00Z");

        void advanceSeconds(long s) {
            now = now.plusSeconds(s);
        }

        @Override public ZoneId getZone() { return ZoneOffset.UTC; }
        @Override public Clock withZone(ZoneId zone) { return this; }
        @Override public Instant instant() { return now; }
    }

    @Test
    void allowsUpToLimitThenBlocksAndRecoversAfterWindow() {
        MutableClock clock = new MutableClock();
        RateLimitFilter filter = new RateLimitFilter(new KivuBankProperties.RateLimit(true, 3, 3, 3, 3, 3), clock, new ObjectMapper());
        assertThat(filter.allow("1.2.3.4|login", 3)).isTrue();
        assertThat(filter.allow("1.2.3.4|login", 3)).isTrue();
        assertThat(filter.allow("1.2.3.4|login", 3)).isTrue();
        assertThat(filter.allow("1.2.3.4|login", 3)).isFalse();
        assertThat(filter.allow("5.6.7.8|login", 3)).as("other client unaffected").isTrue();
        clock.advanceSeconds(61);
        assertThat(filter.allow("1.2.3.4|login", 3)).as("window slid").isTrue();
    }
}
