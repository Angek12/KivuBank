# Security policy

KivuBank is a **simulation / portfolio project**; it is not intended to protect real financial data.
If you find a vulnerability in the code, please open a private security advisory on the repository host
(or contact the repository owner through the contact details on their profile). Do not include real personal data in reports.

Never commit secrets: the JWT key, database passwords and admin credentials are provided through environment variables (see `.env.example`).
