# First-run checklist

The code was written and reviewed without access to a JDK/Maven runtime, so the **first thing to do is build and test it
on your machine** and fix anything the compiler or the tests report. Work through this list in order.

1. `chmod +x mvnw && ./mvnw -B clean compile` — fix any compile error first (most likely: a missing import or a library version mismatch).
2. `./mvnw -B test -Dtest='com.kivubank.unit.*,com.kivubank.security.*,com.kivubank.anomaly.*,com.kivubank.transaction.*'` — pure unit tests, no Spring context.
3. `./mvnw -B test -Dtest=PersistenceConstraintsTest` — validates the Flyway schema against the JPA mappings (H2, MySQL mode).
   If Flyway complains about `DATETIME(6)` on H2, change the test datasource to `MODE=MySQL;NON_KEYWORDS=...` or use Testcontainers MySQL.
4. `./mvnw -B verify` — the full suite (auth, RBAC, transactions, idempotency, concurrency, reconciliation, USSD, audit, ops).
5. Optional schema check: run once with `KIVUBANK_DDL_AUTO=validate` to confirm entities match the migrations.
6. `docker compose up --build`, open `http://localhost:8080`, sign in with the bootstrap admin, open `/swagger-ui.html`.
7. With `SPRING_PROFILES_ACTIVE=demo`, copy the demo credentials printed in the log, log in as a demo customer and try a transfer, the USSD tab,
   then as admin: Overview, Incidents, Reconciliation → *Simulate settlement* → *Run*, Anomalies.
8. Run the tests against real MySQL (Testcontainers) before trusting the locking behaviour.
9. Put your name in the second copyright line of `LICENSE`.

## If a test fails, where to look
| Symptom | Likely cause |
|---|---|
| Context fails to start: "KIVUBANK_JWT_SECRET" | Secret missing/short – tests set it in `application-test.yml` |
| `Schema-validation` / "wrong column type" | You enabled `KIVUBANK_DDL_AUTO=validate`; compare entity vs `V1/V2` SQL |
| Concurrency test timeouts | DB lock timeout / pool exhaustion – check `LOCK_TIMEOUT` in the H2 URL and Hikari pool size |
| Notification tests flaky | Login/PIN/statement notifications are asynchronous; the tests use Awaitility |
| `/actuator/prometheus` 404 in tests | `@AutoConfigureObservability` must be present on the test base class |
