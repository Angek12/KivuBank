# Third-party notices

KivuBank is a derivative work of **BankingPortal-API** by Abhishek Tiwari, licensed under the MIT License
(see `LICENSE`, which is retained unchanged apart from an added copyright line for the modifications).
Source: https://github.com/abhi9720/BankingPortal-API

The project depends on open-source libraries that keep their own licences. Main runtime dependencies (licences as published by each project):

| Library | Licence |
|---|---|
| Spring Boot, Spring Framework, Spring Security, Spring Data | Apache-2.0 |
| Hibernate ORM | LGPL-2.1 (as published by the Hibernate project) |
| Flyway Community | Apache-2.0 |
| MySQL Connector/J | GPL-2.0 with FOSS exception |
| JJWT | Apache-2.0 |
| springdoc-openapi, Swagger annotations/UI | Apache-2.0 |
| Micrometer | Apache-2.0 |
| libphonenumber | Apache-2.0 |
| Jackson | Apache-2.0 |
| H2 Database (tests only) | MPL-2.0 / EPL-1.0 |
| JUnit 5, Mockito, AssertJ, Awaitility | EPL-2.0 / MIT / Apache-2.0 |

Please verify exact licence terms for the versions you ship (`./mvnw dependency:tree`) before redistributing a build.
