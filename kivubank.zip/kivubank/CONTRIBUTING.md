# Contributing

1. `./mvnw verify` must pass (tests, JaCoCo) and `./mvnw spotbugs:check` must be clean.
2. Money-moving code needs tests for success, failure, idempotent replay and concurrency.
3. Never log or audit passwords, PINs, tokens or full secrets; use synthetic data only.
4. Keep the OpenAPI annotations and the README in step with API changes.
5. Keep `LICENSE` and the attribution in `README.md` / `THIRD_PARTY_NOTICES.md` intact.
