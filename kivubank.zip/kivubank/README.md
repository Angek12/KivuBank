# KivuBank

**A simulated digital banking platform and operations portfolio project.**
Spring Boot · MySQL · JWT · RBAC · idempotent payments · audit trail · monitoring dashboard · incident management ·
reconciliation simulator · USSD simulator · notifications · experimental anomaly detection.

> **KivuBank is a learning/portfolio project. It does not handle real money, is not connected to any bank, telecom
> operator or payment provider, and all customers, accounts and transactions are synthetic.**
> Components that are simulated or experimental are labelled as such in the UI, the API and this document.

---

## 1. Provenance and licence (please read)

KivuBank is a **derivative work of [abhi9720/BankingPortal-API](https://github.com/abhi9720/BankingPortal-API)**
(MIT licence, Copyright (c) 2023 Abhishek Tiwari). The upstream project is the origin of the idea, the scope
(registration/login, JWT, accounts, PIN, deposits, withdrawals, transfers, history) and the base domain model.
The original `LICENSE` is kept unchanged, with a second copyright line added for the KivuBank modifications.
The implementation has been restructured and largely rewritten, but it is **not** the work of a single author from scratch
and must not be presented as such. If you publish this repository, keep `LICENSE` and this section, and fill in your name
on the second copyright line.

| | |
|---|---|
| **Original / base (upstream)** | Project idea and scope; user + account + PIN + transaction domain model; registration, login, JWT, PIN, deposit, withdraw, transfer and history features (re-implemented); `libphonenumber` phone validation; Maven wrapper; MIT licence |
| **Added or substantially modified in KivuBank** | Feature-first package structure (`com.kivubank`); BigDecimal money; transaction state machine; Idempotency-Key support with persistent records; pessimistic-locking transfers; manual-review (maker-checker) workflow, reversals; Flyway migrations and DB constraints; RBAC (4 roles); hardened JWT (HS512, revocation, password-change invalidation); account/PIN lockout; rate limiting; audit log; secure error model; operations dashboard and monitoring endpoints; incident management; OpenAPI documentation; test suite; Docker; GitHub Actions; notifications abstraction; web UI |
| **Experimental / simulated** | Anomaly detection (Isolation Forest on synthetic data); simulated payment provider and reconciliation; USSD `*123#` simulator; "mobile" channel concept; simulated notification provider; demo data seeder |

### Removed from the upstream project
OTP login and OTP password reset, IP-geolocation lookups, SMTP e-mail service (replaced by the notification provider
abstraction), Redis cache, `double` money and the "multiples of 100" rule, India-specific defaults (branch/IFSC), hot-linked
logos, the Postman collection, promotional README content/GIFs/links to the separate UI repository, the generic
`CODE_OF_CONDUCT`/`CONTRIBUTING`/issue templates, the original `SECURITY.md` (it named the upstream author as contact),
the PMD plugin configuration (pointed at non-existent rule files), Lombok and MapStruct. A password-reset flow is
**not** implemented yet (see [Limitations](#14-limitations)).

> Note: the upstream `application.properties.sample` contained what looks like a real mail app password. It was **not**
> carried over. If you ever used that value, treat it as compromised.

---

## 2. Problem being solved

Most banking demos stop at "CRUD with a balance". KivuBank focuses on what makes payment systems hard and what
operations teams worry about: **never losing or duplicating money**, **proving what happened** (audit), **seeing the system's
health**, **handling incidents**, **reconciling against an external provider**, and **offering several channels** over the same core.

## 3. Features

* **Accounts & auth** – register, login (e-mail or account number), logout with token revocation, change password, lockout after repeated failures.
* **Money movement** – deposit, withdraw, transfer; unique traceable references (`KB20261003-7XQ4M2PD9T`); decimal arithmetic (`DECIMAL(19,2)`).
* **Transaction state machine** – `PENDING → PROCESSING → SUCCESS → REVERSED`, plus `FAILED` and `CANCELLED`. Illegal transitions are rejected in code.
* **Idempotency** – every money POST requires an `Idempotency-Key`. Persistent records with `UNIQUE(user_id, key)`; safe under concurrent duplicates; same key + different body → `422`.
* **Concurrency safety** – `SELECT … FOR UPDATE` on accounts in ascending id order (no deadlocks), `@Version`, and `CHECK (balance >= 0)` as the last line of defence.
* **Manual review** – transfers ≥ the configured threshold stay `PENDING` until an ADMIN approves or the customer cancels. Admins can reverse successful transactions.
* **History** – pagination, filtering (status, type, date range, amount range, reference), whitelisted sorting, statement export (CSV, formula-injection safe).
* **RBAC** – `CUSTOMER`, `SUPPORT_AGENT`, `ADMIN`, `AUDITOR` enforced with `@PreAuthorize`.
* **Security** – BCrypt, password and PIN policies, PIN lockout, rate limiting, strict validation, uniform error body without internals, security headers.
* **Audit log** – logins (and failures), account creation, transfers (created/completed/failed), deposits, withdrawals, PIN/password changes, admin actions, incidents, reconciliation.
* **Operations dashboard** – health, availability, transaction counts and success rate, average response time, active users, incidents, recent audit events, alerts, hourly trend.
* **Incident management** – full lifecycle (`OPEN → INVESTIGATING → MITIGATED → RESOLVED → CLOSED`) with root cause and resolution.
* **Monitoring** – Actuator health (+ custom ledger check), Micrometer metrics, Prometheus endpoint, JVM and HTTP summaries.
* **API documentation** – OpenAPI/Swagger UI with security scheme, parameters, examples and standard error responses.
* **Reconciliation simulator** – simulated provider (`SUCCESS/FAILED/PENDING/TIMEOUT`) and a reconciliation engine reporting matched, missing, amount-mismatch, duplicate and status-mismatch items.
* **Digital channels** – responsive web UI, "mobile" channel header, USSD `*123#` simulator.
* **Notifications** – provider abstraction, simulated provider, in-app inbox.
* **Experimental AI** – Isolation Forest trained on synthetic data with scores, flags and plain-language reasons.

## 4. Architecture

```mermaid
flowchart LR
  subgraph Clients
    WEB[Web UI<br/>customer + operations]
    MOB[Mobile client concept<br/>X-Client-Channel: MOBILE]
    USSD[USSD simulator *123#]
  end
  WEB & MOB & USSD --> API

  subgraph KivuBank["KivuBank (Spring Boot)"]
    API[REST controllers<br/>validation · RBAC · rate limit · JWT]
    API --> FAC[TransactionFacade<br/>idempotency + PIN check]
    FAC --> PROC[TransactionProcessor<br/>one DB tx, row locks, state machine]
    API --> OPS[Ops dashboard · Incidents · Audit]
    API --> RECON[Reconciliation service]
    PROC -- domain events --> AUD[Audit listener]
    PROC -- domain events --> NOT[Notification listener<br/>provider abstraction]
    PROC -- domain events --> ANOM[Anomaly scoring<br/>Isolation Forest · synthetic · EXPERIMENTAL]
    RECON --> GW[SimulatedPaymentGateway]
  end
  PROC & OPS & RECON & AUD --> DB[(MySQL<br/>Flyway migrations)]
  GW --> SIM[(Simulated provider ledger)]
  KivuBank -. metrics/health .-> ACT[Actuator · Micrometer · Prometheus]
```

**Package layout (`com.kivubank`)**: `auth`, `user`, `account`, `transaction`, `audit`, `notification`, `event`, `anomaly`,
`incident`, `ops`, `reconciliation`, `channels`, `security`, `config`, `common`, `bootstrap`.

**Money movement, step by step** (`POST /api/transactions/transfer`):
1. Rate limit + JWT filter + role check (`CUSTOMER`).
2. `IdempotencyService.begin` inserts `IN_PROGRESS` (unique per user+key). Duplicates replay the stored response (`Idempotent-Replayed: true`), or get `409` while the original is in flight.
3. PIN verified (lockout counters persist in their own transaction, even when the payment is rejected).
4. One database transaction: lock both accounts (ordered), create `PENDING` → `PROCESSING` → `SUCCESS`/`FAILED`, update balances and the transaction row together.
5. After commit: domain event → audit entry, notifications, anomaly score. Failures here never undo the payment.
6. Response stored against the idempotency key.

## 5. Technology stack

Java 17 · Spring Boot 3.4 · Spring Security · Spring Data JPA/Hibernate · MySQL 8 · Flyway · JJWT 0.12 · springdoc-openapi ·
Micrometer + Prometheus · libphonenumber · JUnit 5 / Mockito / AssertJ / Awaitility · H2 (MySQL mode, tests only) ·
Docker / Docker Compose · GitHub Actions (build, test, SpotBugs, CodeQL, dependency review, Trivy) · vanilla JS/CSS front end.

## 6. Setup

### Option A – Docker Compose (MySQL + app)
```bash
cp .env.example .env
openssl rand -base64 64        # put the output in KIVUBANK_JWT_SECRET
# set KIVUBANK_DB_PASSWORD, MYSQL_ROOT_PASSWORD, KIVUBANK_BOOTSTRAP_ADMIN_EMAIL / _PASSWORD in .env
docker compose up --build
```
Open <http://localhost:8080> (UI) · <http://localhost:8080/swagger-ui.html> (API docs).
For synthetic demo data add `SPRING_PROFILES_ACTIVE=demo` to `.env`; demo credentials are printed once in the application log.

### Option B – local JDK + MySQL
```bash
# MySQL 8: create database `kivubank` and a user, then:
export KIVUBANK_DB_PASSWORD=... KIVUBANK_JWT_SECRET=$(openssl rand -base64 64)
export KIVUBANK_BOOTSTRAP_ADMIN_EMAIL=admin@kivubank.example KIVUBANK_BOOTSTRAP_ADMIN_PASSWORD='choose-a-strong-one-1!'
./mvnw spring-boot:run            # add -Dspring-boot.run.profiles=demo for synthetic data
```
Flyway creates the schema on start-up (`src/main/resources/db/migration`).

### Environment variables
| Variable | Required | Purpose |
|---|---|---|
| `KIVUBANK_JWT_SECRET` | **yes** | Base64 HS512 key, ≥ 64 bytes. The app refuses to start without it. |
| `KIVUBANK_DB_URL` / `_USER` / `_PASSWORD` | yes | JDBC URL (default `jdbc:mysql://localhost:3306/kivubank…`), user, password |
| `KIVUBANK_BOOTSTRAP_ADMIN_EMAIL` / `_PASSWORD` / `_PHONE` | first run | Creates the first ADMIN if none exists (password must satisfy the policy) |
| `KIVUBANK_DEMO_PASSWORD` | optional | Password for demo users when profile `demo` is active (otherwise generated) |
| `KIVUBANK_ALLOWED_ORIGINS` | optional | Comma-separated CORS origins (default: none, same-origin only) |
| `KIVUBANK_DDL_AUTO` | optional | `none` (default) or `validate` to check entities against the Flyway schema |
| `PORT`, `SPRING_PROFILES_ACTIVE` | optional | Server port; `demo` loads synthetic data |

Tunables live in `application.yml` under `kivubank.*` (limits, review threshold, lockouts, rate limits, anomaly model).

## 7. API overview

Full interactive documentation: **`/swagger-ui.html`** (OpenAPI JSON at `/v3/api-docs`). Authenticate with `POST /api/auth/login`
and send `Authorization: Bearer <token>`. Errors share one shape: `{timestamp,status,code,message,path,requestId,violations?}`.

| Area | Endpoints | Roles |
|---|---|---|
| Auth | `POST /api/auth/register · login · logout · change-password`, `GET /api/auth/me` | public / any |
| Account | `GET /api/accounts/me`, `POST·PUT /api/accounts/me/pin`, `GET /api/accounts/lookup/{n}`, `GET /api/accounts/me/statement` | CUSTOMER |
| Transactions | `POST /api/transactions/deposit · withdraw · transfer` (**Idempotency-Key**), `GET /api/transactions`, `GET /{ref}`, `POST /{ref}/cancel` | CUSTOMER |
| Notifications | `GET /api/notifications`, `/unread-count`, `POST /{id}/read` | CUSTOMER |
| Staff | `GET /api/admin/transactions`, `POST …/{ref}/approve · reverse` (ADMIN), `GET/POST /api/admin/users`, `/api/admin/accounts` (+freeze) | ADMIN / SUPPORT / AUDITOR (varies) |
| Audit | `GET /api/admin/audit-events` | ADMIN, AUDITOR |
| Ops | `GET /api/ops/dashboard · health · metrics · transactions/trend` | staff |
| Incidents | `POST/GET/PATCH /api/incidents` | ADMIN, SUPPORT (write); AUDITOR (read) |
| Reconciliation (sim) | `POST /api/admin/simulator/provider/payments`, `/api/admin/reconciliation/simulate-settlement · runs`, `GET …/runs/{id}/items` | ADMIN (run), AUDITOR (read) |
| Anomalies (exp.) | `GET /api/admin/anomalies`, `/model`, `POST /evaluate` | staff |
| USSD (sim) | `POST /api/ussd/session` | public + PIN, rate limited |

Example:
```bash
curl -s -X POST localhost:8080/api/transactions/transfer \
  -H "Authorization: Bearer $TOKEN" -H "Idempotency-Key: $(uuidgen)" -H 'Content-Type: application/json' \
  -d '{"targetAccountNumber":"1043820917","amount":"1500.00","pin":"4829","description":"Rent share"}'
```

## 8. Testing

```bash
./mvnw verify          # unit + integration tests (H2 in MySQL mode, Flyway-migrated) + JaCoCo report
./mvnw spotbugs:check  # static analysis
```
Coverage by area: state machine, policies, JWT, rate limiter, anomaly model (unit) · repository constraints (`@DataJpaTest`) ·
auth/RBAC, transactions, validation, incidents, reconciliation, USSD, audit/notifications, anomaly/ops/OpenAPI (full-stack `MockMvc`) ·
**concurrency** (20 parallel transfers cannot overdraw; same idempotency key fired 10× moves money once; opposing transfers do not deadlock).

## 9. CI/CD

`.github/workflows/ci.yml`: compile → `mvn verify` (tests + JaCoCo, reports uploaded, summary in the job page) → package JAR →
SpotBugs → dependency review (PRs) → Docker build → Trivy image scan (HIGH/CRITICAL fail the job). `codeql.yml` runs CodeQL weekly and on PRs.
There is **no deployment step**; nothing pretends to deploy.

## 10. Security features

BCrypt (strength configurable) · password policy (length, classes, no name/e-mail, common list) · PIN policy + attempt lockout ·
account lockout · short-lived HS512 JWT with `jti`, issuer, role, revocation on logout, invalidation on password change/disable ·
no default credentials (bootstrap admin from env) · RBAC on every route (`denyAll` fallback) · rate limiting · input validation on every DTO and path/query parameter ·
no entity binding (no mass assignment) · errors never expose stack traces or SQL · audit trail with request ids · statement CSV formula-injection protection ·
constant-time-ish login for unknown users · security headers · secrets only via environment.

## 11. Monitoring

`/actuator/health` (public, minimal; details for ADMIN) incl. a custom **ledger** check · `/actuator/metrics`, `/actuator/prometheus` (ADMIN) ·
`kivubank.transactions{type,status}` counters · `http.server.requests` timers feed the dashboard's response-time and error-rate figures ·
`/api/ops/*` summaries (uptime, JVM, DB latency, slowest endpoints).

## 12. Reconciliation simulator (SIMULATION)

`SimulatedPaymentGateway` plays an unreliable external provider. An admin can (1) mirror internal transactions into the provider ledger
with injected faults – dropped, duplicated, amount drift, status flips, timeouts, provider-only "orphans" – and (2) run reconciliation, which classifies every row as
`MATCHED`, `MISSING_EXTERNAL`, `MISSING_INTERNAL`, `AMOUNT_MISMATCH`, `DUPLICATE` or `STATUS_MISMATCH`. Cancelled/reversed records are internal-only and excluded.

## 13. USSD simulator & experimental AI

* **USSD (SIMULATION):** `*123#` → 1 Balance · 2 Transfer · 3 Mini statement · 4 Exit. Stateless (aggregator-style accumulated input `2*acct*amount*pin*1`),
  uses the same services, PIN lockout and idempotency as the REST API. Not connected to any operator. A real USSD gateway would mask the PIN; the simulator echoes it.
* **Anomaly detection (EXPERIMENTAL):** an Isolation Forest implemented in `com.kivubank.anomaly` is trained at start-up on *synthetic* transactions
  and scores outgoing transfers/withdrawals on amount vs. account norm, hour, burst rate, new recipient and share of balance used. The result contains a score, a flag and
  plain-language reasons; `/api/admin/anomalies/model` shows synthetic validation metrics. **It is not real-world fraud detection.**
  The detector is behind a small interface-like boundary (`AnomalyModel`/`FeatureVector`) so a Python or hosted model can replace it later.

## 14. Limitations

* Not verified on a real bank workload; no PCI-DSS, KYC, sanctions screening, interest, fees, limits per day, multi-currency or card handling.
* Rate limiter and USSD state are in-memory (single instance). Use a shared store (e.g. Redis) to scale out.
* Idempotency records are kept indefinitely (no retention job) and a crash between commit and response storage leaves a key `IN_PROGRESS` (retries get `409`; resolve manually).
* No password-reset or e-mail verification flow yet; notifications use the simulated provider only.
* JWT is stateless with a deny-list in the database; access tokens last 30 minutes and there is no refresh token.
* Anomaly model is trained on synthetic data and retrained on every start (seeded, deterministic).
* The UI keeps the token in `sessionStorage`; a production system would use hardened cookies and a stricter CSP.
* H2 is used for tests only; behaviour such as locking is validated there, but run the suite against MySQL (e.g. Testcontainers) before relying on it.

## 15. Licence and attribution

MIT. See [`LICENSE`](LICENSE) (original copyright preserved) and [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md).
Upstream: <https://github.com/abhi9720/BankingPortal-API> by Abhishek Tiwari.
